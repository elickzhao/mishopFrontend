'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _baseComponent2.default)({
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-backdrop'
        },
        transparent: {
            type: Boolean,
            value: false
        },
        zIndex: {
            type: Number,
            value: 1000
        },
        classNames: {
            type: null,
            value: 'wux-animate--fadeIn'
        }
    },
    computed: {
        classes: function classes() {
            var _data = this.data,
                prefixCls = _data.prefixCls,
                transparent = _data.transparent;

            var wrap = transparent ? prefixCls + '--transparent' : prefixCls;

            return {
                wrap: wrap
            };
        }
    },
    methods: {
        /**
         * 保持锁定
         */
        retain: function retain() {
            if (typeof this.backdropHolds !== 'number' || !this.backdropHolds) {
                this.backdropHolds = 0;
            }

            this.backdropHolds = this.backdropHolds + 1;

            if (this.backdropHolds === 1) {
                this.setData({ in: true });
            }
        },

        /**
         * 释放锁定
         */
        release: function release() {
            if (this.backdropHolds === 1) {
                this.setData({ in: false });
            }
            this.backdropHolds = Math.max(0, this.backdropHolds - 1);
        },

        /**
         * 点击事件
         */
        onClick: function onClick() {
            this.triggerEvent('click');
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInByb3BlcnRpZXMiLCJwcmVmaXhDbHMiLCJ0eXBlIiwiU3RyaW5nIiwidmFsdWUiLCJ0cmFuc3BhcmVudCIsIkJvb2xlYW4iLCJ6SW5kZXgiLCJOdW1iZXIiLCJjbGFzc05hbWVzIiwiY29tcHV0ZWQiLCJjbGFzc2VzIiwiZGF0YSIsIndyYXAiLCJtZXRob2RzIiwicmV0YWluIiwiYmFja2Ryb3BIb2xkcyIsInNldERhdGEiLCJpbiIsInJlbGVhc2UiLCJNYXRoIiwibWF4Iiwib25DbGljayIsInRyaWdnZXJFdmVudCJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7O0FBRUEsNkJBQWM7QUFDVkEsZ0JBQVk7QUFDUkMsbUJBQVc7QUFDUEMsa0JBQU1DLE1BREM7QUFFUEMsbUJBQU87QUFGQSxTQURIO0FBS1JDLHFCQUFhO0FBQ1RILGtCQUFNSSxPQURHO0FBRVRGLG1CQUFPO0FBRkUsU0FMTDtBQVNSRyxnQkFBUTtBQUNKTCxrQkFBTU0sTUFERjtBQUVKSixtQkFBTztBQUZILFNBVEE7QUFhUkssb0JBQVk7QUFDUlAsa0JBQU0sSUFERTtBQUVSRSxtQkFBTztBQUZDO0FBYkosS0FERjtBQW1CVk0sY0FBVTtBQUNOQyxlQURNLHFCQUNJO0FBQUEsd0JBQzZCLEtBQUtDLElBRGxDO0FBQUEsZ0JBQ0VYLFNBREYsU0FDRUEsU0FERjtBQUFBLGdCQUNhSSxXQURiLFNBQ2FBLFdBRGI7O0FBRU4sZ0JBQU1RLE9BQU9SLGNBQWlCSixTQUFqQixxQkFBNENBLFNBQXpEOztBQUVBLG1CQUFPO0FBQ0hZO0FBREcsYUFBUDtBQUdIO0FBUkssS0FuQkE7QUE2QlZDLGFBQVM7QUFDTDs7O0FBR0FDLGNBSkssb0JBSUk7QUFDTCxnQkFBSSxPQUFPLEtBQUtDLGFBQVosS0FBOEIsUUFBOUIsSUFBMEMsQ0FBQyxLQUFLQSxhQUFwRCxFQUFtRTtBQUMvRCxxQkFBS0EsYUFBTCxHQUFxQixDQUFyQjtBQUNIOztBQUVELGlCQUFLQSxhQUFMLEdBQXFCLEtBQUtBLGFBQUwsR0FBcUIsQ0FBMUM7O0FBRUEsZ0JBQUksS0FBS0EsYUFBTCxLQUF1QixDQUEzQixFQUE4QjtBQUMxQixxQkFBS0MsT0FBTCxDQUFhLEVBQUVDLElBQUksSUFBTixFQUFiO0FBQ0g7QUFDSixTQWRJOztBQWVMOzs7QUFHQUMsZUFsQksscUJBa0JLO0FBQ04sZ0JBQUksS0FBS0gsYUFBTCxLQUF1QixDQUEzQixFQUE4QjtBQUMxQixxQkFBS0MsT0FBTCxDQUFhLEVBQUVDLElBQUksS0FBTixFQUFiO0FBQ0g7QUFDRCxpQkFBS0YsYUFBTCxHQUFxQkksS0FBS0MsR0FBTCxDQUFTLENBQVQsRUFBWSxLQUFLTCxhQUFMLEdBQXFCLENBQWpDLENBQXJCO0FBQ0gsU0F2Qkk7O0FBd0JMOzs7QUFHQU0sZUEzQksscUJBMkJLO0FBQ04saUJBQUtDLFlBQUwsQ0FBa0IsT0FBbEI7QUFDSDtBQTdCSTtBQTdCQyxDQUFkIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGJhc2VDb21wb25lbnQgZnJvbSAnLi4vaGVscGVycy9iYXNlQ29tcG9uZW50J1xuXG5iYXNlQ29tcG9uZW50KHtcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHByZWZpeENsczoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICd3dXgtYmFja2Ryb3AnLFxuICAgICAgICB9LFxuICAgICAgICB0cmFuc3BhcmVudDoge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgekluZGV4OiB7XG4gICAgICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgICAgICB2YWx1ZTogMTAwMCxcbiAgICAgICAgfSxcbiAgICAgICAgY2xhc3NOYW1lczoge1xuICAgICAgICAgICAgdHlwZTogbnVsbCxcbiAgICAgICAgICAgIHZhbHVlOiAnd3V4LWFuaW1hdGUtLWZhZGVJbicsXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBjb21wdXRlZDoge1xuICAgICAgICBjbGFzc2VzKCkge1xuICAgICAgICAgICAgY29uc3QgeyBwcmVmaXhDbHMsIHRyYW5zcGFyZW50IH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IHdyYXAgPSB0cmFuc3BhcmVudCA/IGAke3ByZWZpeENsc30tLXRyYW5zcGFyZW50YCA6IHByZWZpeENsc1xuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdyYXAsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBtZXRob2RzOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiDkv53mjIHplIHlrppcbiAgICAgICAgICovXG4gICAgICAgIHJldGFpbigpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5iYWNrZHJvcEhvbGRzICE9PSAnbnVtYmVyJyB8fCAhdGhpcy5iYWNrZHJvcEhvbGRzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5iYWNrZHJvcEhvbGRzID0gMFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLmJhY2tkcm9wSG9sZHMgPSB0aGlzLmJhY2tkcm9wSG9sZHMgKyAxXG5cbiAgICAgICAgICAgIGlmICh0aGlzLmJhY2tkcm9wSG9sZHMgPT09IDEpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoeyBpbjogdHJ1ZSB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog6YeK5pS+6ZSB5a6aXG4gICAgICAgICAqL1xuICAgICAgICByZWxlYXNlKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuYmFja2Ryb3BIb2xkcyA9PT0gMSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IGluOiBmYWxzZSB9KVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5iYWNrZHJvcEhvbGRzID0gTWF0aC5tYXgoMCwgdGhpcy5iYWNrZHJvcEhvbGRzIC0gMSlcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOeCueWHu+S6i+S7tlxuICAgICAgICAgKi9cbiAgICAgICAgb25DbGljaygpIHtcbiAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KCdjbGljaycpXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG4iXX0=