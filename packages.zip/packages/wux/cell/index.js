'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames2 = require('./../helpers/classNames.js');

var _classNames3 = _interopRequireDefault(_classNames2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _baseComponent2.default)({
    relations: {
        '../cell-group/index': {
            type: 'parent'
        }
    },
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-cell'
        },
        disabled: {
            type: Boolean,
            value: false
        },
        hoverClass: {
            type: String,
            value: 'default'
        },
        hoverStopPropagation: {
            type: Boolean,
            value: false
        },
        hoverStartTime: {
            type: Number,
            value: 20
        },
        hoverStayTime: {
            type: Number,
            value: 70
        },
        lang: {
            type: String,
            value: 'en'
        },
        sessionFrom: {
            type: String,
            value: ''
        },
        sendMessageTitle: {
            type: String,
            value: ''
        },
        sendMessagePath: {
            type: String,
            value: ''
        },
        sendMessageImg: {
            type: String,
            value: ''
        },
        showMessageCard: {
            type: Boolean,
            value: false
        },
        appParameter: {
            type: String,
            value: ''
        },
        thumb: {
            type: String,
            value: ''
        },
        title: {
            type: String,
            value: ''
        },
        label: {
            type: String,
            value: ''
        },
        extra: {
            type: String,
            value: ''
        },
        isLink: {
            type: Boolean,
            value: false
        },
        openType: {
            type: String,
            value: 'navigateTo'
        },
        url: {
            type: String,
            value: ''
        },
        delta: {
            type: Number,
            value: 1
        }
    },
    data: {
        isLast: false
    },
    computed: {
        classes: function classes() {
            var _classNames;

            var _data = this.data,
                prefixCls = _data.prefixCls,
                hoverClass = _data.hoverClass,
                isLast = _data.isLast,
                isLink = _data.isLink,
                disabled = _data.disabled;

            var wrap = (0, _classNames3.default)(prefixCls, (_classNames = {}, _defineProperty(_classNames, prefixCls + '--last', isLast), _defineProperty(_classNames, prefixCls + '--access', isLink), _defineProperty(_classNames, prefixCls + '--disabled', disabled), _classNames));
            var hd = prefixCls + '__hd';
            var thumb = prefixCls + '__thumb';
            var bd = prefixCls + '__bd';
            var text = prefixCls + '__text';
            var desc = prefixCls + '__desc';
            var ft = prefixCls + '__ft';
            var hover = hoverClass && hoverClass !== 'default' ? hoverClass : prefixCls + '--hover';

            return {
                wrap: wrap,
                hd: hd,
                thumb: thumb,
                bd: bd,
                text: text,
                desc: desc,
                ft: ft,
                hover: hover
            };
        }
    },
    methods: {
        onTap: function onTap() {
            if (!this.data.disabled) {
                this.triggerEvent('click');
                this.linkTo();
            }
        },
        bindgetuserinfo: function bindgetuserinfo(e) {
            this.triggerEvent('getuserinfo', e.detail);
        },
        bindcontact: function bindcontact(e) {
            this.triggerEvent('contact', e.detail);
        },
        bindgetphonenumber: function bindgetphonenumber(e) {
            this.triggerEvent('getphonenumber', e.detail);
        },
        bindopensetting: function bindopensetting(e) {
            this.triggerEvent('opensetting', e.detail);
        },
        onError: function onError(e) {
            this.triggerEvent('error', e.detail);
        },
        linkTo: function linkTo() {
            var _data2 = this.data,
                url = _data2.url,
                isLink = _data2.isLink,
                openType = _data2.openType,
                delta = _data2.delta;

            var navigate = ['navigateTo', 'redirectTo', 'switchTab', 'navigateBack', 'reLaunch'];

            // openType 属性可选值为 navigateTo、redirectTo、switchTab、navigateBack、reLaunch
            if (!isLink || !url || !navigate.includes(openType)) {
                return false;
            } else if (openType === 'navigateBack') {
                return wx[openType].call(wx, { delta: delta });
            } else {
                return wx[openType].call(wx, { url: url });
            }
        },
        updateIsLastElement: function updateIsLastElement(isLast) {
            this.setData({ isLast: isLast });
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInJlbGF0aW9ucyIsInR5cGUiLCJwcm9wZXJ0aWVzIiwicHJlZml4Q2xzIiwiU3RyaW5nIiwidmFsdWUiLCJkaXNhYmxlZCIsIkJvb2xlYW4iLCJob3ZlckNsYXNzIiwiaG92ZXJTdG9wUHJvcGFnYXRpb24iLCJob3ZlclN0YXJ0VGltZSIsIk51bWJlciIsImhvdmVyU3RheVRpbWUiLCJsYW5nIiwic2Vzc2lvbkZyb20iLCJzZW5kTWVzc2FnZVRpdGxlIiwic2VuZE1lc3NhZ2VQYXRoIiwic2VuZE1lc3NhZ2VJbWciLCJzaG93TWVzc2FnZUNhcmQiLCJhcHBQYXJhbWV0ZXIiLCJ0aHVtYiIsInRpdGxlIiwibGFiZWwiLCJleHRyYSIsImlzTGluayIsIm9wZW5UeXBlIiwidXJsIiwiZGVsdGEiLCJkYXRhIiwiaXNMYXN0IiwiY29tcHV0ZWQiLCJjbGFzc2VzIiwid3JhcCIsImhkIiwiYmQiLCJ0ZXh0IiwiZGVzYyIsImZ0IiwiaG92ZXIiLCJtZXRob2RzIiwib25UYXAiLCJ0cmlnZ2VyRXZlbnQiLCJsaW5rVG8iLCJiaW5kZ2V0dXNlcmluZm8iLCJlIiwiZGV0YWlsIiwiYmluZGNvbnRhY3QiLCJiaW5kZ2V0cGhvbmVudW1iZXIiLCJiaW5kb3BlbnNldHRpbmciLCJvbkVycm9yIiwibmF2aWdhdGUiLCJpbmNsdWRlcyIsInd4IiwiY2FsbCIsInVwZGF0ZUlzTGFzdEVsZW1lbnQiLCJzZXREYXRhIl0sIm1hcHBpbmdzIjoiOztBQUFBOzs7O0FBQ0E7Ozs7Ozs7O0FBRUEsNkJBQWM7QUFDVkEsZUFBVztBQUNQLCtCQUF1QjtBQUNuQkMsa0JBQU07QUFEYTtBQURoQixLQUREO0FBTVZDLGdCQUFZO0FBQ1JDLG1CQUFXO0FBQ1BGLGtCQUFNRyxNQURDO0FBRVBDLG1CQUFPO0FBRkEsU0FESDtBQUtSQyxrQkFBVTtBQUNOTCxrQkFBTU0sT0FEQTtBQUVORixtQkFBTztBQUZELFNBTEY7QUFTUkcsb0JBQVk7QUFDUlAsa0JBQU1HLE1BREU7QUFFUkMsbUJBQU87QUFGQyxTQVRKO0FBYVJJLDhCQUFzQjtBQUNsQlIsa0JBQU1NLE9BRFk7QUFFbEJGLG1CQUFPO0FBRlcsU0FiZDtBQWlCUkssd0JBQWdCO0FBQ1pULGtCQUFNVSxNQURNO0FBRVpOLG1CQUFPO0FBRkssU0FqQlI7QUFxQlJPLHVCQUFlO0FBQ1hYLGtCQUFNVSxNQURLO0FBRVhOLG1CQUFPO0FBRkksU0FyQlA7QUF5QlJRLGNBQU07QUFDRlosa0JBQU1HLE1BREo7QUFFRkMsbUJBQU87QUFGTCxTQXpCRTtBQTZCUlMscUJBQWE7QUFDVGIsa0JBQU1HLE1BREc7QUFFVEMsbUJBQU87QUFGRSxTQTdCTDtBQWlDUlUsMEJBQWtCO0FBQ2RkLGtCQUFNRyxNQURRO0FBRWRDLG1CQUFPO0FBRk8sU0FqQ1Y7QUFxQ1JXLHlCQUFpQjtBQUNiZixrQkFBTUcsTUFETztBQUViQyxtQkFBTztBQUZNLFNBckNUO0FBeUNSWSx3QkFBZ0I7QUFDWmhCLGtCQUFNRyxNQURNO0FBRVpDLG1CQUFPO0FBRkssU0F6Q1I7QUE2Q1JhLHlCQUFpQjtBQUNiakIsa0JBQU1NLE9BRE87QUFFYkYsbUJBQU87QUFGTSxTQTdDVDtBQWlEUmMsc0JBQWM7QUFDVmxCLGtCQUFNRyxNQURJO0FBRVZDLG1CQUFPO0FBRkcsU0FqRE47QUFxRFJlLGVBQU87QUFDSG5CLGtCQUFNRyxNQURIO0FBRUhDLG1CQUFPO0FBRkosU0FyREM7QUF5RFJnQixlQUFPO0FBQ0hwQixrQkFBTUcsTUFESDtBQUVIQyxtQkFBTztBQUZKLFNBekRDO0FBNkRSaUIsZUFBTztBQUNIckIsa0JBQU1HLE1BREg7QUFFSEMsbUJBQU87QUFGSixTQTdEQztBQWlFUmtCLGVBQU87QUFDSHRCLGtCQUFNRyxNQURIO0FBRUhDLG1CQUFPO0FBRkosU0FqRUM7QUFxRVJtQixnQkFBUTtBQUNKdkIsa0JBQU1NLE9BREY7QUFFSkYsbUJBQU87QUFGSCxTQXJFQTtBQXlFUm9CLGtCQUFVO0FBQ054QixrQkFBTUcsTUFEQTtBQUVOQyxtQkFBTztBQUZELFNBekVGO0FBNkVScUIsYUFBSztBQUNEekIsa0JBQU1HLE1BREw7QUFFREMsbUJBQU87QUFGTixTQTdFRztBQWlGUnNCLGVBQU87QUFDSDFCLGtCQUFNVSxNQURIO0FBRUhOLG1CQUFPO0FBRko7QUFqRkMsS0FORjtBQTRGVnVCLFVBQU07QUFDRkMsZ0JBQVE7QUFETixLQTVGSTtBQStGVkMsY0FBVTtBQUNOQyxlQURNLHFCQUNJO0FBQUE7O0FBQUEsd0JBQ3NELEtBQUtILElBRDNEO0FBQUEsZ0JBQ0V6QixTQURGLFNBQ0VBLFNBREY7QUFBQSxnQkFDYUssVUFEYixTQUNhQSxVQURiO0FBQUEsZ0JBQ3lCcUIsTUFEekIsU0FDeUJBLE1BRHpCO0FBQUEsZ0JBQ2lDTCxNQURqQyxTQUNpQ0EsTUFEakM7QUFBQSxnQkFDeUNsQixRQUR6QyxTQUN5Q0EsUUFEekM7O0FBRU4sZ0JBQU0wQixPQUFPLDBCQUFXN0IsU0FBWCxrREFDTEEsU0FESyxhQUNlMEIsTUFEZixnQ0FFTDFCLFNBRkssZUFFaUJxQixNQUZqQixnQ0FHTHJCLFNBSEssaUJBR21CRyxRQUhuQixnQkFBYjtBQUtBLGdCQUFNMkIsS0FBUTlCLFNBQVIsU0FBTjtBQUNBLGdCQUFNaUIsUUFBV2pCLFNBQVgsWUFBTjtBQUNBLGdCQUFNK0IsS0FBUS9CLFNBQVIsU0FBTjtBQUNBLGdCQUFNZ0MsT0FBVWhDLFNBQVYsV0FBTjtBQUNBLGdCQUFNaUMsT0FBVWpDLFNBQVYsV0FBTjtBQUNBLGdCQUFNa0MsS0FBUWxDLFNBQVIsU0FBTjtBQUNBLGdCQUFNbUMsUUFBUTlCLGNBQWNBLGVBQWUsU0FBN0IsR0FBeUNBLFVBQXpDLEdBQXlETCxTQUF6RCxZQUFkOztBQUVBLG1CQUFPO0FBQ0g2QiwwQkFERztBQUVIQyxzQkFGRztBQUdIYiw0QkFIRztBQUlIYyxzQkFKRztBQUtIQywwQkFMRztBQU1IQywwQkFORztBQU9IQyxzQkFQRztBQVFIQztBQVJHLGFBQVA7QUFVSDtBQTFCSyxLQS9GQTtBQTJIVkMsYUFBUztBQUNMQyxhQURLLG1CQUNHO0FBQ0osZ0JBQUksQ0FBQyxLQUFLWixJQUFMLENBQVV0QixRQUFmLEVBQXlCO0FBQ3JCLHFCQUFLbUMsWUFBTCxDQUFrQixPQUFsQjtBQUNBLHFCQUFLQyxNQUFMO0FBQ0g7QUFDSixTQU5JO0FBT0xDLHVCQVBLLDJCQU9XQyxDQVBYLEVBT2M7QUFDZixpQkFBS0gsWUFBTCxDQUFrQixhQUFsQixFQUFpQ0csRUFBRUMsTUFBbkM7QUFDSCxTQVRJO0FBVUxDLG1CQVZLLHVCQVVPRixDQVZQLEVBVVU7QUFDWCxpQkFBS0gsWUFBTCxDQUFrQixTQUFsQixFQUE2QkcsRUFBRUMsTUFBL0I7QUFDSCxTQVpJO0FBYUxFLDBCQWJLLDhCQWFjSCxDQWJkLEVBYWlCO0FBQ2xCLGlCQUFLSCxZQUFMLENBQWtCLGdCQUFsQixFQUFvQ0csRUFBRUMsTUFBdEM7QUFDSCxTQWZJO0FBZ0JMRyx1QkFoQkssMkJBZ0JXSixDQWhCWCxFQWdCYztBQUNmLGlCQUFLSCxZQUFMLENBQWtCLGFBQWxCLEVBQWlDRyxFQUFFQyxNQUFuQztBQUNILFNBbEJJO0FBbUJMSSxlQW5CSyxtQkFtQkdMLENBbkJILEVBbUJNO0FBQ1AsaUJBQUtILFlBQUwsQ0FBa0IsT0FBbEIsRUFBMkJHLEVBQUVDLE1BQTdCO0FBQ0gsU0FyQkk7QUFzQkxILGNBdEJLLG9CQXNCSTtBQUFBLHlCQUNvQyxLQUFLZCxJQUR6QztBQUFBLGdCQUNHRixHQURILFVBQ0dBLEdBREg7QUFBQSxnQkFDUUYsTUFEUixVQUNRQSxNQURSO0FBQUEsZ0JBQ2dCQyxRQURoQixVQUNnQkEsUUFEaEI7QUFBQSxnQkFDMEJFLEtBRDFCLFVBQzBCQSxLQUQxQjs7QUFFTCxnQkFBTXVCLFdBQVcsQ0FDYixZQURhLEVBRWIsWUFGYSxFQUdiLFdBSGEsRUFJYixjQUphLEVBS2IsVUFMYSxDQUFqQjs7QUFRQTtBQUNBLGdCQUFJLENBQUMxQixNQUFELElBQVcsQ0FBQ0UsR0FBWixJQUFtQixDQUFDd0IsU0FBU0MsUUFBVCxDQUFrQjFCLFFBQWxCLENBQXhCLEVBQXFEO0FBQ2pELHVCQUFPLEtBQVA7QUFDSCxhQUZELE1BRU8sSUFBSUEsYUFBYSxjQUFqQixFQUFpQztBQUNwQyx1QkFBTzJCLEdBQUczQixRQUFILEVBQWE0QixJQUFiLENBQWtCRCxFQUFsQixFQUFzQixFQUFFekIsWUFBRixFQUF0QixDQUFQO0FBQ0gsYUFGTSxNQUVBO0FBQ0gsdUJBQU95QixHQUFHM0IsUUFBSCxFQUFhNEIsSUFBYixDQUFrQkQsRUFBbEIsRUFBc0IsRUFBRTFCLFFBQUYsRUFBdEIsQ0FBUDtBQUNIO0FBQ0osU0F4Q0k7QUF5Q0w0QiwyQkF6Q0ssK0JBeUNlekIsTUF6Q2YsRUF5Q3VCO0FBQ3hCLGlCQUFLMEIsT0FBTCxDQUFhLEVBQUUxQixjQUFGLEVBQWI7QUFDSDtBQTNDSTtBQTNIQyxDQUFkIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGJhc2VDb21wb25lbnQgZnJvbSAnLi4vaGVscGVycy9iYXNlQ29tcG9uZW50J1xuaW1wb3J0IGNsYXNzTmFtZXMgZnJvbSAnLi4vaGVscGVycy9jbGFzc05hbWVzJ1xuXG5iYXNlQ29tcG9uZW50KHtcbiAgICByZWxhdGlvbnM6IHtcbiAgICAgICAgJy4uL2NlbGwtZ3JvdXAvaW5kZXgnOiB7XG4gICAgICAgICAgICB0eXBlOiAncGFyZW50JyxcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcHJlZml4Q2xzOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ3d1eC1jZWxsJyxcbiAgICAgICAgfSxcbiAgICAgICAgZGlzYWJsZWQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGhvdmVyQ2xhc3M6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnZGVmYXVsdCcsXG4gICAgICAgIH0sXG4gICAgICAgIGhvdmVyU3RvcFByb3BhZ2F0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBob3ZlclN0YXJ0VGltZToge1xuICAgICAgICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgICAgICAgdmFsdWU6IDIwLFxuICAgICAgICB9LFxuICAgICAgICBob3ZlclN0YXlUaW1lOiB7XG4gICAgICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgICAgICB2YWx1ZTogNzAsXG4gICAgICAgIH0sXG4gICAgICAgIGxhbmc6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnZW4nLFxuICAgICAgICB9LFxuICAgICAgICBzZXNzaW9uRnJvbToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzZW5kTWVzc2FnZVRpdGxlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIHNlbmRNZXNzYWdlUGF0aDoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzZW5kTWVzc2FnZUltZzoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzaG93TWVzc2FnZUNhcmQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGFwcFBhcmFtZXRlcjoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICB0aHVtYjoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBsYWJlbDoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBleHRyYToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBpc0xpbms6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIG9wZW5UeXBlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ25hdmlnYXRlVG8nLFxuICAgICAgICB9LFxuICAgICAgICB1cmw6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgZGVsdGE6IHtcbiAgICAgICAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgICAgICAgIHZhbHVlOiAxLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgZGF0YToge1xuICAgICAgICBpc0xhc3Q6IGZhbHNlLFxuICAgIH0sXG4gICAgY29tcHV0ZWQ6IHtcbiAgICAgICAgY2xhc3NlcygpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcHJlZml4Q2xzLCBob3ZlckNsYXNzLCBpc0xhc3QsIGlzTGluaywgZGlzYWJsZWQgfSA9IHRoaXMuZGF0YVxuICAgICAgICAgICAgY29uc3Qgd3JhcCA9IGNsYXNzTmFtZXMocHJlZml4Q2xzLCB7XG4gICAgICAgICAgICAgICAgW2Ake3ByZWZpeENsc30tLWxhc3RgXTogaXNMYXN0LFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1hY2Nlc3NgXTogaXNMaW5rLFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1kaXNhYmxlZGBdOiBkaXNhYmxlZCxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBjb25zdCBoZCA9IGAke3ByZWZpeENsc31fX2hkYFxuICAgICAgICAgICAgY29uc3QgdGh1bWIgPSBgJHtwcmVmaXhDbHN9X190aHVtYmBcbiAgICAgICAgICAgIGNvbnN0IGJkID0gYCR7cHJlZml4Q2xzfV9fYmRgXG4gICAgICAgICAgICBjb25zdCB0ZXh0ID0gYCR7cHJlZml4Q2xzfV9fdGV4dGBcbiAgICAgICAgICAgIGNvbnN0IGRlc2MgPSBgJHtwcmVmaXhDbHN9X19kZXNjYFxuICAgICAgICAgICAgY29uc3QgZnQgPSBgJHtwcmVmaXhDbHN9X19mdGBcbiAgICAgICAgICAgIGNvbnN0IGhvdmVyID0gaG92ZXJDbGFzcyAmJiBob3ZlckNsYXNzICE9PSAnZGVmYXVsdCcgPyBob3ZlckNsYXNzIDogYCR7cHJlZml4Q2xzfS0taG92ZXJgXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgd3JhcCxcbiAgICAgICAgICAgICAgICBoZCxcbiAgICAgICAgICAgICAgICB0aHVtYixcbiAgICAgICAgICAgICAgICBiZCxcbiAgICAgICAgICAgICAgICB0ZXh0LFxuICAgICAgICAgICAgICAgIGRlc2MsXG4gICAgICAgICAgICAgICAgZnQsXG4gICAgICAgICAgICAgICAgaG92ZXIsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBtZXRob2RzOiB7XG4gICAgICAgIG9uVGFwKCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmRhdGEuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2xpY2snKVxuICAgICAgICAgICAgICAgIHRoaXMubGlua1RvKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgYmluZGdldHVzZXJpbmZvKGUpIHtcbiAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KCdnZXR1c2VyaW5mbycsIGUuZGV0YWlsKVxuICAgICAgICB9LFxuICAgICAgICBiaW5kY29udGFjdChlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY29udGFjdCcsIGUuZGV0YWlsKVxuICAgICAgICB9LFxuICAgICAgICBiaW5kZ2V0cGhvbmVudW1iZXIoZSkge1xuICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2dldHBob25lbnVtYmVyJywgZS5kZXRhaWwpXG4gICAgICAgIH0sXG4gICAgICAgIGJpbmRvcGVuc2V0dGluZyhlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnb3BlbnNldHRpbmcnLCBlLmRldGFpbClcbiAgICAgICAgfSxcbiAgICAgICAgb25FcnJvcihlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnZXJyb3InLCBlLmRldGFpbClcbiAgICAgICAgfSxcbiAgICAgICAgbGlua1RvKCkge1xuICAgICAgICAgICAgY29uc3QgeyB1cmwsIGlzTGluaywgb3BlblR5cGUsIGRlbHRhIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IG5hdmlnYXRlID0gW1xuICAgICAgICAgICAgICAgICduYXZpZ2F0ZVRvJyxcbiAgICAgICAgICAgICAgICAncmVkaXJlY3RUbycsXG4gICAgICAgICAgICAgICAgJ3N3aXRjaFRhYicsXG4gICAgICAgICAgICAgICAgJ25hdmlnYXRlQmFjaycsXG4gICAgICAgICAgICAgICAgJ3JlTGF1bmNoJyxcbiAgICAgICAgICAgIF1cblxuICAgICAgICAgICAgLy8gb3BlblR5cGUg5bGe5oCn5Y+v6YCJ5YC85Li6IG5hdmlnYXRlVG/jgIFyZWRpcmVjdFRv44CBc3dpdGNoVGFi44CBbmF2aWdhdGVCYWNr44CBcmVMYXVuY2hcbiAgICAgICAgICAgIGlmICghaXNMaW5rIHx8ICF1cmwgfHwgIW5hdmlnYXRlLmluY2x1ZGVzKG9wZW5UeXBlKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICAgICAgfSBlbHNlIGlmIChvcGVuVHlwZSA9PT0gJ25hdmlnYXRlQmFjaycpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gd3hbb3BlblR5cGVdLmNhbGwod3gsIHsgZGVsdGEgfSlcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHd4W29wZW5UeXBlXS5jYWxsKHd4LCB7IHVybCB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICB1cGRhdGVJc0xhc3RFbGVtZW50KGlzTGFzdCkge1xuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgaXNMYXN0IH0pXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG4iXX0=