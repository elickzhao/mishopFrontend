'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames = require('./../helpers/classNames.js');

var _classNames2 = _interopRequireDefault(_classNames);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _baseComponent2.default)({
    relations: {
        '../sticky-item/index': {
            type: 'child',
            observer: function observer() {
                this.debounce(this.updated);
            }
        }
    },
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-sticky'
        },
        scrollTop: {
            type: Number,
            value: 0,
            observer: 'onScroll'
        }
    },
    computed: {
        classes: function classes() {
            var prefixCls = this.data.prefixCls;

            var wrap = (0, _classNames2.default)(prefixCls);

            return {
                wrap: wrap
            };
        }
    },
    methods: {
        onScroll: function onScroll() {
            var scrollTop = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.scrollTop;

            var elements = this.getRelationNodes('../sticky-item/index');
            if (elements.length > 0) {
                elements.forEach(function (element, index) {
                    element.onScroll(scrollTop);
                });
            }
        },
        updated: function updated() {
            var elements = this.getRelationNodes('../sticky-item/index');
            if (elements.length > 0) {
                elements.forEach(function (element, index) {
                    element.updated(index);
                });
            }
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInJlbGF0aW9ucyIsInR5cGUiLCJvYnNlcnZlciIsImRlYm91bmNlIiwidXBkYXRlZCIsInByb3BlcnRpZXMiLCJwcmVmaXhDbHMiLCJTdHJpbmciLCJ2YWx1ZSIsInNjcm9sbFRvcCIsIk51bWJlciIsImNvbXB1dGVkIiwiY2xhc3NlcyIsImRhdGEiLCJ3cmFwIiwibWV0aG9kcyIsIm9uU2Nyb2xsIiwiZWxlbWVudHMiLCJnZXRSZWxhdGlvbk5vZGVzIiwibGVuZ3RoIiwiZm9yRWFjaCIsImVsZW1lbnQiLCJpbmRleCJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7OztBQUNBOzs7Ozs7QUFFQSw2QkFBYztBQUNWQSxlQUFXO0FBQ1AsZ0NBQXdCO0FBQ3BCQyxrQkFBTSxPQURjO0FBRXBCQyxvQkFGb0Isc0JBRVQ7QUFDUCxxQkFBS0MsUUFBTCxDQUFjLEtBQUtDLE9BQW5CO0FBQ0g7QUFKbUI7QUFEakIsS0FERDtBQVNWQyxnQkFBWTtBQUNSQyxtQkFBVztBQUNQTCxrQkFBTU0sTUFEQztBQUVQQyxtQkFBTztBQUZBLFNBREg7QUFLUkMsbUJBQVc7QUFDUFIsa0JBQU1TLE1BREM7QUFFUEYsbUJBQU8sQ0FGQTtBQUdQTixzQkFBVTtBQUhIO0FBTEgsS0FURjtBQW9CVlMsY0FBVTtBQUNOQyxlQURNLHFCQUNJO0FBQUEsZ0JBQ0VOLFNBREYsR0FDZ0IsS0FBS08sSUFEckIsQ0FDRVAsU0FERjs7QUFFTixnQkFBTVEsT0FBTywwQkFBV1IsU0FBWCxDQUFiOztBQUVBLG1CQUFPO0FBQ0hRO0FBREcsYUFBUDtBQUdIO0FBUkssS0FwQkE7QUE4QlZDLGFBQVM7QUFDTEMsZ0JBREssc0JBQ3FDO0FBQUEsZ0JBQWpDUCxTQUFpQyx1RUFBckIsS0FBS0ksSUFBTCxDQUFVSixTQUFXOztBQUN0QyxnQkFBTVEsV0FBVyxLQUFLQyxnQkFBTCxDQUFzQixzQkFBdEIsQ0FBakI7QUFDQSxnQkFBSUQsU0FBU0UsTUFBVCxHQUFrQixDQUF0QixFQUF5QjtBQUNyQkYseUJBQVNHLE9BQVQsQ0FBaUIsVUFBQ0MsT0FBRCxFQUFVQyxLQUFWLEVBQW9CO0FBQ2pDRCw0QkFBUUwsUUFBUixDQUFpQlAsU0FBakI7QUFDSCxpQkFGRDtBQUdIO0FBQ0osU0FSSTtBQVNSTCxlQVRRLHFCQVNFO0FBQ1QsZ0JBQU1hLFdBQVcsS0FBS0MsZ0JBQUwsQ0FBc0Isc0JBQXRCLENBQWpCO0FBQ00sZ0JBQUlELFNBQVNFLE1BQVQsR0FBa0IsQ0FBdEIsRUFBeUI7QUFDakNGLHlCQUFTRyxPQUFULENBQWlCLFVBQUNDLE9BQUQsRUFBVUMsS0FBVixFQUFvQjtBQUNqQ0QsNEJBQVFqQixPQUFSLENBQWdCa0IsS0FBaEI7QUFDSCxpQkFGRDtBQUdTO0FBQ1A7QUFoQk87QUE5QkMsQ0FBZCIsImZpbGUiOiJpbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBiYXNlQ29tcG9uZW50IGZyb20gJy4uL2hlbHBlcnMvYmFzZUNvbXBvbmVudCdcbmltcG9ydCBjbGFzc05hbWVzIGZyb20gJy4uL2hlbHBlcnMvY2xhc3NOYW1lcydcblxuYmFzZUNvbXBvbmVudCh7XG4gICAgcmVsYXRpb25zOiB7XG4gICAgICAgICcuLi9zdGlja3ktaXRlbS9pbmRleCc6IHtcbiAgICAgICAgICAgIHR5cGU6ICdjaGlsZCcsXG4gICAgICAgICAgICBvYnNlcnZlcigpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRlYm91bmNlKHRoaXMudXBkYXRlZClcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHByZWZpeENsczoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICd3dXgtc3RpY2t5JyxcbiAgICAgICAgfSxcbiAgICAgICAgc2Nyb2xsVG9wOiB7XG4gICAgICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgICAgICB2YWx1ZTogMCxcbiAgICAgICAgICAgIG9ic2VydmVyOiAnb25TY3JvbGwnLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgY29tcHV0ZWQ6IHtcbiAgICAgICAgY2xhc3NlcygpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcHJlZml4Q2xzIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IHdyYXAgPSBjbGFzc05hbWVzKHByZWZpeENscylcblxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB3cmFwLFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICBvblNjcm9sbChzY3JvbGxUb3AgPSB0aGlzLmRhdGEuc2Nyb2xsVG9wKSB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50cyA9IHRoaXMuZ2V0UmVsYXRpb25Ob2RlcygnLi4vc3RpY2t5LWl0ZW0vaW5kZXgnKVxuICAgICAgICAgICAgaWYgKGVsZW1lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50cy5mb3JFYWNoKChlbGVtZW50LCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50Lm9uU2Nyb2xsKHNjcm9sbFRvcClcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIFx0dXBkYXRlZCgpIHtcbiAgICBcdFx0Y29uc3QgZWxlbWVudHMgPSB0aGlzLmdldFJlbGF0aW9uTm9kZXMoJy4uL3N0aWNreS1pdGVtL2luZGV4JylcbiAgICAgICAgICAgIGlmIChlbGVtZW50cy5sZW5ndGggPiAwKSB7XG5cdFx0XHRcdGVsZW1lbnRzLmZvckVhY2goKGVsZW1lbnQsIGluZGV4KSA9PiB7XG5cdFx0XHRcdCAgICBlbGVtZW50LnVwZGF0ZWQoaW5kZXgpXG5cdFx0XHRcdH0pXG4gICAgICAgICAgICB9XG4gICAgXHR9LFxuICAgIH0sXG59KVxuIl19