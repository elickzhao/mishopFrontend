"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var CountUp = function () {
    function CountUp(startVal, endVal, decimals, duration) {
        var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
        var page = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : getCurrentPages()[getCurrentPages().length - 1];

        _classCallCheck(this, CountUp);

        Object.assign(this, {
            page: page,
            startVal: startVal,
            endVal: endVal,
            decimals: decimals,
            duration: duration,
            options: options
        });
        this.__init();
    }

    /**
     * 初始化
     */


    _createClass(CountUp, [{
        key: "__init",
        value: function __init() {
            this.setData = this.page.setData.bind(this.page);

            this.lastTime = 0;

            // merge options
            this.mergeOptions(this.options);

            this.startVal = Number(this.startVal);
            this.cacheVal = this.startVal;
            this.endVal = Number(this.endVal);
            this.countDown = this.startVal > this.endVal;
            this.frameVal = this.startVal;
            this.decimals = Math.max(0, this.decimals || 0);
            this.dec = Math.pow(10, this.decimals);
            this.duration = Number(this.duration) * 1000 || 2000;

            // format startVal on initialization
            this.printValue(this.formattingFn(this.startVal));
        }

        /**
         * 默认参数
         */

    }, {
        key: "setDefaultOptions",
        value: function setDefaultOptions() {
            return {
                useEasing: true, // toggle easing
                useGrouping: true, // 1,000,000 vs 1000000
                separator: ",", // character to use as a separator
                decimal: ".", // character to use as a decimal
                easingFn: null, // optional custom easing closure function, default is Robert Penner's easeOutExpo
                formattingFn: null, // optional custom formatting function, default is this.formatNumber below
                printValue: function printValue(value) {}
            };
        }

        /**
         * 合并参数
         */

    }, {
        key: "mergeOptions",
        value: function mergeOptions(options) {
            var defaultOptions = this.setDefaultOptions();

            // extend default options with passed options object
            for (var key in defaultOptions) {
                if (defaultOptions.hasOwnProperty(key)) {
                    this.options[key] = typeof options[key] !== "undefined" ? options[key] : defaultOptions[key];
                    if (typeof this.options[key] === "function") {
                        this.options[key] = this.options[key].bind(this);
                    }
                }
            }

            if (this.options.separator === "") {
                this.options.useGrouping = !1;
            }
            if (!this.options.prefix) this.options.prefix = "";
            if (!this.options.suffix) this.options.suffix = "";

            this.easingFn = this.options.easingFn ? this.options.easingFn : this.easeOutExpo;
            this.formattingFn = this.options.formattingFn ? this.options.formattingFn : this.formatNumber;
            this.printValue = this.options.printValue ? this.options.printValue : function () {};
        }

        /**
         * 创建定时器
         */

    }, {
        key: "requestAnimationFrame",
        value: function requestAnimationFrame(callback) {
            var _this = this;

            var currTime = new Date().getTime();
            var timeToCall = Math.max(0, 16 - (currTime - this.lastTime));
            var timeout = setTimeout(function () {
                callback.bind(_this)(currTime + timeToCall);
            }, timeToCall);
            this.lastTime = currTime + timeToCall;
            return timeout;
        }

        /**
         * 清空定时器
         */

    }, {
        key: "cancelAnimationFrame",
        value: function cancelAnimationFrame(timeout) {
            clearTimeout(timeout);
        }

        /**
         * 格式化数字
         */

    }, {
        key: "formatNumber",
        value: function formatNumber(nStr) {
            nStr = nStr.toFixed(this.decimals);
            nStr += "";
            var x = void 0,
                x1 = void 0,
                x2 = void 0,
                rgx = void 0;
            x = nStr.split(".");
            x1 = x[0];
            x2 = x.length > 1 ? this.options.decimal + x[1] : "";
            rgx = /(\d+)(\d{3})/;
            if (this.options.useGrouping) {
                while (rgx.test(x1)) {
                    x1 = x1.replace(rgx, "$1" + this.options.separator + "$2");
                }
            }
            return this.options.prefix + x1 + x2 + this.options.suffix;
        }

        /**
         * 过渡效果
         */

    }, {
        key: "easeOutExpo",
        value: function easeOutExpo(t, b, c, d) {
            return c * (-Math.pow(2, -10 * t / d) + 1) * 1024 / 1023 + b;
        }

        /**
         * 计数函数
         */

    }, {
        key: "count",
        value: function count(timestamp) {
            if (!this.startTime) {
                this.startTime = timestamp;
            }

            this.timestamp = timestamp;
            var progress = timestamp - this.startTime;
            this.remaining = this.duration - progress;

            // to ease or not to ease
            if (this.options.useEasing) {
                if (this.countDown) {
                    this.frameVal = this.startVal - this.easingFn(progress, 0, this.startVal - this.endVal, this.duration);
                } else {
                    this.frameVal = this.easingFn(progress, this.startVal, this.endVal - this.startVal, this.duration);
                }
            } else {
                if (this.countDown) {
                    this.frameVal = this.startVal - (this.startVal - this.endVal) * (progress / this.duration);
                } else {
                    this.frameVal = this.startVal + (this.endVal - this.startVal) * (progress / this.duration);
                }
            }

            // don't go past endVal since progress can exceed duration in the last frame
            if (this.countDown) {
                this.frameVal = this.frameVal < this.endVal ? this.endVal : this.frameVal;
            } else {
                this.frameVal = this.frameVal > this.endVal ? this.endVal : this.frameVal;
            }

            // decimal
            this.frameVal = Math.round(this.frameVal * this.dec) / this.dec;

            // format and print value
            this.printValue(this.formattingFn(this.frameVal));

            // whether to continue
            if (progress < this.duration) {
                this.rAF = this.requestAnimationFrame(this.count);
            } else {
                if (this.callback) {
                    this.callback();
                }
            }
        }

        /**
         * 启动计数器
         */

    }, {
        key: "start",
        value: function start(callback) {
            this.callback = callback;
            this.rAF = this.requestAnimationFrame(this.count);
            return !1;
        }

        /**
         * 停止计数器
         */

    }, {
        key: "pauseResume",
        value: function pauseResume() {
            if (!this.paused) {
                this.paused = !0;
                this.cancelAnimationFrame(this.rAF);
            } else {
                this.paused = !1;
                delete this.startTime;
                this.duration = this.remaining;
                this.startVal = this.frameVal;
                this.requestAnimationFrame(this.count);
            }
        }

        /**
         * 重置计数器
         */

    }, {
        key: "reset",
        value: function reset() {
            this.paused = !1;
            delete this.startTime;
            this.startVal = this.cacheVal;
            this.cancelAnimationFrame(this.rAF);
            this.printValue(this.formattingFn(this.startVal));
        }

        /**
         * 更新计数器
         */

    }, {
        key: "update",
        value: function update(newEndVal) {
            this.cancelAnimationFrame(this.rAF);
            this.paused = !1;
            delete this.startTime;
            this.startVal = this.frameVal;
            this.endVal = Number(newEndVal);
            this.countDown = this.startVal > this.endVal;
            this.rAF = this.requestAnimationFrame(this.count);
        }
    }]);

    return CountUp;
}();

exports.default = CountUp;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkNvdW50VXAiLCJzdGFydFZhbCIsImVuZFZhbCIsImRlY2ltYWxzIiwiZHVyYXRpb24iLCJvcHRpb25zIiwicGFnZSIsImdldEN1cnJlbnRQYWdlcyIsImxlbmd0aCIsIk9iamVjdCIsImFzc2lnbiIsIl9faW5pdCIsInNldERhdGEiLCJiaW5kIiwibGFzdFRpbWUiLCJtZXJnZU9wdGlvbnMiLCJOdW1iZXIiLCJjYWNoZVZhbCIsImNvdW50RG93biIsImZyYW1lVmFsIiwiTWF0aCIsIm1heCIsImRlYyIsInBvdyIsInByaW50VmFsdWUiLCJmb3JtYXR0aW5nRm4iLCJ1c2VFYXNpbmciLCJ1c2VHcm91cGluZyIsInNlcGFyYXRvciIsImRlY2ltYWwiLCJlYXNpbmdGbiIsInZhbHVlIiwiZGVmYXVsdE9wdGlvbnMiLCJzZXREZWZhdWx0T3B0aW9ucyIsImtleSIsImhhc093blByb3BlcnR5IiwicHJlZml4Iiwic3VmZml4IiwiZWFzZU91dEV4cG8iLCJmb3JtYXROdW1iZXIiLCJjYWxsYmFjayIsImN1cnJUaW1lIiwiRGF0ZSIsImdldFRpbWUiLCJ0aW1lVG9DYWxsIiwidGltZW91dCIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJuU3RyIiwidG9GaXhlZCIsIngiLCJ4MSIsIngyIiwicmd4Iiwic3BsaXQiLCJ0ZXN0IiwicmVwbGFjZSIsInQiLCJiIiwiYyIsImQiLCJ0aW1lc3RhbXAiLCJzdGFydFRpbWUiLCJwcm9ncmVzcyIsInJlbWFpbmluZyIsInJvdW5kIiwickFGIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwiY291bnQiLCJwYXVzZWQiLCJjYW5jZWxBbmltYXRpb25GcmFtZSIsIm5ld0VuZFZhbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztJQUFNQSxPO0FBQ0YscUJBQVlDLFFBQVosRUFBc0JDLE1BQXRCLEVBQThCQyxRQUE5QixFQUF3Q0MsUUFBeEMsRUFBd0g7QUFBQSxZQUF0RUMsT0FBc0UsdUVBQTVELEVBQTREO0FBQUEsWUFBeERDLElBQXdELHVFQUFqREMsa0JBQWtCQSxrQkFBa0JDLE1BQWxCLEdBQTJCLENBQTdDLENBQWlEOztBQUFBOztBQUNwSEMsZUFBT0MsTUFBUCxDQUFjLElBQWQsRUFBb0I7QUFDaEJKLHNCQURnQjtBQUVoQkwsOEJBRmdCO0FBR2hCQywwQkFIZ0I7QUFJaEJDLDhCQUpnQjtBQUtoQkMsOEJBTGdCO0FBTWhCQztBQU5nQixTQUFwQjtBQVFBLGFBQUtNLE1BQUw7QUFDSDs7QUFFRDs7Ozs7OztpQ0FHUztBQUNMLGlCQUFLQyxPQUFMLEdBQWUsS0FBS04sSUFBTCxDQUFVTSxPQUFWLENBQWtCQyxJQUFsQixDQUF1QixLQUFLUCxJQUE1QixDQUFmOztBQUVBLGlCQUFLUSxRQUFMLEdBQWdCLENBQWhCOztBQUVBO0FBQ0EsaUJBQUtDLFlBQUwsQ0FBa0IsS0FBS1YsT0FBdkI7O0FBRUEsaUJBQUtKLFFBQUwsR0FBZ0JlLE9BQU8sS0FBS2YsUUFBWixDQUFoQjtBQUNBLGlCQUFLZ0IsUUFBTCxHQUFnQixLQUFLaEIsUUFBckI7QUFDQSxpQkFBS0MsTUFBTCxHQUFjYyxPQUFPLEtBQUtkLE1BQVosQ0FBZDtBQUNBLGlCQUFLZ0IsU0FBTCxHQUFrQixLQUFLakIsUUFBTCxHQUFnQixLQUFLQyxNQUF2QztBQUNBLGlCQUFLaUIsUUFBTCxHQUFnQixLQUFLbEIsUUFBckI7QUFDQSxpQkFBS0UsUUFBTCxHQUFnQmlCLEtBQUtDLEdBQUwsQ0FBUyxDQUFULEVBQVksS0FBS2xCLFFBQUwsSUFBaUIsQ0FBN0IsQ0FBaEI7QUFDQSxpQkFBS21CLEdBQUwsR0FBV0YsS0FBS0csR0FBTCxDQUFTLEVBQVQsRUFBYSxLQUFLcEIsUUFBbEIsQ0FBWDtBQUNBLGlCQUFLQyxRQUFMLEdBQWdCWSxPQUFPLEtBQUtaLFFBQVosSUFBd0IsSUFBeEIsSUFBZ0MsSUFBaEQ7O0FBRUE7QUFDQSxpQkFBS29CLFVBQUwsQ0FBZ0IsS0FBS0MsWUFBTCxDQUFrQixLQUFLeEIsUUFBdkIsQ0FBaEI7QUFDSDs7QUFFRDs7Ozs7OzRDQUdvQjtBQUNoQixtQkFBTztBQUNIeUIsMkJBQVcsSUFEUixFQUNjO0FBQ2pCQyw2QkFBYSxJQUZWLEVBRWdCO0FBQ25CQyw4QkFIRyxFQUdhO0FBQ2hCQyw0QkFKRyxFQUlXO0FBQ2RDLDBCQUFVLElBTFAsRUFLYTtBQUNoQkwsOEJBQWMsSUFOWCxFQU1pQjtBQUNwQkQsMEJBUEcsc0JBT1FPLEtBUFIsRUFPZSxDQUFFO0FBUGpCLGFBQVA7QUFTSDs7QUFFRDs7Ozs7O3FDQUdhMUIsTyxFQUFTO0FBQ2xCLGdCQUFNMkIsaUJBQWlCLEtBQUtDLGlCQUFMLEVBQXZCOztBQUVBO0FBQ0EsaUJBQUssSUFBSUMsR0FBVCxJQUFnQkYsY0FBaEIsRUFBZ0M7QUFDNUIsb0JBQUlBLGVBQWVHLGNBQWYsQ0FBOEJELEdBQTlCLENBQUosRUFBd0M7QUFDcEMseUJBQUs3QixPQUFMLENBQWE2QixHQUFiLElBQW9CLE9BQU83QixRQUFRNkIsR0FBUixDQUFQLG1CQUFzQzdCLFFBQVE2QixHQUFSLENBQXRDLEdBQXFERixlQUFlRSxHQUFmLENBQXpFO0FBQ0Esd0JBQUksT0FBTyxLQUFLN0IsT0FBTCxDQUFhNkIsR0FBYixDQUFQLGVBQUosRUFBNkM7QUFDekMsNkJBQUs3QixPQUFMLENBQWE2QixHQUFiLElBQW9CLEtBQUs3QixPQUFMLENBQWE2QixHQUFiLEVBQWtCckIsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBcEI7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsZ0JBQUksS0FBS1IsT0FBTCxDQUFhdUIsU0FBYixPQUFKLEVBQW1DO0FBQUUscUJBQUt2QixPQUFMLENBQWFzQixXQUFiLEdBQTJCLENBQUMsQ0FBNUI7QUFBK0I7QUFDcEUsZ0JBQUksQ0FBQyxLQUFLdEIsT0FBTCxDQUFhK0IsTUFBbEIsRUFBMEIsS0FBSy9CLE9BQUwsQ0FBYStCLE1BQWI7QUFDMUIsZ0JBQUksQ0FBQyxLQUFLL0IsT0FBTCxDQUFhZ0MsTUFBbEIsRUFBMEIsS0FBS2hDLE9BQUwsQ0FBYWdDLE1BQWI7O0FBRTFCLGlCQUFLUCxRQUFMLEdBQWdCLEtBQUt6QixPQUFMLENBQWF5QixRQUFiLEdBQXdCLEtBQUt6QixPQUFMLENBQWF5QixRQUFyQyxHQUFnRCxLQUFLUSxXQUFyRTtBQUNBLGlCQUFLYixZQUFMLEdBQW9CLEtBQUtwQixPQUFMLENBQWFvQixZQUFiLEdBQTRCLEtBQUtwQixPQUFMLENBQWFvQixZQUF6QyxHQUF3RCxLQUFLYyxZQUFqRjtBQUNBLGlCQUFLZixVQUFMLEdBQWtCLEtBQUtuQixPQUFMLENBQWFtQixVQUFiLEdBQTBCLEtBQUtuQixPQUFMLENBQWFtQixVQUF2QyxHQUFvRCxZQUFXLENBQUUsQ0FBbkY7QUFDSDs7QUFFRDs7Ozs7OzhDQUdzQmdCLFEsRUFBVTtBQUFBOztBQUM1QixnQkFBSUMsV0FBVyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBZjtBQUNBLGdCQUFJQyxhQUFheEIsS0FBS0MsR0FBTCxDQUFTLENBQVQsRUFBWSxNQUFNb0IsV0FBVyxLQUFLM0IsUUFBdEIsQ0FBWixDQUFqQjtBQUNBLGdCQUFJK0IsVUFBVUMsV0FBVyxZQUFNO0FBQzNCTix5QkFBUzNCLElBQVQsQ0FBYyxLQUFkLEVBQW9CNEIsV0FBV0csVUFBL0I7QUFDSCxhQUZhLEVBRVhBLFVBRlcsQ0FBZDtBQUdBLGlCQUFLOUIsUUFBTCxHQUFnQjJCLFdBQVdHLFVBQTNCO0FBQ0EsbUJBQU9DLE9BQVA7QUFDSDs7QUFFRDs7Ozs7OzZDQUdxQkEsTyxFQUFTO0FBQzFCRSx5QkFBYUYsT0FBYjtBQUNIOztBQUVEOzs7Ozs7cUNBR2FHLEksRUFBTTtBQUNmQSxtQkFBT0EsS0FBS0MsT0FBTCxDQUFhLEtBQUs5QyxRQUFsQixDQUFQO0FBQ0E2QztBQUNBLGdCQUFJRSxVQUFKO0FBQUEsZ0JBQU9DLFdBQVA7QUFBQSxnQkFBV0MsV0FBWDtBQUFBLGdCQUFlQyxZQUFmO0FBQ0FILGdCQUFJRixLQUFLTSxLQUFMLEtBQUo7QUFDQUgsaUJBQUtELEVBQUUsQ0FBRixDQUFMO0FBQ0FFLGlCQUFLRixFQUFFMUMsTUFBRixHQUFXLENBQVgsR0FBZSxLQUFLSCxPQUFMLENBQWF3QixPQUFiLEdBQXVCcUIsRUFBRSxDQUFGLENBQXRDLEtBQUw7QUFDQUcsa0JBQU0sY0FBTjtBQUNBLGdCQUFJLEtBQUtoRCxPQUFMLENBQWFzQixXQUFqQixFQUE4QjtBQUMxQix1QkFBTzBCLElBQUlFLElBQUosQ0FBU0osRUFBVCxDQUFQLEVBQXFCO0FBQ2pCQSx5QkFBS0EsR0FBR0ssT0FBSCxDQUFXSCxHQUFYLEVBQWdCLE9BQU8sS0FBS2hELE9BQUwsQ0FBYXVCLFNBQXBCLE9BQWhCLENBQUw7QUFDSDtBQUNKO0FBQ0QsbUJBQU8sS0FBS3ZCLE9BQUwsQ0FBYStCLE1BQWIsR0FBc0JlLEVBQXRCLEdBQTJCQyxFQUEzQixHQUFnQyxLQUFLL0MsT0FBTCxDQUFhZ0MsTUFBcEQ7QUFDSDs7QUFFRDs7Ozs7O29DQUdZb0IsQyxFQUFHQyxDLEVBQUdDLEMsRUFBR0MsQyxFQUFHO0FBQ3BCLG1CQUFPRCxLQUFLLENBQUN2QyxLQUFLRyxHQUFMLENBQVMsQ0FBVCxFQUFZLENBQUMsRUFBRCxHQUFNa0MsQ0FBTixHQUFVRyxDQUF0QixDQUFELEdBQTRCLENBQWpDLElBQXNDLElBQXRDLEdBQTZDLElBQTdDLEdBQW9ERixDQUEzRDtBQUNIOztBQUVEOzs7Ozs7OEJBR01HLFMsRUFBVztBQUNiLGdCQUFJLENBQUMsS0FBS0MsU0FBVixFQUFxQjtBQUFFLHFCQUFLQSxTQUFMLEdBQWlCRCxTQUFqQjtBQUE0Qjs7QUFFbkQsaUJBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EsZ0JBQU1FLFdBQVdGLFlBQVksS0FBS0MsU0FBbEM7QUFDQSxpQkFBS0UsU0FBTCxHQUFpQixLQUFLNUQsUUFBTCxHQUFnQjJELFFBQWpDOztBQUVBO0FBQ0EsZ0JBQUksS0FBSzFELE9BQUwsQ0FBYXFCLFNBQWpCLEVBQTRCO0FBQ3hCLG9CQUFJLEtBQUtSLFNBQVQsRUFBb0I7QUFDaEIseUJBQUtDLFFBQUwsR0FBZ0IsS0FBS2xCLFFBQUwsR0FBZ0IsS0FBSzZCLFFBQUwsQ0FBY2lDLFFBQWQsRUFBd0IsQ0FBeEIsRUFBMkIsS0FBSzlELFFBQUwsR0FBZ0IsS0FBS0MsTUFBaEQsRUFBd0QsS0FBS0UsUUFBN0QsQ0FBaEM7QUFDSCxpQkFGRCxNQUVPO0FBQ0gseUJBQUtlLFFBQUwsR0FBZ0IsS0FBS1csUUFBTCxDQUFjaUMsUUFBZCxFQUF3QixLQUFLOUQsUUFBN0IsRUFBdUMsS0FBS0MsTUFBTCxHQUFjLEtBQUtELFFBQTFELEVBQW9FLEtBQUtHLFFBQXpFLENBQWhCO0FBQ0g7QUFDSixhQU5ELE1BTU87QUFDSCxvQkFBSSxLQUFLYyxTQUFULEVBQW9CO0FBQ2hCLHlCQUFLQyxRQUFMLEdBQWdCLEtBQUtsQixRQUFMLEdBQWlCLENBQUMsS0FBS0EsUUFBTCxHQUFnQixLQUFLQyxNQUF0QixLQUFpQzZELFdBQVcsS0FBSzNELFFBQWpELENBQWpDO0FBQ0gsaUJBRkQsTUFFTztBQUNILHlCQUFLZSxRQUFMLEdBQWdCLEtBQUtsQixRQUFMLEdBQWdCLENBQUMsS0FBS0MsTUFBTCxHQUFjLEtBQUtELFFBQXBCLEtBQWlDOEQsV0FBVyxLQUFLM0QsUUFBakQsQ0FBaEM7QUFDSDtBQUNKOztBQUVEO0FBQ0EsZ0JBQUksS0FBS2MsU0FBVCxFQUFvQjtBQUNoQixxQkFBS0MsUUFBTCxHQUFpQixLQUFLQSxRQUFMLEdBQWdCLEtBQUtqQixNQUF0QixHQUFnQyxLQUFLQSxNQUFyQyxHQUE4QyxLQUFLaUIsUUFBbkU7QUFDSCxhQUZELE1BRU87QUFDSCxxQkFBS0EsUUFBTCxHQUFpQixLQUFLQSxRQUFMLEdBQWdCLEtBQUtqQixNQUF0QixHQUFnQyxLQUFLQSxNQUFyQyxHQUE4QyxLQUFLaUIsUUFBbkU7QUFDSDs7QUFFRDtBQUNBLGlCQUFLQSxRQUFMLEdBQWdCQyxLQUFLNkMsS0FBTCxDQUFXLEtBQUs5QyxRQUFMLEdBQWdCLEtBQUtHLEdBQWhDLElBQXVDLEtBQUtBLEdBQTVEOztBQUVBO0FBQ0EsaUJBQUtFLFVBQUwsQ0FBZ0IsS0FBS0MsWUFBTCxDQUFrQixLQUFLTixRQUF2QixDQUFoQjs7QUFFQTtBQUNBLGdCQUFJNEMsV0FBVyxLQUFLM0QsUUFBcEIsRUFBOEI7QUFDMUIscUJBQUs4RCxHQUFMLEdBQVcsS0FBS0MscUJBQUwsQ0FBMkIsS0FBS0MsS0FBaEMsQ0FBWDtBQUNILGFBRkQsTUFFTztBQUNILG9CQUFJLEtBQUs1QixRQUFULEVBQW1CO0FBQUUseUJBQUtBLFFBQUw7QUFBaUI7QUFDekM7QUFDSjs7QUFFRDs7Ozs7OzhCQUdNQSxRLEVBQVU7QUFDWixpQkFBS0EsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxpQkFBSzBCLEdBQUwsR0FBVyxLQUFLQyxxQkFBTCxDQUEyQixLQUFLQyxLQUFoQyxDQUFYO0FBQ0EsbUJBQU8sQ0FBQyxDQUFSO0FBQ0g7O0FBRUQ7Ozs7OztzQ0FHYztBQUNWLGdCQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLHFCQUFLQSxNQUFMLEdBQWMsQ0FBQyxDQUFmO0FBQ0EscUJBQUtDLG9CQUFMLENBQTBCLEtBQUtKLEdBQS9CO0FBQ0gsYUFIRCxNQUdPO0FBQ0gscUJBQUtHLE1BQUwsR0FBYyxDQUFDLENBQWY7QUFDQSx1QkFBTyxLQUFLUCxTQUFaO0FBQ0EscUJBQUsxRCxRQUFMLEdBQWdCLEtBQUs0RCxTQUFyQjtBQUNBLHFCQUFLL0QsUUFBTCxHQUFnQixLQUFLa0IsUUFBckI7QUFDQSxxQkFBS2dELHFCQUFMLENBQTJCLEtBQUtDLEtBQWhDO0FBQ0g7QUFDSjs7QUFFRDs7Ozs7O2dDQUdRO0FBQ0osaUJBQUtDLE1BQUwsR0FBYyxDQUFDLENBQWY7QUFDQSxtQkFBTyxLQUFLUCxTQUFaO0FBQ0EsaUJBQUs3RCxRQUFMLEdBQWdCLEtBQUtnQixRQUFyQjtBQUNBLGlCQUFLcUQsb0JBQUwsQ0FBMEIsS0FBS0osR0FBL0I7QUFDQSxpQkFBSzFDLFVBQUwsQ0FBZ0IsS0FBS0MsWUFBTCxDQUFrQixLQUFLeEIsUUFBdkIsQ0FBaEI7QUFDSDs7QUFFRDs7Ozs7OytCQUdPc0UsUyxFQUFXO0FBQ2QsaUJBQUtELG9CQUFMLENBQTBCLEtBQUtKLEdBQS9CO0FBQ0EsaUJBQUtHLE1BQUwsR0FBYyxDQUFDLENBQWY7QUFDQSxtQkFBTyxLQUFLUCxTQUFaO0FBQ0EsaUJBQUs3RCxRQUFMLEdBQWdCLEtBQUtrQixRQUFyQjtBQUNBLGlCQUFLakIsTUFBTCxHQUFjYyxPQUFPdUQsU0FBUCxDQUFkO0FBQ0EsaUJBQUtyRCxTQUFMLEdBQWtCLEtBQUtqQixRQUFMLEdBQWdCLEtBQUtDLE1BQXZDO0FBQ0EsaUJBQUtnRSxHQUFMLEdBQVcsS0FBS0MscUJBQUwsQ0FBMkIsS0FBS0MsS0FBaEMsQ0FBWDtBQUNIOzs7Ozs7a0JBR1VwRSxPIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgQ291bnRVcCB7XG4gICAgY29uc3RydWN0b3Ioc3RhcnRWYWwsIGVuZFZhbCwgZGVjaW1hbHMsIGR1cmF0aW9uLCBvcHRpb25zID0ge30sIHBhZ2UgPSBnZXRDdXJyZW50UGFnZXMoKVtnZXRDdXJyZW50UGFnZXMoKS5sZW5ndGggLSAxXSkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHRoaXMsIHtcbiAgICAgICAgICAgIHBhZ2UsXG4gICAgICAgICAgICBzdGFydFZhbCxcbiAgICAgICAgICAgIGVuZFZhbCxcbiAgICAgICAgICAgIGRlY2ltYWxzLFxuICAgICAgICAgICAgZHVyYXRpb24sXG4gICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICB9KVxuICAgICAgICB0aGlzLl9faW5pdCgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5Yid5aeL5YyWXG4gICAgICovXG4gICAgX19pbml0KCkge1xuICAgICAgICB0aGlzLnNldERhdGEgPSB0aGlzLnBhZ2Uuc2V0RGF0YS5iaW5kKHRoaXMucGFnZSlcblxuICAgICAgICB0aGlzLmxhc3RUaW1lID0gMFxuXG4gICAgICAgIC8vIG1lcmdlIG9wdGlvbnNcbiAgICAgICAgdGhpcy5tZXJnZU9wdGlvbnModGhpcy5vcHRpb25zKVxuXG4gICAgICAgIHRoaXMuc3RhcnRWYWwgPSBOdW1iZXIodGhpcy5zdGFydFZhbClcbiAgICAgICAgdGhpcy5jYWNoZVZhbCA9IHRoaXMuc3RhcnRWYWxcbiAgICAgICAgdGhpcy5lbmRWYWwgPSBOdW1iZXIodGhpcy5lbmRWYWwpXG4gICAgICAgIHRoaXMuY291bnREb3duID0gKHRoaXMuc3RhcnRWYWwgPiB0aGlzLmVuZFZhbClcbiAgICAgICAgdGhpcy5mcmFtZVZhbCA9IHRoaXMuc3RhcnRWYWxcbiAgICAgICAgdGhpcy5kZWNpbWFscyA9IE1hdGgubWF4KDAsIHRoaXMuZGVjaW1hbHMgfHwgMClcbiAgICAgICAgdGhpcy5kZWMgPSBNYXRoLnBvdygxMCwgdGhpcy5kZWNpbWFscylcbiAgICAgICAgdGhpcy5kdXJhdGlvbiA9IE51bWJlcih0aGlzLmR1cmF0aW9uKSAqIDEwMDAgfHwgMjAwMFxuXG4gICAgICAgIC8vIGZvcm1hdCBzdGFydFZhbCBvbiBpbml0aWFsaXphdGlvblxuICAgICAgICB0aGlzLnByaW50VmFsdWUodGhpcy5mb3JtYXR0aW5nRm4odGhpcy5zdGFydFZhbCkpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog6buY6K6k5Y+C5pWwXG4gICAgICovXG4gICAgc2V0RGVmYXVsdE9wdGlvbnMoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB1c2VFYXNpbmc6IHRydWUsIC8vIHRvZ2dsZSBlYXNpbmdcbiAgICAgICAgICAgIHVzZUdyb3VwaW5nOiB0cnVlLCAvLyAxLDAwMCwwMDAgdnMgMTAwMDAwMFxuICAgICAgICAgICAgc2VwYXJhdG9yOiBgLGAsIC8vIGNoYXJhY3RlciB0byB1c2UgYXMgYSBzZXBhcmF0b3JcbiAgICAgICAgICAgIGRlY2ltYWw6IGAuYCwgLy8gY2hhcmFjdGVyIHRvIHVzZSBhcyBhIGRlY2ltYWxcbiAgICAgICAgICAgIGVhc2luZ0ZuOiBudWxsLCAvLyBvcHRpb25hbCBjdXN0b20gZWFzaW5nIGNsb3N1cmUgZnVuY3Rpb24sIGRlZmF1bHQgaXMgUm9iZXJ0IFBlbm5lcidzIGVhc2VPdXRFeHBvXG4gICAgICAgICAgICBmb3JtYXR0aW5nRm46IG51bGwsIC8vIG9wdGlvbmFsIGN1c3RvbSBmb3JtYXR0aW5nIGZ1bmN0aW9uLCBkZWZhdWx0IGlzIHRoaXMuZm9ybWF0TnVtYmVyIGJlbG93XG4gICAgICAgICAgICBwcmludFZhbHVlKHZhbHVlKSB7fSwgLy8gcHJpbnRWYWx1ZVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5ZCI5bm25Y+C5pWwXG4gICAgICovXG4gICAgbWVyZ2VPcHRpb25zKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgZGVmYXVsdE9wdGlvbnMgPSB0aGlzLnNldERlZmF1bHRPcHRpb25zKClcblxuICAgICAgICAvLyBleHRlbmQgZGVmYXVsdCBvcHRpb25zIHdpdGggcGFzc2VkIG9wdGlvbnMgb2JqZWN0XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBkZWZhdWx0T3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKGRlZmF1bHRPcHRpb25zLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnNba2V5XSA9IHR5cGVvZiBvcHRpb25zW2tleV0gIT09IGB1bmRlZmluZWRgID8gb3B0aW9uc1trZXldIDogZGVmYXVsdE9wdGlvbnNba2V5XVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zW2tleV0gPT09IGBmdW5jdGlvbmApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zW2tleV0gPSB0aGlzLm9wdGlvbnNba2V5XS5iaW5kKHRoaXMpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5zZXBhcmF0b3IgPT09IGBgKSB7IHRoaXMub3B0aW9ucy51c2VHcm91cGluZyA9ICExIH1cbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucHJlZml4KSB0aGlzLm9wdGlvbnMucHJlZml4ID0gYGBcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuc3VmZml4KSB0aGlzLm9wdGlvbnMuc3VmZml4ID0gYGBcblxuICAgICAgICB0aGlzLmVhc2luZ0ZuID0gdGhpcy5vcHRpb25zLmVhc2luZ0ZuID8gdGhpcy5vcHRpb25zLmVhc2luZ0ZuIDogdGhpcy5lYXNlT3V0RXhwb1xuICAgICAgICB0aGlzLmZvcm1hdHRpbmdGbiA9IHRoaXMub3B0aW9ucy5mb3JtYXR0aW5nRm4gPyB0aGlzLm9wdGlvbnMuZm9ybWF0dGluZ0ZuIDogdGhpcy5mb3JtYXROdW1iZXJcbiAgICAgICAgdGhpcy5wcmludFZhbHVlID0gdGhpcy5vcHRpb25zLnByaW50VmFsdWUgPyB0aGlzLm9wdGlvbnMucHJpbnRWYWx1ZSA6IGZ1bmN0aW9uKCkge31cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDliJvlu7rlrprml7blmahcbiAgICAgKi9cbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoY2FsbGJhY2spIHtcbiAgICAgICAgbGV0IGN1cnJUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKClcbiAgICAgICAgbGV0IHRpbWVUb0NhbGwgPSBNYXRoLm1heCgwLCAxNiAtIChjdXJyVGltZSAtIHRoaXMubGFzdFRpbWUpKVxuICAgICAgICBsZXQgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgY2FsbGJhY2suYmluZCh0aGlzKShjdXJyVGltZSArIHRpbWVUb0NhbGwpXG4gICAgICAgIH0sIHRpbWVUb0NhbGwpXG4gICAgICAgIHRoaXMubGFzdFRpbWUgPSBjdXJyVGltZSArIHRpbWVUb0NhbGxcbiAgICAgICAgcmV0dXJuIHRpbWVvdXRcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmuIXnqbrlrprml7blmahcbiAgICAgKi9cbiAgICBjYW5jZWxBbmltYXRpb25GcmFtZSh0aW1lb3V0KSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOagvOW8j+WMluaVsOWtl1xuICAgICAqL1xuICAgIGZvcm1hdE51bWJlcihuU3RyKSB7XG4gICAgICAgIG5TdHIgPSBuU3RyLnRvRml4ZWQodGhpcy5kZWNpbWFscylcbiAgICAgICAgblN0ciArPSBgYFxuICAgICAgICBsZXQgeCwgeDEsIHgyLCByZ3hcbiAgICAgICAgeCA9IG5TdHIuc3BsaXQoYC5gKVxuICAgICAgICB4MSA9IHhbMF1cbiAgICAgICAgeDIgPSB4Lmxlbmd0aCA+IDEgPyB0aGlzLm9wdGlvbnMuZGVjaW1hbCArIHhbMV0gOiBgYFxuICAgICAgICByZ3ggPSAvKFxcZCspKFxcZHszfSkvXG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMudXNlR3JvdXBpbmcpIHtcbiAgICAgICAgICAgIHdoaWxlIChyZ3gudGVzdCh4MSkpIHtcbiAgICAgICAgICAgICAgICB4MSA9IHgxLnJlcGxhY2Uocmd4LCBgJDFgICsgdGhpcy5vcHRpb25zLnNlcGFyYXRvciArIGAkMmApXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5wcmVmaXggKyB4MSArIHgyICsgdGhpcy5vcHRpb25zLnN1ZmZpeFxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOi/h+a4oeaViOaenFxuICAgICAqL1xuICAgIGVhc2VPdXRFeHBvKHQsIGIsIGMsIGQpIHtcbiAgICAgICAgcmV0dXJuIGMgKiAoLU1hdGgucG93KDIsIC0xMCAqIHQgLyBkKSArIDEpICogMTAyNCAvIDEwMjMgKyBiXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog6K6h5pWw5Ye95pWwXG4gICAgICovXG4gICAgY291bnQodGltZXN0YW1wKSB7XG4gICAgICAgIGlmICghdGhpcy5zdGFydFRpbWUpIHsgdGhpcy5zdGFydFRpbWUgPSB0aW1lc3RhbXAgfVxuXG4gICAgICAgIHRoaXMudGltZXN0YW1wID0gdGltZXN0YW1wXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gdGltZXN0YW1wIC0gdGhpcy5zdGFydFRpbWVcbiAgICAgICAgdGhpcy5yZW1haW5pbmcgPSB0aGlzLmR1cmF0aW9uIC0gcHJvZ3Jlc3NcblxuICAgICAgICAvLyB0byBlYXNlIG9yIG5vdCB0byBlYXNlXG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMudXNlRWFzaW5nKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5jb3VudERvd24pIHtcbiAgICAgICAgICAgICAgICB0aGlzLmZyYW1lVmFsID0gdGhpcy5zdGFydFZhbCAtIHRoaXMuZWFzaW5nRm4ocHJvZ3Jlc3MsIDAsIHRoaXMuc3RhcnRWYWwgLSB0aGlzLmVuZFZhbCwgdGhpcy5kdXJhdGlvbilcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mcmFtZVZhbCA9IHRoaXMuZWFzaW5nRm4ocHJvZ3Jlc3MsIHRoaXMuc3RhcnRWYWwsIHRoaXMuZW5kVmFsIC0gdGhpcy5zdGFydFZhbCwgdGhpcy5kdXJhdGlvbilcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmNvdW50RG93bikge1xuICAgICAgICAgICAgICAgIHRoaXMuZnJhbWVWYWwgPSB0aGlzLnN0YXJ0VmFsIC0gKCh0aGlzLnN0YXJ0VmFsIC0gdGhpcy5lbmRWYWwpICogKHByb2dyZXNzIC8gdGhpcy5kdXJhdGlvbikpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuZnJhbWVWYWwgPSB0aGlzLnN0YXJ0VmFsICsgKHRoaXMuZW5kVmFsIC0gdGhpcy5zdGFydFZhbCkgKiAocHJvZ3Jlc3MgLyB0aGlzLmR1cmF0aW9uKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZG9uJ3QgZ28gcGFzdCBlbmRWYWwgc2luY2UgcHJvZ3Jlc3MgY2FuIGV4Y2VlZCBkdXJhdGlvbiBpbiB0aGUgbGFzdCBmcmFtZVxuICAgICAgICBpZiAodGhpcy5jb3VudERvd24pIHtcbiAgICAgICAgICAgIHRoaXMuZnJhbWVWYWwgPSAodGhpcy5mcmFtZVZhbCA8IHRoaXMuZW5kVmFsKSA/IHRoaXMuZW5kVmFsIDogdGhpcy5mcmFtZVZhbFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5mcmFtZVZhbCA9ICh0aGlzLmZyYW1lVmFsID4gdGhpcy5lbmRWYWwpID8gdGhpcy5lbmRWYWwgOiB0aGlzLmZyYW1lVmFsXG4gICAgICAgIH1cblxuICAgICAgICAvLyBkZWNpbWFsXG4gICAgICAgIHRoaXMuZnJhbWVWYWwgPSBNYXRoLnJvdW5kKHRoaXMuZnJhbWVWYWwgKiB0aGlzLmRlYykgLyB0aGlzLmRlY1xuXG4gICAgICAgIC8vIGZvcm1hdCBhbmQgcHJpbnQgdmFsdWVcbiAgICAgICAgdGhpcy5wcmludFZhbHVlKHRoaXMuZm9ybWF0dGluZ0ZuKHRoaXMuZnJhbWVWYWwpKVxuXG4gICAgICAgIC8vIHdoZXRoZXIgdG8gY29udGludWVcbiAgICAgICAgaWYgKHByb2dyZXNzIDwgdGhpcy5kdXJhdGlvbikge1xuICAgICAgICAgICAgdGhpcy5yQUYgPSB0aGlzLnJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLmNvdW50KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKHRoaXMuY2FsbGJhY2spIHsgdGhpcy5jYWxsYmFjaygpIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOWQr+WKqOiuoeaVsOWZqFxuICAgICAqL1xuICAgIHN0YXJ0KGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuY2FsbGJhY2sgPSBjYWxsYmFja1xuICAgICAgICB0aGlzLnJBRiA9IHRoaXMucmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRoaXMuY291bnQpXG4gICAgICAgIHJldHVybiAhMVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOWBnOatouiuoeaVsOWZqFxuICAgICAqL1xuICAgIHBhdXNlUmVzdW1lKCkge1xuICAgICAgICBpZiAoIXRoaXMucGF1c2VkKSB7XG4gICAgICAgICAgICB0aGlzLnBhdXNlZCA9ICEwXG4gICAgICAgICAgICB0aGlzLmNhbmNlbEFuaW1hdGlvbkZyYW1lKHRoaXMuckFGKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5wYXVzZWQgPSAhMVxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuc3RhcnRUaW1lXG4gICAgICAgICAgICB0aGlzLmR1cmF0aW9uID0gdGhpcy5yZW1haW5pbmdcbiAgICAgICAgICAgIHRoaXMuc3RhcnRWYWwgPSB0aGlzLmZyYW1lVmFsXG4gICAgICAgICAgICB0aGlzLnJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLmNvdW50KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog6YeN572u6K6h5pWw5ZmoXG4gICAgICovXG4gICAgcmVzZXQoKSB7XG4gICAgICAgIHRoaXMucGF1c2VkID0gITFcbiAgICAgICAgZGVsZXRlIHRoaXMuc3RhcnRUaW1lXG4gICAgICAgIHRoaXMuc3RhcnRWYWwgPSB0aGlzLmNhY2hlVmFsXG4gICAgICAgIHRoaXMuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5yQUYpXG4gICAgICAgIHRoaXMucHJpbnRWYWx1ZSh0aGlzLmZvcm1hdHRpbmdGbih0aGlzLnN0YXJ0VmFsKSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmm7TmlrDorqHmlbDlmahcbiAgICAgKi9cbiAgICB1cGRhdGUobmV3RW5kVmFsKSB7XG4gICAgICAgIHRoaXMuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5yQUYpXG4gICAgICAgIHRoaXMucGF1c2VkID0gITFcbiAgICAgICAgZGVsZXRlIHRoaXMuc3RhcnRUaW1lXG4gICAgICAgIHRoaXMuc3RhcnRWYWwgPSB0aGlzLmZyYW1lVmFsXG4gICAgICAgIHRoaXMuZW5kVmFsID0gTnVtYmVyKG5ld0VuZFZhbClcbiAgICAgICAgdGhpcy5jb3VudERvd24gPSAodGhpcy5zdGFydFZhbCA+IHRoaXMuZW5kVmFsKVxuICAgICAgICB0aGlzLnJBRiA9IHRoaXMucmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRoaXMuY291bnQpXG4gICAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb3VudFVwIl19