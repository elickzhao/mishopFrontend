'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
    'use strict';

    var hasOwn = {}.hasOwnProperty;

    function classNames() {
        var classes = [];

        for (var i = 0; i < arguments.length; i++) {
            var arg = arguments[i];
            if (!arg) continue;

            var argType = typeof arg === 'undefined' ? 'undefined' : _typeof(arg);

            if (argType === 'string' || argType === 'number') {
                classes.push(arg);
            } else if (Array.isArray(arg) && arg.length) {
                var inner = classNames.apply(null, arg);
                if (inner) {
                    classes.push(inner);
                }
            } else if (argType === 'object') {
                for (var key in arg) {
                    if (hasOwn.call(arg, key) && arg[key]) {
                        classes.push(key);
                    }
                }
            }
        }

        return classes.join(' ');
    }

    if (typeof module !== 'undefined' && module.exports) {
        classNames.default = classNames;
        module.exports = classNames;
    } else if (typeof define === 'function' && _typeof(define.amd) === 'object' && define.amd) {
        // register as 'classnames', consistent with npm package name
        define('classnames', [], function () {
            return classNames;
        });
    } else {
        window.classNames = classNames;
    }
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNsYXNzTmFtZXMuanMiXSwibmFtZXMiOlsiaGFzT3duIiwiaGFzT3duUHJvcGVydHkiLCJjbGFzc05hbWVzIiwiY2xhc3NlcyIsImkiLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJhcmciLCJhcmdUeXBlIiwicHVzaCIsIkFycmF5IiwiaXNBcnJheSIsImlubmVyIiwiYXBwbHkiLCJrZXkiLCJjYWxsIiwiam9pbiIsIm1vZHVsZSIsImV4cG9ydHMiLCJkZWZhdWx0IiwiZGVmaW5lIiwiYW1kIiwid2luZG93Il0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7Ozs7O0FBS0E7O0FBRUMsYUFBVztBQUNSOztBQUVBLFFBQUlBLFNBQVMsR0FBR0MsY0FBaEI7O0FBRUEsYUFBU0MsVUFBVCxHQUFzQjtBQUNsQixZQUFJQyxVQUFVLEVBQWQ7O0FBRUEsYUFBSyxJQUFJQyxJQUFJLENBQWIsRUFBZ0JBLElBQUlDLFVBQVVDLE1BQTlCLEVBQXNDRixHQUF0QyxFQUEyQztBQUN2QyxnQkFBSUcsTUFBTUYsVUFBVUQsQ0FBVixDQUFWO0FBQ0EsZ0JBQUksQ0FBQ0csR0FBTCxFQUFVOztBQUVWLGdCQUFJQyxpQkFBaUJELEdBQWpCLHlDQUFpQkEsR0FBakIsQ0FBSjs7QUFFQSxnQkFBSUMsWUFBWSxRQUFaLElBQXdCQSxZQUFZLFFBQXhDLEVBQWtEO0FBQzlDTCx3QkFBUU0sSUFBUixDQUFhRixHQUFiO0FBQ0gsYUFGRCxNQUVPLElBQUlHLE1BQU1DLE9BQU4sQ0FBY0osR0FBZCxLQUFzQkEsSUFBSUQsTUFBOUIsRUFBc0M7QUFDekMsb0JBQUlNLFFBQVFWLFdBQVdXLEtBQVgsQ0FBaUIsSUFBakIsRUFBdUJOLEdBQXZCLENBQVo7QUFDQSxvQkFBSUssS0FBSixFQUFXO0FBQ1BULDRCQUFRTSxJQUFSLENBQWFHLEtBQWI7QUFDSDtBQUNKLGFBTE0sTUFLQSxJQUFJSixZQUFZLFFBQWhCLEVBQTBCO0FBQzdCLHFCQUFLLElBQUlNLEdBQVQsSUFBZ0JQLEdBQWhCLEVBQXFCO0FBQ2pCLHdCQUFJUCxPQUFPZSxJQUFQLENBQVlSLEdBQVosRUFBaUJPLEdBQWpCLEtBQXlCUCxJQUFJTyxHQUFKLENBQTdCLEVBQXVDO0FBQ25DWCxnQ0FBUU0sSUFBUixDQUFhSyxHQUFiO0FBQ0g7QUFDSjtBQUNKO0FBQ0o7O0FBRUQsZUFBT1gsUUFBUWEsSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUNIOztBQUVELFFBQUksT0FBT0MsTUFBUCxLQUFrQixXQUFsQixJQUFpQ0EsT0FBT0MsT0FBNUMsRUFBcUQ7QUFDakRoQixtQkFBV2lCLE9BQVgsR0FBcUJqQixVQUFyQjtBQUNBZSxlQUFPQyxPQUFQLEdBQWlCaEIsVUFBakI7QUFDSCxLQUhELE1BR08sSUFBSSxPQUFPa0IsTUFBUCxLQUFrQixVQUFsQixJQUFnQyxRQUFPQSxPQUFPQyxHQUFkLE1BQXNCLFFBQXRELElBQWtFRCxPQUFPQyxHQUE3RSxFQUFrRjtBQUNyRjtBQUNBRCxlQUFPLFlBQVAsRUFBcUIsRUFBckIsRUFBeUIsWUFBVztBQUNoQyxtQkFBT2xCLFVBQVA7QUFDSCxTQUZEO0FBR0gsS0FMTSxNQUtBO0FBQ0hvQixlQUFPcEIsVUFBUCxHQUFvQkEsVUFBcEI7QUFDSDtBQUNKLENBNUNBLEdBQUQiLCJmaWxlIjoiY2xhc3NOYW1lcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICBDb3B5cmlnaHQgKGMpIDIwMTggSmVkIFdhdHNvbi5cbiAgTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlIChNSVQpLCBzZWVcbiAgaHR0cDovL2plZHdhdHNvbi5naXRodWIuaW8vY2xhc3NuYW1lc1xuKi9cbi8qIGdsb2JhbCBkZWZpbmUgKi9cblxuKGZ1bmN0aW9uKCkge1xuICAgICd1c2Ugc3RyaWN0JztcblxuICAgIHZhciBoYXNPd24gPSB7fS5oYXNPd25Qcm9wZXJ0eTtcblxuICAgIGZ1bmN0aW9uIGNsYXNzTmFtZXMoKSB7XG4gICAgICAgIHZhciBjbGFzc2VzID0gW107XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBhcmcgPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICBpZiAoIWFyZykgY29udGludWU7XG5cbiAgICAgICAgICAgIHZhciBhcmdUeXBlID0gdHlwZW9mIGFyZztcblxuICAgICAgICAgICAgaWYgKGFyZ1R5cGUgPT09ICdzdHJpbmcnIHx8IGFyZ1R5cGUgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgY2xhc3Nlcy5wdXNoKGFyZyk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoYXJnKSAmJiBhcmcubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgdmFyIGlubmVyID0gY2xhc3NOYW1lcy5hcHBseShudWxsLCBhcmcpO1xuICAgICAgICAgICAgICAgIGlmIChpbm5lcikge1xuICAgICAgICAgICAgICAgICAgICBjbGFzc2VzLnB1c2goaW5uZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoYXJnVHlwZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gYXJnKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoYXNPd24uY2FsbChhcmcsIGtleSkgJiYgYXJnW2tleV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzZXMucHVzaChrZXkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGNsYXNzZXMuam9pbignICcpO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2YgbW9kdWxlICE9PSAndW5kZWZpbmVkJyAmJiBtb2R1bGUuZXhwb3J0cykge1xuICAgICAgICBjbGFzc05hbWVzLmRlZmF1bHQgPSBjbGFzc05hbWVzO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IGNsYXNzTmFtZXM7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBkZWZpbmUuYW1kID09PSAnb2JqZWN0JyAmJiBkZWZpbmUuYW1kKSB7XG4gICAgICAgIC8vIHJlZ2lzdGVyIGFzICdjbGFzc25hbWVzJywgY29uc2lzdGVudCB3aXRoIG5wbSBwYWNrYWdlIG5hbWVcbiAgICAgICAgZGVmaW5lKCdjbGFzc25hbWVzJywgW10sIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNsYXNzTmFtZXM7XG4gICAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHdpbmRvdy5jbGFzc05hbWVzID0gY2xhc3NOYW1lcztcbiAgICB9XG59KCkpOyJdfQ==