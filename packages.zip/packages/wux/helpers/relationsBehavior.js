'use strict';

var _isEmpty = require('./isEmpty.js');

var _isEmpty2 = _interopRequireDefault(_isEmpty);

var _debounce = require('./debounce.js');

var _debounce2 = _interopRequireDefault(_debounce);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * bind func to obj
 */
function bindFunc(obj, method, observer) {
    var oldFn = obj[method];
    obj[method] = function (target) {
        if (observer) {
            observer.call(this, target, _defineProperty({}, method, true));
        }
        if (oldFn) {
            oldFn.call(this, target);
        }
    };
}

// default methods
var methods = ['linked', 'linkChanged', 'unlinked'];

// extra props
var extProps = ['observer'];

module.exports = Behavior({
    lifetimes: {
        created: function created() {
            this._debounce = null;
        }
    },
    definitionFilter: function definitionFilter(defFields) {
        var relations = defFields.relations;


        if (!(0, _isEmpty2.default)(relations)) {
            var _loop = function _loop(key) {
                var relation = relations[key];

                // bind func
                methods.forEach(function (method) {
                    return bindFunc(relation, method, relation.observer);
                });

                // delete extProps
                extProps.forEach(function (prop) {
                    return delete relation[prop];
                });
            };

            for (var key in relations) {
                _loop(key);
            }
        }

        defFields.methods = defFields.methods || {};
        defFields.methods.debounce = function (func) {
            var wait = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
            var immediate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

            return (this._debounce = this._debounce || (0, _debounce2.default)(func.bind(this), wait, immediate)).call(this);
        };
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlbGF0aW9uc0JlaGF2aW9yLmpzIl0sIm5hbWVzIjpbImJpbmRGdW5jIiwib2JqIiwibWV0aG9kIiwib2JzZXJ2ZXIiLCJvbGRGbiIsInRhcmdldCIsImNhbGwiLCJtZXRob2RzIiwiZXh0UHJvcHMiLCJtb2R1bGUiLCJleHBvcnRzIiwiQmVoYXZpb3IiLCJsaWZldGltZXMiLCJjcmVhdGVkIiwiX2RlYm91bmNlIiwiZGVmaW5pdGlvbkZpbHRlciIsImRlZkZpZWxkcyIsInJlbGF0aW9ucyIsImtleSIsInJlbGF0aW9uIiwiZm9yRWFjaCIsInByb3AiLCJkZWJvdW5jZSIsImZ1bmMiLCJ3YWl0IiwiaW1tZWRpYXRlIiwiYmluZCJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7OztBQUNBOzs7Ozs7OztBQUVBOzs7QUFHQSxTQUFTQSxRQUFULENBQWtCQyxHQUFsQixFQUF1QkMsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ3JDLFFBQU1DLFFBQVFILElBQUlDLE1BQUosQ0FBZDtBQUNBRCxRQUFJQyxNQUFKLElBQWMsVUFBU0csTUFBVCxFQUFpQjtBQUMzQixZQUFJRixRQUFKLEVBQWM7QUFDVkEscUJBQVNHLElBQVQsQ0FBYyxJQUFkLEVBQW9CRCxNQUFwQixzQkFDS0gsTUFETCxFQUNjLElBRGQ7QUFHSDtBQUNELFlBQUlFLEtBQUosRUFBVztBQUNQQSxrQkFBTUUsSUFBTixDQUFXLElBQVgsRUFBaUJELE1BQWpCO0FBQ0g7QUFDSixLQVREO0FBVUg7O0FBRUQ7QUFDQSxJQUFNRSxVQUFVLENBQUMsUUFBRCxFQUFXLGFBQVgsRUFBMEIsVUFBMUIsQ0FBaEI7O0FBRUE7QUFDQSxJQUFNQyxXQUFXLENBQUMsVUFBRCxDQUFqQjs7QUFFQUMsT0FBT0MsT0FBUCxHQUFpQkMsU0FBUztBQUN0QkMsZUFBVztBQUNQQyxlQURPLHFCQUNHO0FBQ04saUJBQUtDLFNBQUwsR0FBaUIsSUFBakI7QUFDSDtBQUhNLEtBRFc7QUFNdEJDLG9CQU5zQiw0QkFNTEMsU0FOSyxFQU1NO0FBQUEsWUFDaEJDLFNBRGdCLEdBQ0ZELFNBREUsQ0FDaEJDLFNBRGdCOzs7QUFHeEIsWUFBSSxDQUFDLHVCQUFRQSxTQUFSLENBQUwsRUFBeUI7QUFBQSx1Q0FDVkMsR0FEVTtBQUVqQixvQkFBTUMsV0FBV0YsVUFBVUMsR0FBVixDQUFqQjs7QUFFQTtBQUNBWCx3QkFBUWEsT0FBUixDQUFnQixVQUFDbEIsTUFBRDtBQUFBLDJCQUFZRixTQUFTbUIsUUFBVCxFQUFtQmpCLE1BQW5CLEVBQTJCaUIsU0FBU2hCLFFBQXBDLENBQVo7QUFBQSxpQkFBaEI7O0FBRUE7QUFDQUsseUJBQVNZLE9BQVQsQ0FBaUIsVUFBQ0MsSUFBRDtBQUFBLDJCQUFVLE9BQU9GLFNBQVNFLElBQVQsQ0FBakI7QUFBQSxpQkFBakI7QUFSaUI7O0FBQ3JCLGlCQUFLLElBQU1ILEdBQVgsSUFBa0JELFNBQWxCLEVBQTZCO0FBQUEsc0JBQWxCQyxHQUFrQjtBQVE1QjtBQUNKOztBQUVERixrQkFBVVQsT0FBVixHQUFvQlMsVUFBVVQsT0FBVixJQUFxQixFQUF6QztBQUNBUyxrQkFBVVQsT0FBVixDQUFrQmUsUUFBbEIsR0FBNkIsVUFBU0MsSUFBVCxFQUE0QztBQUFBLGdCQUE3QkMsSUFBNkIsdUVBQXRCLENBQXNCO0FBQUEsZ0JBQW5CQyxTQUFtQix1RUFBUCxLQUFPOztBQUNyRSxtQkFBTyxDQUFDLEtBQUtYLFNBQUwsR0FBaUIsS0FBS0EsU0FBTCxJQUFrQix3QkFBU1MsS0FBS0csSUFBTCxDQUFVLElBQVYsQ0FBVCxFQUEwQkYsSUFBMUIsRUFBZ0NDLFNBQWhDLENBQXBDLEVBQWdGbkIsSUFBaEYsQ0FBcUYsSUFBckYsQ0FBUDtBQUNILFNBRkQ7QUFHSDtBQXpCcUIsQ0FBVCxDQUFqQiIsImZpbGUiOiJyZWxhdGlvbnNCZWhhdmlvci5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBpc0VtcHR5IGZyb20gJy4vaXNFbXB0eSdcbmltcG9ydCBkZWJvdW5jZSBmcm9tICcuL2RlYm91bmNlJ1xuXG4vKipcbiAqIGJpbmQgZnVuYyB0byBvYmpcbiAqL1xuZnVuY3Rpb24gYmluZEZ1bmMob2JqLCBtZXRob2QsIG9ic2VydmVyKSB7XG4gICAgY29uc3Qgb2xkRm4gPSBvYmpbbWV0aG9kXVxuICAgIG9ialttZXRob2RdID0gZnVuY3Rpb24odGFyZ2V0KSB7XG4gICAgICAgIGlmIChvYnNlcnZlcikge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuY2FsbCh0aGlzLCB0YXJnZXQsIHtcbiAgICAgICAgICAgICAgICBbbWV0aG9kXTogdHJ1ZSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9sZEZuKSB7XG4gICAgICAgICAgICBvbGRGbi5jYWxsKHRoaXMsIHRhcmdldClcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gZGVmYXVsdCBtZXRob2RzXG5jb25zdCBtZXRob2RzID0gWydsaW5rZWQnLCAnbGlua0NoYW5nZWQnLCAndW5saW5rZWQnXVxuXG4vLyBleHRyYSBwcm9wc1xuY29uc3QgZXh0UHJvcHMgPSBbJ29ic2VydmVyJ11cblxubW9kdWxlLmV4cG9ydHMgPSBCZWhhdmlvcih7XG4gICAgbGlmZXRpbWVzOiB7XG4gICAgICAgIGNyZWF0ZWQoKSB7XG4gICAgICAgICAgICB0aGlzLl9kZWJvdW5jZSA9IG51bGxcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIGRlZmluaXRpb25GaWx0ZXIoZGVmRmllbGRzKSB7XG4gICAgICAgIGNvbnN0IHsgcmVsYXRpb25zIH0gPSBkZWZGaWVsZHNcblxuICAgICAgICBpZiAoIWlzRW1wdHkocmVsYXRpb25zKSkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gcmVsYXRpb25zKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVsYXRpb24gPSByZWxhdGlvbnNba2V5XVxuXG4gICAgICAgICAgICAgICAgLy8gYmluZCBmdW5jXG4gICAgICAgICAgICAgICAgbWV0aG9kcy5mb3JFYWNoKChtZXRob2QpID0+IGJpbmRGdW5jKHJlbGF0aW9uLCBtZXRob2QsIHJlbGF0aW9uLm9ic2VydmVyKSlcblxuICAgICAgICAgICAgICAgIC8vIGRlbGV0ZSBleHRQcm9wc1xuICAgICAgICAgICAgICAgIGV4dFByb3BzLmZvckVhY2goKHByb3ApID0+IGRlbGV0ZSByZWxhdGlvbltwcm9wXSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGRlZkZpZWxkcy5tZXRob2RzID0gZGVmRmllbGRzLm1ldGhvZHMgfHwge31cbiAgICAgICAgZGVmRmllbGRzLm1ldGhvZHMuZGVib3VuY2UgPSBmdW5jdGlvbihmdW5jLCB3YWl0ID0gMCwgaW1tZWRpYXRlID0gZmFsc2UpIHtcbiAgICAgICAgICAgIHJldHVybiAodGhpcy5fZGVib3VuY2UgPSB0aGlzLl9kZWJvdW5jZSB8fCBkZWJvdW5jZShmdW5jLmJpbmQodGhpcyksIHdhaXQsIGltbWVkaWF0ZSkpLmNhbGwodGhpcylcbiAgICAgICAgfVxuICAgIH0sXG59KVxuIl19