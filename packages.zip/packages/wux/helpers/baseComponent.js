'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _computedBehavior = require('./computedBehavior.js');

var _computedBehavior2 = _interopRequireDefault(_computedBehavior);

var _relationsBehavior = require('./relationsBehavior.js');

var _relationsBehavior2 = _interopRequireDefault(_relationsBehavior);

var _safeSetDataBehavior = require('./safeSetDataBehavior.js');

var _safeSetDataBehavior2 = _interopRequireDefault(_safeSetDataBehavior);

var _funcBehavior = require('./funcBehavior.js');

var _funcBehavior2 = _interopRequireDefault(_funcBehavior);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var baseComponent = function baseComponent() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    // add default externalClasses
    options.externalClasses = ['wux-class', 'wux-hover-class'].concat(_toConsumableArray(options.externalClasses = options.externalClasses || []));

    // add default behaviors
    options.behaviors = [_relationsBehavior2.default, _computedBehavior2.default, _safeSetDataBehavior2.default].concat(_toConsumableArray(options.behaviors = options.behaviors || []));

    // use func
    if (options.useFunc) {
        options.behaviors = [].concat(_toConsumableArray(options.behaviors), [_funcBehavior2.default]);
        delete options.useFunc;
    }

    // use field
    if (options.useField) {
        options.behaviors = [].concat(_toConsumableArray(options.behaviors), ['wx://form-field']);
        delete options.useField;
    }

    // use export
    if (options.useExport) {
        options.behaviors = [].concat(_toConsumableArray(options.behaviors), ['wx://component-export']);
        options.methods = _extends({
            export: function _export() {
                return this;
            }
        }, options.methods);
        delete options.useExport;
    }

    // add default options
    options.options = _extends({
        multipleSlots: true,
        addGlobalClass: true
    }, options.options);

    return Component(options);
};

exports.default = baseComponent;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhc2VDb21wb25lbnQuanMiXSwibmFtZXMiOlsiYmFzZUNvbXBvbmVudCIsIm9wdGlvbnMiLCJleHRlcm5hbENsYXNzZXMiLCJiZWhhdmlvcnMiLCJyZWxhdGlvbnNCZWhhdmlvciIsImNvbXB1dGVkQmVoYXZpb3IiLCJzYWZlU2V0RGF0YUJlaGF2aW9yIiwidXNlRnVuYyIsImZ1bmNCZWhhdmlvciIsInVzZUZpZWxkIiwidXNlRXhwb3J0IiwibWV0aG9kcyIsImV4cG9ydCIsIm11bHRpcGxlU2xvdHMiLCJhZGRHbG9iYWxDbGFzcyIsIkNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7QUFFQSxJQUFNQSxnQkFBZ0IsU0FBaEJBLGFBQWdCLEdBQWtCO0FBQUEsUUFBakJDLE9BQWlCLHVFQUFQLEVBQU87O0FBQ3BDO0FBQ0FBLFlBQVFDLGVBQVIsSUFDSSxXQURKLEVBRUksaUJBRkosNEJBR1FELFFBQVFDLGVBQVIsR0FBMEJELFFBQVFDLGVBQVIsSUFBMkIsRUFIN0Q7O0FBTUE7QUFDQUQsWUFBUUUsU0FBUixJQUNJQywyQkFESixFQUVJQywwQkFGSixFQUdJQyw2QkFISiw0QkFJUUwsUUFBUUUsU0FBUixHQUFvQkYsUUFBUUUsU0FBUixJQUFxQixFQUpqRDs7QUFPQTtBQUNBLFFBQUlGLFFBQVFNLE9BQVosRUFBcUI7QUFDakJOLGdCQUFRRSxTQUFSLGdDQUF3QkYsUUFBUUUsU0FBaEMsSUFBMkNLLHNCQUEzQztBQUNBLGVBQU9QLFFBQVFNLE9BQWY7QUFDSDs7QUFFRDtBQUNBLFFBQUlOLFFBQVFRLFFBQVosRUFBc0I7QUFDbEJSLGdCQUFRRSxTQUFSLGdDQUF3QkYsUUFBUUUsU0FBaEMsSUFBMkMsaUJBQTNDO0FBQ0EsZUFBT0YsUUFBUVEsUUFBZjtBQUNIOztBQUVEO0FBQ0EsUUFBSVIsUUFBUVMsU0FBWixFQUF1QjtBQUNuQlQsZ0JBQVFFLFNBQVIsZ0NBQXdCRixRQUFRRSxTQUFoQyxJQUEyQyx1QkFBM0M7QUFDQUYsZ0JBQVFVLE9BQVI7QUFDSUMsa0JBREoscUJBQ2M7QUFDTix1QkFBTyxJQUFQO0FBQ0g7QUFITCxXQUlPWCxRQUFRVSxPQUpmO0FBTUEsZUFBT1YsUUFBUVMsU0FBZjtBQUNIOztBQUVEO0FBQ0FULFlBQVFBLE9BQVI7QUFDSVksdUJBQWUsSUFEbkI7QUFFSUMsd0JBQWdCO0FBRnBCLE9BR09iLFFBQVFBLE9BSGY7O0FBTUEsV0FBT2MsVUFBVWQsT0FBVixDQUFQO0FBQ0gsQ0FoREQ7O2tCQWtEZUQsYSIsImZpbGUiOiJiYXNlQ29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGNvbXB1dGVkQmVoYXZpb3IgZnJvbSAnLi9jb21wdXRlZEJlaGF2aW9yJ1xuaW1wb3J0IHJlbGF0aW9uc0JlaGF2aW9yIGZyb20gJy4vcmVsYXRpb25zQmVoYXZpb3InXG5pbXBvcnQgc2FmZVNldERhdGFCZWhhdmlvciBmcm9tICcuL3NhZmVTZXREYXRhQmVoYXZpb3InXG5pbXBvcnQgZnVuY0JlaGF2aW9yIGZyb20gJy4vZnVuY0JlaGF2aW9yJ1xuXG5jb25zdCBiYXNlQ29tcG9uZW50ID0gKG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIC8vIGFkZCBkZWZhdWx0IGV4dGVybmFsQ2xhc3Nlc1xuICAgIG9wdGlvbnMuZXh0ZXJuYWxDbGFzc2VzID0gW1xuICAgICAgICAnd3V4LWNsYXNzJyxcbiAgICAgICAgJ3d1eC1ob3Zlci1jbGFzcycsXG4gICAgICAgIC4uLihvcHRpb25zLmV4dGVybmFsQ2xhc3NlcyA9IG9wdGlvbnMuZXh0ZXJuYWxDbGFzc2VzIHx8IFtdKSxcbiAgICBdXG5cbiAgICAvLyBhZGQgZGVmYXVsdCBiZWhhdmlvcnNcbiAgICBvcHRpb25zLmJlaGF2aW9ycyA9IFtcbiAgICAgICAgcmVsYXRpb25zQmVoYXZpb3IsXG4gICAgICAgIGNvbXB1dGVkQmVoYXZpb3IsXG4gICAgICAgIHNhZmVTZXREYXRhQmVoYXZpb3IsXG4gICAgICAgIC4uLihvcHRpb25zLmJlaGF2aW9ycyA9IG9wdGlvbnMuYmVoYXZpb3JzIHx8IFtdKSxcbiAgICBdXG5cbiAgICAvLyB1c2UgZnVuY1xuICAgIGlmIChvcHRpb25zLnVzZUZ1bmMpIHtcbiAgICAgICAgb3B0aW9ucy5iZWhhdmlvcnMgPSBbLi4ub3B0aW9ucy5iZWhhdmlvcnMsIGZ1bmNCZWhhdmlvcl1cbiAgICAgICAgZGVsZXRlIG9wdGlvbnMudXNlRnVuY1xuICAgIH1cblxuICAgIC8vIHVzZSBmaWVsZFxuICAgIGlmIChvcHRpb25zLnVzZUZpZWxkKSB7XG4gICAgICAgIG9wdGlvbnMuYmVoYXZpb3JzID0gWy4uLm9wdGlvbnMuYmVoYXZpb3JzLCAnd3g6Ly9mb3JtLWZpZWxkJ11cbiAgICAgICAgZGVsZXRlIG9wdGlvbnMudXNlRmllbGRcbiAgICB9XG5cbiAgICAvLyB1c2UgZXhwb3J0XG4gICAgaWYgKG9wdGlvbnMudXNlRXhwb3J0KSB7XG4gICAgICAgIG9wdGlvbnMuYmVoYXZpb3JzID0gWy4uLm9wdGlvbnMuYmVoYXZpb3JzLCAnd3g6Ly9jb21wb25lbnQtZXhwb3J0J11cbiAgICAgICAgb3B0aW9ucy5tZXRob2RzID0ge1xuICAgICAgICAgICAgZXhwb3J0ICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMubWV0aG9kcyxcbiAgICAgICAgfVxuICAgICAgICBkZWxldGUgb3B0aW9ucy51c2VFeHBvcnRcbiAgICB9XG5cbiAgICAvLyBhZGQgZGVmYXVsdCBvcHRpb25zXG4gICAgb3B0aW9ucy5vcHRpb25zID0ge1xuICAgICAgICBtdWx0aXBsZVNsb3RzOiB0cnVlLFxuICAgICAgICBhZGRHbG9iYWxDbGFzczogdHJ1ZSxcbiAgICAgICAgLi4ub3B0aW9ucy5vcHRpb25zLFxuICAgIH1cblxuICAgIHJldHVybiBDb21wb25lbnQob3B0aW9ucylcbn1cblxuZXhwb3J0IGRlZmF1bHQgYmFzZUNvbXBvbmVudFxuIl19