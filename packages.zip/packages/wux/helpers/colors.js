'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
var colors = exports.colors = {
    'light': '#ddd',
    'stable': '#b2b2b2',
    'positive': '#387ef5',
    'calm': '#11c1f3',
    'balanced': '#33cd5f',
    'energized': '#ffc900',
    'assertive': '#ef473a',
    'royal': '#886aea',
    'dark': '#444'
};

var isPresetColor = exports.isPresetColor = function isPresetColor(color) {
    if (!color) {
        return false;
    }
    return colors[color] ? colors[color] : color;
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbG9ycy5qcyJdLCJuYW1lcyI6WyJjb2xvcnMiLCJpc1ByZXNldENvbG9yIiwiY29sb3IiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQU8sSUFBTUEsMEJBQVM7QUFDbEIsYUFBUyxNQURTO0FBRWxCLGNBQVUsU0FGUTtBQUdsQixnQkFBWSxTQUhNO0FBSWxCLFlBQVEsU0FKVTtBQUtsQixnQkFBWSxTQUxNO0FBTWxCLGlCQUFhLFNBTks7QUFPbEIsaUJBQWEsU0FQSztBQVFsQixhQUFTLFNBUlM7QUFTbEIsWUFBUTtBQVRVLENBQWY7O0FBWUEsSUFBTUMsd0NBQWdCLFNBQWhCQSxhQUFnQixDQUFDQyxLQUFELEVBQVc7QUFDcEMsUUFBSSxDQUFDQSxLQUFMLEVBQVk7QUFDUixlQUFPLEtBQVA7QUFDSDtBQUNELFdBQU9GLE9BQU9FLEtBQVAsSUFBZ0JGLE9BQU9FLEtBQVAsQ0FBaEIsR0FBZ0NBLEtBQXZDO0FBQ0gsQ0FMTSIsImZpbGUiOiJjb2xvcnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgY29sb3JzID0ge1xuICAgICdsaWdodCc6ICcjZGRkJyxcbiAgICAnc3RhYmxlJzogJyNiMmIyYjInLFxuICAgICdwb3NpdGl2ZSc6ICcjMzg3ZWY1JyxcbiAgICAnY2FsbSc6ICcjMTFjMWYzJyxcbiAgICAnYmFsYW5jZWQnOiAnIzMzY2Q1ZicsXG4gICAgJ2VuZXJnaXplZCc6ICcjZmZjOTAwJyxcbiAgICAnYXNzZXJ0aXZlJzogJyNlZjQ3M2EnLFxuICAgICdyb3lhbCc6ICcjODg2YWVhJyxcbiAgICAnZGFyayc6ICcjNDQ0Jyxcbn1cblxuZXhwb3J0IGNvbnN0IGlzUHJlc2V0Q29sb3IgPSAoY29sb3IpID0+IHtcbiAgICBpZiAoIWNvbG9yKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICByZXR1cm4gY29sb3JzW2NvbG9yXSA/IGNvbG9yc1tjb2xvcl0gOiBjb2xvclxufVxuIl19