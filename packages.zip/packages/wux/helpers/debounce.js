"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = debounce;
function debounce(func, wait, immediate) {
    var timeout = void 0;
    var args = void 0;
    var context = void 0;
    var timestamp = void 0;
    var result = void 0;

    var later = function later() {
        var last = +new Date() - timestamp;

        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
                if (!timeout) {
                    context = null;
                    args = null;
                }
            }
        }
    };

    return function debounced() {
        context = this;
        args = arguments;
        timestamp = +new Date();

        var callNow = immediate && !timeout;
        if (!timeout) {
            timeout = setTimeout(later, wait);
        }

        if (callNow) {
            result = func.apply(context, args);
            context = null;
            args = null;
        }

        return result;
    };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlYm91bmNlLmpzIl0sIm5hbWVzIjpbImRlYm91bmNlIiwiZnVuYyIsIndhaXQiLCJpbW1lZGlhdGUiLCJ0aW1lb3V0IiwiYXJncyIsImNvbnRleHQiLCJ0aW1lc3RhbXAiLCJyZXN1bHQiLCJsYXRlciIsImxhc3QiLCJEYXRlIiwic2V0VGltZW91dCIsImFwcGx5IiwiZGVib3VuY2VkIiwiYXJndW1lbnRzIiwiY2FsbE5vdyJdLCJtYXBwaW5ncyI6Ijs7Ozs7a0JBQXdCQSxRO0FBQVQsU0FBU0EsUUFBVCxDQUFrQkMsSUFBbEIsRUFBd0JDLElBQXhCLEVBQThCQyxTQUE5QixFQUF5QztBQUNwRCxRQUFJQyxnQkFBSjtBQUNBLFFBQUlDLGFBQUo7QUFDQSxRQUFJQyxnQkFBSjtBQUNBLFFBQUlDLGtCQUFKO0FBQ0EsUUFBSUMsZUFBSjs7QUFFQSxRQUFNQyxRQUFRLFNBQVNBLEtBQVQsR0FBaUI7QUFDL0IsWUFBTUMsT0FBTyxDQUFFLElBQUlDLElBQUosRUFBRixHQUFnQkosU0FBN0I7O0FBRUEsWUFBSUcsT0FBT1IsSUFBUCxJQUFlUSxRQUFRLENBQTNCLEVBQThCO0FBQ3RCTixzQkFBVVEsV0FBV0gsS0FBWCxFQUFrQlAsT0FBT1EsSUFBekIsQ0FBVjtBQUNILFNBRkwsTUFFVztBQUNITixzQkFBVSxJQUFWO0FBQ0EsZ0JBQUksQ0FBQ0QsU0FBTCxFQUFnQjtBQUNaSyx5QkFBU1AsS0FBS1ksS0FBTCxDQUFXUCxPQUFYLEVBQW9CRCxJQUFwQixDQUFUO0FBQ0Esb0JBQUksQ0FBQ0QsT0FBTCxFQUFjO0FBQ1ZFLDhCQUFVLElBQVY7QUFDQUQsMkJBQU8sSUFBUDtBQUNIO0FBQ0o7QUFDSjtBQUNKLEtBZkQ7O0FBaUJBLFdBQU8sU0FBU1MsU0FBVCxHQUFxQjtBQUN4QlIsa0JBQVUsSUFBVjtBQUNBRCxlQUFPVSxTQUFQO0FBQ0FSLG9CQUFZLENBQUUsSUFBSUksSUFBSixFQUFkOztBQUVBLFlBQU1LLFVBQVViLGFBQWEsQ0FBQ0MsT0FBOUI7QUFDQSxZQUFJLENBQUNBLE9BQUwsRUFBYztBQUNWQSxzQkFBVVEsV0FBV0gsS0FBWCxFQUFrQlAsSUFBbEIsQ0FBVjtBQUNIOztBQUVELFlBQUljLE9BQUosRUFBYTtBQUNUUixxQkFBU1AsS0FBS1ksS0FBTCxDQUFXUCxPQUFYLEVBQW9CRCxJQUFwQixDQUFUO0FBQ0FDLHNCQUFVLElBQVY7QUFDQUQsbUJBQU8sSUFBUDtBQUNIOztBQUVELGVBQU9HLE1BQVA7QUFDSCxLQWpCRDtBQWtCSCIsImZpbGUiOiJkZWJvdW5jZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGRlYm91bmNlKGZ1bmMsIHdhaXQsIGltbWVkaWF0ZSkge1xuICAgIGxldCB0aW1lb3V0XG4gICAgbGV0IGFyZ3NcbiAgICBsZXQgY29udGV4dFxuICAgIGxldCB0aW1lc3RhbXBcbiAgICBsZXQgcmVzdWx0XG5cbiAgICBjb25zdCBsYXRlciA9IGZ1bmN0aW9uIGxhdGVyKCkge1xuICAgIGNvbnN0IGxhc3QgPSArKG5ldyBEYXRlKCkpIC0gdGltZXN0YW1wXG5cbiAgICBpZiAobGFzdCA8IHdhaXQgJiYgbGFzdCA+PSAwKSB7XG4gICAgICAgICAgICB0aW1lb3V0ID0gc2V0VGltZW91dChsYXRlciwgd2FpdCAtIGxhc3QpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aW1lb3V0ID0gbnVsbFxuICAgICAgICAgICAgaWYgKCFpbW1lZGlhdGUpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBmdW5jLmFwcGx5KGNvbnRleHQsIGFyZ3MpXG4gICAgICAgICAgICAgICAgaWYgKCF0aW1lb3V0KSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQgPSBudWxsXG4gICAgICAgICAgICAgICAgICAgIGFyZ3MgPSBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZ1bmN0aW9uIGRlYm91bmNlZCgpIHtcbiAgICAgICAgY29udGV4dCA9IHRoaXNcbiAgICAgICAgYXJncyA9IGFyZ3VtZW50c1xuICAgICAgICB0aW1lc3RhbXAgPSArKG5ldyBEYXRlKCkpXG5cbiAgICAgICAgY29uc3QgY2FsbE5vdyA9IGltbWVkaWF0ZSAmJiAhdGltZW91dFxuICAgICAgICBpZiAoIXRpbWVvdXQpIHtcbiAgICAgICAgICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KGxhdGVyLCB3YWl0KVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNhbGxOb3cpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGZ1bmMuYXBwbHkoY29udGV4dCwgYXJncylcbiAgICAgICAgICAgIGNvbnRleHQgPSBudWxsXG4gICAgICAgICAgICBhcmdzID0gbnVsbFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cbn1cbiJdfQ==