'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

/**
 * 过滤对象的函数属性
 * @param {Object} opts
 */
var mergeOptionsToData = function mergeOptionsToData() {
    var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var options = Object.assign({}, opts);

    for (var key in options) {
        if (options.hasOwnProperty(key) && typeof options[key] === 'function') {
            delete options[key];
        }
    }

    return options;
};

/**
 * Simple bind, faster than native
 *
 * @param {Function} fn
 * @param {Object} ctx
 * @return {Function}
 */
var bind = function bind(fn, ctx) {
    return function () {
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return args.length ? fn.apply(ctx, args) : fn.call(ctx);
    };
};

/**
 * Object assign
 */
var assign = function assign() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
    }

    return Object.assign.apply(Object, [{}].concat(args));
};

exports.default = Behavior({
    definitionFilter: function definitionFilter(defFields) {
        defFields.data = mergeOptionsToData(defFields.data);
        defFields.data.in = false;
        defFields.data.visible = false;
    },

    methods: {
        /**
         * 过滤对象的函数属性
         * @param {Object} opts
         */
        $$mergeOptionsToData: mergeOptionsToData,
        /**
         * 合并参数并绑定方法
         *
         * @param {Object} opts 参数对象
         * @param {Object} fns 方法挂载的属性
         */
        $$mergeOptionsAndBindMethods: function $$mergeOptionsAndBindMethods() {
            var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var fns = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.fns;

            var options = Object.assign({}, opts);

            for (var key in options) {
                if (options.hasOwnProperty(key) && typeof options[key] === 'function') {
                    fns[key] = bind(options[key], this);
                    delete options[key];
                }
            }

            return options;
        },

        /**
         * Promise setData
         * @param {Array} args 参数对象
         */
        $$setData: function $$setData() {
            var _this = this;

            for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
                args[_key3] = arguments[_key3];
            }

            var params = assign.apply(undefined, [{}].concat(_toConsumableArray(args)));

            return new Promise(function (resolve) {
                _this.setData(params, resolve);
            });
        },

        /**
         * 延迟指定时间执行回调函数
         * @param {Function} callback 回调函数
         * @param {Number} timeout 延迟时间
         */
        $$requestAnimationFrame: function $$requestAnimationFrame() {
            var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};
            var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000 / 60;

            return new Promise(function (resolve) {
                return setTimeout(resolve, timeout);
            }).then(callback);
        }
    },
    /**
     * 组件生命周期函数，在组件实例进入页面节点树时执行
     */
    created: function created() {
        this.fns = {};
    },

    /**
     * 组件生命周期函数，在组件实例被从页面节点树移除时执行
     */
    detached: function detached() {
        this.fns = {};
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZ1bmNCZWhhdmlvci5qcyJdLCJuYW1lcyI6WyJtZXJnZU9wdGlvbnNUb0RhdGEiLCJvcHRzIiwib3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsImtleSIsImhhc093blByb3BlcnR5IiwiYmluZCIsImZuIiwiY3R4IiwiYXJncyIsImxlbmd0aCIsImFwcGx5IiwiY2FsbCIsIkJlaGF2aW9yIiwiZGVmaW5pdGlvbkZpbHRlciIsImRlZkZpZWxkcyIsImRhdGEiLCJpbiIsInZpc2libGUiLCJtZXRob2RzIiwiJCRtZXJnZU9wdGlvbnNUb0RhdGEiLCIkJG1lcmdlT3B0aW9uc0FuZEJpbmRNZXRob2RzIiwiZm5zIiwiJCRzZXREYXRhIiwicGFyYW1zIiwiUHJvbWlzZSIsInJlc29sdmUiLCJzZXREYXRhIiwiJCRyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJjYWxsYmFjayIsInRpbWVvdXQiLCJzZXRUaW1lb3V0IiwidGhlbiIsImNyZWF0ZWQiLCJkZXRhY2hlZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7OztBQUlBLElBQU1BLHFCQUFxQixTQUFyQkEsa0JBQXFCLEdBQWU7QUFBQSxRQUFkQyxJQUFjLHVFQUFQLEVBQU87O0FBQ3RDLFFBQU1DLFVBQVVDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCSCxJQUFsQixDQUFoQjs7QUFFQSxTQUFLLElBQU1JLEdBQVgsSUFBa0JILE9BQWxCLEVBQTJCO0FBQ3ZCLFlBQUlBLFFBQVFJLGNBQVIsQ0FBdUJELEdBQXZCLEtBQStCLE9BQU9ILFFBQVFHLEdBQVIsQ0FBUCxLQUF3QixVQUEzRCxFQUF1RTtBQUNuRSxtQkFBT0gsUUFBUUcsR0FBUixDQUFQO0FBQ0g7QUFDSjs7QUFFRCxXQUFPSCxPQUFQO0FBQ0gsQ0FWRDs7QUFZQTs7Ozs7OztBQU9BLElBQU1LLE9BQU8sU0FBUEEsSUFBTyxDQUFDQyxFQUFELEVBQUtDLEdBQUwsRUFBYTtBQUN0QixXQUFPLFlBQWE7QUFBQSwwQ0FBVEMsSUFBUztBQUFUQSxnQkFBUztBQUFBOztBQUNoQixlQUFPQSxLQUFLQyxNQUFMLEdBQWNILEdBQUdJLEtBQUgsQ0FBU0gsR0FBVCxFQUFjQyxJQUFkLENBQWQsR0FBb0NGLEdBQUdLLElBQUgsQ0FBUUosR0FBUixDQUEzQztBQUNILEtBRkQ7QUFHSCxDQUpEOztBQU1BOzs7QUFHQSxJQUFNTCxTQUFTLFNBQVRBLE1BQVM7QUFBQSx1Q0FBSU0sSUFBSjtBQUFJQSxZQUFKO0FBQUE7O0FBQUEsV0FBYVAsT0FBT0MsTUFBUCxnQkFBYyxFQUFkLFNBQXFCTSxJQUFyQixFQUFiO0FBQUEsQ0FBZjs7a0JBRWVJLFNBQVM7QUFDcEJDLG9CQURvQiw0QkFDSEMsU0FERyxFQUNRO0FBQ3hCQSxrQkFBVUMsSUFBVixHQUFpQmpCLG1CQUFtQmdCLFVBQVVDLElBQTdCLENBQWpCO0FBQ0FELGtCQUFVQyxJQUFWLENBQWVDLEVBQWYsR0FBb0IsS0FBcEI7QUFDQUYsa0JBQVVDLElBQVYsQ0FBZUUsT0FBZixHQUF5QixLQUF6QjtBQUNILEtBTG1COztBQU1wQkMsYUFBUztBQUNMOzs7O0FBSUFDLDhCQUFzQnJCLGtCQUxqQjtBQU1MOzs7Ozs7QUFNQXNCLG9DQVpLLDBDQVlvRDtBQUFBLGdCQUEzQnJCLElBQTJCLHVFQUFwQixFQUFvQjtBQUFBLGdCQUFoQnNCLEdBQWdCLHVFQUFWLEtBQUtBLEdBQUs7O0FBQ3JELGdCQUFNckIsVUFBVUMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JILElBQWxCLENBQWhCOztBQUVBLGlCQUFLLElBQU1JLEdBQVgsSUFBa0JILE9BQWxCLEVBQTJCO0FBQ3ZCLG9CQUFJQSxRQUFRSSxjQUFSLENBQXVCRCxHQUF2QixLQUErQixPQUFPSCxRQUFRRyxHQUFSLENBQVAsS0FBd0IsVUFBM0QsRUFBdUU7QUFDbkVrQix3QkFBSWxCLEdBQUosSUFBV0UsS0FBS0wsUUFBUUcsR0FBUixDQUFMLEVBQW1CLElBQW5CLENBQVg7QUFDQSwyQkFBT0gsUUFBUUcsR0FBUixDQUFQO0FBQ0g7QUFDSjs7QUFFRCxtQkFBT0gsT0FBUDtBQUNILFNBdkJJOztBQXdCTDs7OztBQUlBc0IsaUJBNUJLLHVCQTRCZTtBQUFBOztBQUFBLCtDQUFOZCxJQUFNO0FBQU5BLG9CQUFNO0FBQUE7O0FBQ2hCLGdCQUFNZSxTQUFTckIseUJBQU8sRUFBUCw0QkFBY00sSUFBZCxHQUFmOztBQUVBLG1CQUFPLElBQUlnQixPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFhO0FBQzVCLHNCQUFLQyxPQUFMLENBQWFILE1BQWIsRUFBcUJFLE9BQXJCO0FBQ0gsYUFGTSxDQUFQO0FBR0gsU0FsQ0k7O0FBbUNMOzs7OztBQUtBRSwrQkF4Q0sscUNBd0M4RDtBQUFBLGdCQUExQ0MsUUFBMEMsdUVBQS9CLFlBQU0sQ0FBRSxDQUF1QjtBQUFBLGdCQUFyQkMsT0FBcUIsdUVBQVgsT0FBTyxFQUFJOztBQUMvRCxtQkFBTyxJQUFJTCxPQUFKLENBQVksVUFBQ0MsT0FBRDtBQUFBLHVCQUFhSyxXQUFXTCxPQUFYLEVBQW9CSSxPQUFwQixDQUFiO0FBQUEsYUFBWixFQUF1REUsSUFBdkQsQ0FBNERILFFBQTVELENBQVA7QUFDSDtBQTFDSSxLQU5XO0FBa0RwQjs7O0FBR0FJLFdBckRvQixxQkFxRFQ7QUFDUCxhQUFLWCxHQUFMLEdBQVcsRUFBWDtBQUNILEtBdkRtQjs7QUF3RHBCOzs7QUFHQVksWUEzRG9CLHNCQTJEUjtBQUNSLGFBQUtaLEdBQUwsR0FBVyxFQUFYO0FBQ0g7QUE3RG1CLENBQVQsQyIsImZpbGUiOiJmdW5jQmVoYXZpb3IuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIOi/h+a7pOWvueixoeeahOWHveaVsOWxnuaAp1xuICogQHBhcmFtIHtPYmplY3R9IG9wdHNcbiAqL1xuY29uc3QgbWVyZ2VPcHRpb25zVG9EYXRhID0gKG9wdHMgPSB7fSkgPT4ge1xuICAgIGNvbnN0IG9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRzKVxuXG4gICAgZm9yIChjb25zdCBrZXkgaW4gb3B0aW9ucykge1xuICAgICAgICBpZiAob3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShrZXkpICYmIHR5cGVvZiBvcHRpb25zW2tleV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGRlbGV0ZSBvcHRpb25zW2tleV1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBvcHRpb25zXG59XG5cbi8qKlxuICogU2ltcGxlIGJpbmQsIGZhc3RlciB0aGFuIG5hdGl2ZVxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuXG4gKiBAcGFyYW0ge09iamVjdH0gY3R4XG4gKiBAcmV0dXJuIHtGdW5jdGlvbn1cbiAqL1xuY29uc3QgYmluZCA9IChmbiwgY3R4KSA9PiB7XG4gICAgcmV0dXJuICguLi5hcmdzKSA9PiB7XG4gICAgICAgIHJldHVybiBhcmdzLmxlbmd0aCA/IGZuLmFwcGx5KGN0eCwgYXJncykgOiBmbi5jYWxsKGN0eClcbiAgICB9XG59XG5cbi8qKlxuICogT2JqZWN0IGFzc2lnblxuICovXG5jb25zdCBhc3NpZ24gPSAoLi4uYXJncykgPT4gT2JqZWN0LmFzc2lnbih7fSwgLi4uYXJncylcblxuZXhwb3J0IGRlZmF1bHQgQmVoYXZpb3Ioe1xuICAgIGRlZmluaXRpb25GaWx0ZXIoZGVmRmllbGRzKSB7XG4gICAgICAgIGRlZkZpZWxkcy5kYXRhID0gbWVyZ2VPcHRpb25zVG9EYXRhKGRlZkZpZWxkcy5kYXRhKVxuICAgICAgICBkZWZGaWVsZHMuZGF0YS5pbiA9IGZhbHNlXG4gICAgICAgIGRlZkZpZWxkcy5kYXRhLnZpc2libGUgPSBmYWxzZVxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICAvKipcbiAgICAgICAgICog6L+H5ruk5a+56LGh55qE5Ye95pWw5bGe5oCnXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzXG4gICAgICAgICAqL1xuICAgICAgICAkJG1lcmdlT3B0aW9uc1RvRGF0YTogbWVyZ2VPcHRpb25zVG9EYXRhLFxuICAgICAgICAvKipcbiAgICAgICAgICog5ZCI5bm25Y+C5pWw5bm257uR5a6a5pa55rOVXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzIOWPguaVsOWvueixoVxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gZm5zIOaWueazleaMgui9veeahOWxnuaAp1xuICAgICAgICAgKi9cbiAgICAgICAgJCRtZXJnZU9wdGlvbnNBbmRCaW5kTWV0aG9kcyAob3B0cyA9IHt9LCBmbnMgPSB0aGlzLmZucykge1xuICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdHMpXG5cbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShrZXkpICYmIHR5cGVvZiBvcHRpb25zW2tleV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgZm5zW2tleV0gPSBiaW5kKG9wdGlvbnNba2V5XSwgdGhpcylcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9wdGlvbnNba2V5XVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIG9wdGlvbnNcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb21pc2Ugc2V0RGF0YVxuICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBhcmdzIOWPguaVsOWvueixoVxuICAgICAgICAgKi9cbiAgICAgICAgJCRzZXREYXRhICguLi5hcmdzKSB7XG4gICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBhc3NpZ24oe30sIC4uLmFyZ3MpXG5cbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMsIHJlc29sdmUpXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog5bu26L+f5oyH5a6a5pe26Ze05omn6KGM5Zue6LCD5Ye95pWwXG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIOWbnuiwg+WHveaVsFxuICAgICAgICAgKiBAcGFyYW0ge051bWJlcn0gdGltZW91dCDlu7bov5/ml7bpl7RcbiAgICAgICAgICovXG4gICAgICAgICQkcmVxdWVzdEFuaW1hdGlvbkZyYW1lIChjYWxsYmFjayA9ICgpID0+IHt9LCB0aW1lb3V0ID0gMTAwMCAvIDYwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZW91dCkpLnRoZW4oY2FsbGJhY2spXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDnu4Tku7bnlJ/lkb3lkajmnJ/lh73mlbDvvIzlnKjnu4Tku7blrp7kvovov5vlhaXpobXpnaLoioLngrnmoJHml7bmiafooYxcbiAgICAgKi9cbiAgICBjcmVhdGVkICgpIHtcbiAgICAgICAgdGhpcy5mbnMgPSB7fVxuICAgIH0sXG4gICAgLyoqXG4gICAgICog57uE5Lu255Sf5ZG95ZGo5pyf5Ye95pWw77yM5Zyo57uE5Lu25a6e5L6L6KKr5LuO6aG16Z2i6IqC54K55qCR56e76Zmk5pe25omn6KGMXG4gICAgICovXG4gICAgZGV0YWNoZWQgKCkge1xuICAgICAgICB0aGlzLmZucyA9IHt9XG4gICAgfSxcbn0pXG4iXX0=