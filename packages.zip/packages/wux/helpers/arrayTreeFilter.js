'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * https://github.com/afc163/array-tree-filter
 */
function arrayTreeFilter(data, filterFn, options) {
    options = options || {};
    options.childrenKeyName = options.childrenKeyName || 'children';
    var children = data || [];
    var result = [];
    var level = 0;
    do {
        var foundItem = children.filter(function (item) {
            return filterFn(item, level);
        })[0];
        if (!foundItem) {
            break;
        }
        result.push(foundItem);
        children = foundItem[options.childrenKeyName] || [];
        level += 1;
    } while (children.length > 0);
    return result;
}
exports.default = arrayTreeFilter;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5VHJlZUZpbHRlci5qcyJdLCJuYW1lcyI6WyJhcnJheVRyZWVGaWx0ZXIiLCJkYXRhIiwiZmlsdGVyRm4iLCJvcHRpb25zIiwiY2hpbGRyZW5LZXlOYW1lIiwiY2hpbGRyZW4iLCJyZXN1bHQiLCJsZXZlbCIsImZvdW5kSXRlbSIsImZpbHRlciIsIml0ZW0iLCJwdXNoIiwibGVuZ3RoIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBOzs7QUFHQSxTQUFTQSxlQUFULENBQTBCQyxJQUExQixFQUFnQ0MsUUFBaEMsRUFBMENDLE9BQTFDLEVBQW1EO0FBQy9DQSxjQUFVQSxXQUFXLEVBQXJCO0FBQ0FBLFlBQVFDLGVBQVIsR0FBMEJELFFBQVFDLGVBQVIsSUFBMkIsVUFBckQ7QUFDQSxRQUFJQyxXQUFXSixRQUFRLEVBQXZCO0FBQ0EsUUFBTUssU0FBUyxFQUFmO0FBQ0EsUUFBSUMsUUFBUSxDQUFaO0FBQ0EsT0FBRztBQUNDLFlBQU1DLFlBQVlILFNBQVNJLE1BQVQsQ0FBZ0IsVUFBVUMsSUFBVixFQUFnQjtBQUM5QyxtQkFBT1IsU0FBU1EsSUFBVCxFQUFlSCxLQUFmLENBQVA7QUFDSCxTQUZpQixFQUVmLENBRmUsQ0FBbEI7QUFHQSxZQUFJLENBQUNDLFNBQUwsRUFBZ0I7QUFDWjtBQUNIO0FBQ0RGLGVBQU9LLElBQVAsQ0FBWUgsU0FBWjtBQUNBSCxtQkFBV0csVUFBVUwsUUFBUUMsZUFBbEIsS0FBc0MsRUFBakQ7QUFDQUcsaUJBQVMsQ0FBVDtBQUNILEtBVkQsUUFVU0YsU0FBU08sTUFBVCxHQUFrQixDQVYzQjtBQVdBLFdBQU9OLE1BQVA7QUFDSDtrQkFDY04sZSIsImZpbGUiOiJhcnJheVRyZWVGaWx0ZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9hZmMxNjMvYXJyYXktdHJlZS1maWx0ZXJcbiAqL1xuZnVuY3Rpb24gYXJyYXlUcmVlRmlsdGVyIChkYXRhLCBmaWx0ZXJGbiwgb3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9XG4gICAgb3B0aW9ucy5jaGlsZHJlbktleU5hbWUgPSBvcHRpb25zLmNoaWxkcmVuS2V5TmFtZSB8fCAnY2hpbGRyZW4nXG4gICAgbGV0IGNoaWxkcmVuID0gZGF0YSB8fCBbXVxuICAgIGNvbnN0IHJlc3VsdCA9IFtdXG4gICAgbGV0IGxldmVsID0gMFxuICAgIGRvIHtcbiAgICAgICAgY29uc3QgZm91bmRJdGVtID0gY2hpbGRyZW4uZmlsdGVyKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gZmlsdGVyRm4oaXRlbSwgbGV2ZWwpXG4gICAgICAgIH0pWzBdXG4gICAgICAgIGlmICghZm91bmRJdGVtKSB7XG4gICAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdC5wdXNoKGZvdW5kSXRlbSlcbiAgICAgICAgY2hpbGRyZW4gPSBmb3VuZEl0ZW1bb3B0aW9ucy5jaGlsZHJlbktleU5hbWVdIHx8IFtdXG4gICAgICAgIGxldmVsICs9IDFcbiAgICB9IHdoaWxlIChjaGlsZHJlbi5sZW5ndGggPiAwKVxuICAgIHJldHVybiByZXN1bHRcbn1cbmV4cG9ydCBkZWZhdWx0IGFycmF5VHJlZUZpbHRlclxuIl19