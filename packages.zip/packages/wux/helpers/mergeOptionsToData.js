'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * 过滤对象的函数属性
 * @param {Object} opts
 */
var mergeOptionsToData = function mergeOptionsToData() {
    var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var options = Object.assign({}, opts);

    for (var key in options) {
        if (options.hasOwnProperty(key) && typeof options[key] === 'function') {
            delete options[key];
        }
    }

    return options;
};

exports.default = mergeOptionsToData;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lcmdlT3B0aW9uc1RvRGF0YS5qcyJdLCJuYW1lcyI6WyJtZXJnZU9wdGlvbnNUb0RhdGEiLCJvcHRzIiwib3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsImtleSIsImhhc093blByb3BlcnR5Il0sIm1hcHBpbmdzIjoiOzs7OztBQUFBOzs7O0FBSUEsSUFBTUEscUJBQXFCLFNBQXJCQSxrQkFBcUIsR0FBZTtBQUFBLFFBQWRDLElBQWMsdUVBQVAsRUFBTzs7QUFDdEMsUUFBTUMsVUFBVUMsT0FBT0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JILElBQWxCLENBQWhCOztBQUVBLFNBQUssSUFBTUksR0FBWCxJQUFrQkgsT0FBbEIsRUFBMkI7QUFDdkIsWUFBSUEsUUFBUUksY0FBUixDQUF1QkQsR0FBdkIsS0FBK0IsT0FBT0gsUUFBUUcsR0FBUixDQUFQLEtBQXdCLFVBQTNELEVBQXVFO0FBQ25FLG1CQUFPSCxRQUFRRyxHQUFSLENBQVA7QUFDSDtBQUNKOztBQUVELFdBQU9ILE9BQVA7QUFDSCxDQVZEOztrQkFZZUYsa0IiLCJmaWxlIjoibWVyZ2VPcHRpb25zVG9EYXRhLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDov4fmu6Tlr7nosaHnmoTlh73mlbDlsZ7mgKdcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzXG4gKi9cbmNvbnN0IG1lcmdlT3B0aW9uc1RvRGF0YSA9IChvcHRzID0ge30pID0+IHtcbiAgICBjb25zdCBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0cylcblxuICAgIGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKG9wdGlvbnMuaGFzT3duUHJvcGVydHkoa2V5KSAmJiB0eXBlb2Ygb3B0aW9uc1trZXldID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBkZWxldGUgb3B0aW9uc1trZXldXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gb3B0aW9uc1xufVxuXG5leHBvcnQgZGVmYXVsdCBtZXJnZU9wdGlvbnNUb0RhdGFcbiJdfQ==