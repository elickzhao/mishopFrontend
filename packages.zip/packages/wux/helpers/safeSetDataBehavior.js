"use strict";

module.exports = Behavior({
    lifetimes: {
        created: function created() {
            this.nextCallback = null;
        },
        detached: function detached() {
            this.cancelNextCallback();
        }
    },
    methods: {
        /**
         * safeSetData
         * @param {Object} nextData 数据对象
         * @param {Function} callback 回调函数
         */
        safeSetData: function safeSetData(nextData, callback) {
            var _this = this;

            this.pendingData = Object.assign({}, this.data, nextData);
            callback = this.setNextCallback(callback);

            this.setData(nextData, function () {
                _this.pendingData = null;
                callback();
            });
        },

        /**
         * 设置下一回调函数
         * @param {Function} callback 回调函数
         */
        setNextCallback: function setNextCallback(callback) {
            var _this2 = this;

            var active = true;

            this.nextCallback = function (event) {
                if (active) {
                    active = false;
                    _this2.nextCallback = null;

                    callback.call(_this2, event);
                }
            };

            this.nextCallback.cancel = function () {
                active = false;
            };

            return this.nextCallback;
        },

        /**
         * 取消下一回调函数
         */
        cancelNextCallback: function cancelNextCallback() {
            if (this.nextCallback !== null) {
                this.nextCallback.cancel();
                this.nextCallback = null;
            }
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNhZmVTZXREYXRhQmVoYXZpb3IuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkJlaGF2aW9yIiwibGlmZXRpbWVzIiwiY3JlYXRlZCIsIm5leHRDYWxsYmFjayIsImRldGFjaGVkIiwiY2FuY2VsTmV4dENhbGxiYWNrIiwibWV0aG9kcyIsInNhZmVTZXREYXRhIiwibmV4dERhdGEiLCJjYWxsYmFjayIsInBlbmRpbmdEYXRhIiwiT2JqZWN0IiwiYXNzaWduIiwiZGF0YSIsInNldE5leHRDYWxsYmFjayIsInNldERhdGEiLCJhY3RpdmUiLCJldmVudCIsImNhbGwiLCJjYW5jZWwiXSwibWFwcGluZ3MiOiI7O0FBQUFBLE9BQU9DLE9BQVAsR0FBaUJDLFNBQVM7QUFDdEJDLGVBQVc7QUFDUEMsZUFETyxxQkFDSTtBQUNQLGlCQUFLQyxZQUFMLEdBQW9CLElBQXBCO0FBQ0gsU0FITTtBQUlQQyxnQkFKTyxzQkFJSTtBQUNQLGlCQUFLQyxrQkFBTDtBQUNIO0FBTk0sS0FEVztBQVN0QkMsYUFBUztBQUNMOzs7OztBQUtBQyxtQkFOSyx1QkFNT0MsUUFOUCxFQU1pQkMsUUFOakIsRUFNMkI7QUFBQTs7QUFDNUIsaUJBQUtDLFdBQUwsR0FBbUJDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLEtBQUtDLElBQXZCLEVBQTZCTCxRQUE3QixDQUFuQjtBQUNBQyx1QkFBVyxLQUFLSyxlQUFMLENBQXFCTCxRQUFyQixDQUFYOztBQUVBLGlCQUFLTSxPQUFMLENBQWFQLFFBQWIsRUFBdUIsWUFBTTtBQUN6QixzQkFBS0UsV0FBTCxHQUFtQixJQUFuQjtBQUNBRDtBQUNILGFBSEQ7QUFJSCxTQWRJOztBQWVMOzs7O0FBSUFLLHVCQW5CSywyQkFtQldMLFFBbkJYLEVBbUJxQjtBQUFBOztBQUN0QixnQkFBSU8sU0FBUyxJQUFiOztBQUVBLGlCQUFLYixZQUFMLEdBQW9CLFVBQUNjLEtBQUQsRUFBVztBQUMzQixvQkFBSUQsTUFBSixFQUFZO0FBQ1JBLDZCQUFTLEtBQVQ7QUFDQSwyQkFBS2IsWUFBTCxHQUFvQixJQUFwQjs7QUFFQU0sNkJBQVNTLElBQVQsQ0FBYyxNQUFkLEVBQW9CRCxLQUFwQjtBQUNIO0FBQ0osYUFQRDs7QUFTQSxpQkFBS2QsWUFBTCxDQUFrQmdCLE1BQWxCLEdBQTJCLFlBQU07QUFDN0JILHlCQUFTLEtBQVQ7QUFDSCxhQUZEOztBQUlBLG1CQUFPLEtBQUtiLFlBQVo7QUFDSCxTQXBDSTs7QUFxQ0w7OztBQUdBRSwwQkF4Q0ssZ0NBd0NnQjtBQUNqQixnQkFBSSxLQUFLRixZQUFMLEtBQXNCLElBQTFCLEVBQWdDO0FBQzVCLHFCQUFLQSxZQUFMLENBQWtCZ0IsTUFBbEI7QUFDQSxxQkFBS2hCLFlBQUwsR0FBb0IsSUFBcEI7QUFDSDtBQUNKO0FBN0NJO0FBVGEsQ0FBVCxDQUFqQiIsImZpbGUiOiJzYWZlU2V0RGF0YUJlaGF2aW9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSBCZWhhdmlvcih7XG4gICAgbGlmZXRpbWVzOiB7XG4gICAgICAgIGNyZWF0ZWQgKCkge1xuICAgICAgICAgICAgdGhpcy5uZXh0Q2FsbGJhY2sgPSBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIGRldGFjaGVkKCkge1xuICAgICAgICAgICAgdGhpcy5jYW5jZWxOZXh0Q2FsbGJhY2soKVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICAvKipcbiAgICAgICAgICogc2FmZVNldERhdGFcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG5leHREYXRhIOaVsOaNruWvueixoVxuICAgICAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayDlm57osIPlh73mlbBcbiAgICAgICAgICovXG4gICAgICAgIHNhZmVTZXREYXRhKG5leHREYXRhLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgdGhpcy5wZW5kaW5nRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZGF0YSwgbmV4dERhdGEpXG4gICAgICAgICAgICBjYWxsYmFjayA9IHRoaXMuc2V0TmV4dENhbGxiYWNrKGNhbGxiYWNrKVxuXG4gICAgICAgICAgICB0aGlzLnNldERhdGEobmV4dERhdGEsICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnBlbmRpbmdEYXRhID0gbnVsbFxuICAgICAgICAgICAgICAgIGNhbGxiYWNrKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDorr7nva7kuIvkuIDlm57osIPlh73mlbBcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sg5Zue6LCD5Ye95pWwXG4gICAgICAgICAqL1xuICAgICAgICBzZXROZXh0Q2FsbGJhY2soY2FsbGJhY2spIHtcbiAgICAgICAgICAgIGxldCBhY3RpdmUgPSB0cnVlXG5cbiAgICAgICAgICAgIHRoaXMubmV4dENhbGxiYWNrID0gKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGFjdGl2ZSkge1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmUgPSBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5leHRDYWxsYmFjayA9IG51bGxcblxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjay5jYWxsKHRoaXMsIGV2ZW50KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy5uZXh0Q2FsbGJhY2suY2FuY2VsID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGFjdGl2ZSA9IGZhbHNlXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5leHRDYWxsYmFja1xuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog5Y+W5raI5LiL5LiA5Zue6LCD5Ye95pWwXG4gICAgICAgICAqL1xuICAgICAgICBjYW5jZWxOZXh0Q2FsbGJhY2soKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5uZXh0Q2FsbGJhY2sgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5leHRDYWxsYmFjay5jYW5jZWwoKVxuICAgICAgICAgICAgICAgIHRoaXMubmV4dENhbGxiYWNrID0gbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH0sXG59KVxuIl19