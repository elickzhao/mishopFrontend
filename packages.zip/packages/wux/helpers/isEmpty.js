'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/**
 * Checks if a value is empty.
 */
function isEmpty(value) {
    if (Array.isArray(value)) {
        return value.length === 0;
    } else if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object') {
        if (value) {
            for (var _ in value) {
                return false;
            }
        }
        return true;
    } else {
        return !value;
    }
}

module.exports = isEmpty;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImlzRW1wdHkuanMiXSwibmFtZXMiOlsiaXNFbXB0eSIsInZhbHVlIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiXyIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTs7O0FBR0EsU0FBU0EsT0FBVCxDQUFrQkMsS0FBbEIsRUFBeUI7QUFDckIsUUFBSUMsTUFBTUMsT0FBTixDQUFjRixLQUFkLENBQUosRUFBMEI7QUFDdEIsZUFBT0EsTUFBTUcsTUFBTixLQUFpQixDQUF4QjtBQUNILEtBRkQsTUFFTyxJQUFJLFFBQU9ILEtBQVAseUNBQU9BLEtBQVAsT0FBaUIsUUFBckIsRUFBK0I7QUFDbEMsWUFBSUEsS0FBSixFQUFXO0FBQ1AsaUJBQUssSUFBTUksQ0FBWCxJQUFnQkosS0FBaEIsRUFBdUI7QUFDbkIsdUJBQU8sS0FBUDtBQUNIO0FBQ0o7QUFDRCxlQUFPLElBQVA7QUFDSCxLQVBNLE1BT0E7QUFDSCxlQUFPLENBQUNBLEtBQVI7QUFDSDtBQUNKOztBQUVESyxPQUFPQyxPQUFQLEdBQWlCUCxPQUFqQiIsImZpbGUiOiJpc0VtcHR5LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDaGVja3MgaWYgYSB2YWx1ZSBpcyBlbXB0eS5cbiAqL1xuZnVuY3Rpb24gaXNFbXB0eSAodmFsdWUpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLmxlbmd0aCA9PT0gMFxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgXyBpbiB2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlXG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuICF2YWx1ZVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBpc0VtcHR5XG4iXX0=