'use strict';

/**
 * CSS properties which accept numbers but are not in units of "px".
 */

var isUnitlessNumber = {
    boxFlex: true,
    boxFlexGroup: true,
    columnCount: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    widows: true,
    zIndex: true,
    zoom: true,

    // SVG-related properties
    fillOpacity: true,
    strokeDashoffset: true,
    strokeOpacity: true,
    strokeWidth: true
};

/**
 * @param {string} prefix vendor-specific prefix, eg: Webkit
 * @param {string} key style name, eg: transitionDuration
 * @return {string} style name prefixed with `prefix`, properly camelCased, eg:
 * WebkitTransitionDuration
 */
function prefixKey(prefix, key) {
    return prefix + key.charAt(0).toUpperCase() + key.substring(1);
}

/**
 * Support style names that may come passed in prefixed by adding permutations
 * of vendor prefixes.
 */
var prefixes = ['Webkit', 'ms', 'Moz', 'O'];

// Using Object.keys here, or else the vanilla for-in loop makes IE8 go into an
// infinite loop, because it iterates over the newly added props too.
Object.keys(isUnitlessNumber).forEach(function (prop) {
    prefixes.forEach(function (prefix) {
        isUnitlessNumber[prefixKey(prefix, prop)] = isUnitlessNumber[prop];
    });
});

var msPattern = /^ms-/;

var _uppercasePattern = /([A-Z])/g;

/**
 * Hyphenates a camelcased string, for example:
 *
 *   > hyphenate('backgroundColor')
 *   < "background-color"
 *
 * For CSS style names, use `hyphenateStyleName` instead which works properly
 * with all vendor prefixes, including `ms`.
 *
 * @param {string} string
 * @return {string}
 */
function hyphenate(string) {
    return string.replace(_uppercasePattern, '-$1').toLowerCase();
}

/**
 * Hyphenates a camelcased CSS property name, for example:
 *
 *   > hyphenateStyleName('backgroundColor')
 *   < "background-color"
 *   > hyphenateStyleName('MozTransition')
 *   < "-moz-transition"
 *   > hyphenateStyleName('msTransition')
 *   < "-ms-transition"
 *
 * As Modernizr suggests (http://modernizr.com/docs/#prefixed), an `ms` prefix
 * is converted to `-ms-`.
 *
 * @param {string} string
 * @return {string}
 */
function hyphenateStyleName(string) {
    return hyphenate(string).replace(msPattern, '-ms-');
}

var isArray = Array.isArray;
var keys = Object.keys;

var counter = 1;
// Follows syntax at https://developer.mozilla.org/en-US/docs/Web/CSS/content,
// including multiple space separated values.
var unquotedContentValueRegex = /^(normal|none|(\b(url\([^)]*\)|chapter_counter|attr\([^)]*\)|(no-)?(open|close)-quote|inherit)((\b\s*)|$|\s+))+)$/;

function buildRule(key, value) {
    if (!isUnitlessNumber[key] && typeof value === 'number') {
        value = '' + value + 'px';
    } else if (key === 'content' && !unquotedContentValueRegex.test(value)) {
        value = "'" + value.replace(/'/g, "\\'") + "'";
    }

    return hyphenateStyleName(key) + ': ' + value + ';  ';
}

function styleToCssString(rules) {
    var result = '';
    if (typeof rules === 'string') {
        return rules;
    }
    if (!rules || keys(rules).length === 0) {
        return result;
    }
    var styleKeys = keys(rules);
    for (var j = 0, l = styleKeys.length; j < l; j++) {
        var styleKey = styleKeys[j];
        var value = rules[styleKey];

        if (isArray(value)) {
            for (var i = 0, len = value.length; i < len; i++) {
                result += buildRule(styleKey, value[i]);
            }
        } else {
            result += buildRule(styleKey, value);
        }
    }
    return result;
}

module.exports = styleToCssString;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0eWxlVG9Dc3NTdHJpbmcuanMiXSwibmFtZXMiOlsiaXNVbml0bGVzc051bWJlciIsImJveEZsZXgiLCJib3hGbGV4R3JvdXAiLCJjb2x1bW5Db3VudCIsImZsZXgiLCJmbGV4R3JvdyIsImZsZXhQb3NpdGl2ZSIsImZsZXhTaHJpbmsiLCJmbGV4TmVnYXRpdmUiLCJmb250V2VpZ2h0IiwibGluZUNsYW1wIiwibGluZUhlaWdodCIsIm9wYWNpdHkiLCJvcmRlciIsIm9ycGhhbnMiLCJ3aWRvd3MiLCJ6SW5kZXgiLCJ6b29tIiwiZmlsbE9wYWNpdHkiLCJzdHJva2VEYXNob2Zmc2V0Iiwic3Ryb2tlT3BhY2l0eSIsInN0cm9rZVdpZHRoIiwicHJlZml4S2V5IiwicHJlZml4Iiwia2V5IiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzdWJzdHJpbmciLCJwcmVmaXhlcyIsIk9iamVjdCIsImtleXMiLCJmb3JFYWNoIiwicHJvcCIsIm1zUGF0dGVybiIsIl91cHBlcmNhc2VQYXR0ZXJuIiwiaHlwaGVuYXRlIiwic3RyaW5nIiwicmVwbGFjZSIsInRvTG93ZXJDYXNlIiwiaHlwaGVuYXRlU3R5bGVOYW1lIiwiaXNBcnJheSIsIkFycmF5IiwiY291bnRlciIsInVucXVvdGVkQ29udGVudFZhbHVlUmVnZXgiLCJidWlsZFJ1bGUiLCJ2YWx1ZSIsInRlc3QiLCJzdHlsZVRvQ3NzU3RyaW5nIiwicnVsZXMiLCJyZXN1bHQiLCJsZW5ndGgiLCJzdHlsZUtleXMiLCJqIiwibCIsInN0eWxlS2V5IiwiaSIsImxlbiIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiJBQUFBOztBQUVBOzs7O0FBR0EsSUFBSUEsbUJBQW1CO0FBQ25CQyxhQUFTLElBRFU7QUFFbkJDLGtCQUFjLElBRks7QUFHbkJDLGlCQUFhLElBSE07QUFJbkJDLFVBQU0sSUFKYTtBQUtuQkMsY0FBVSxJQUxTO0FBTW5CQyxrQkFBYyxJQU5LO0FBT25CQyxnQkFBWSxJQVBPO0FBUW5CQyxrQkFBYyxJQVJLO0FBU25CQyxnQkFBWSxJQVRPO0FBVW5CQyxlQUFXLElBVlE7QUFXbkJDLGdCQUFZLElBWE87QUFZbkJDLGFBQVMsSUFaVTtBQWFuQkMsV0FBTyxJQWJZO0FBY25CQyxhQUFTLElBZFU7QUFlbkJDLFlBQVEsSUFmVztBQWdCbkJDLFlBQVEsSUFoQlc7QUFpQm5CQyxVQUFNLElBakJhOztBQW1CbkI7QUFDQUMsaUJBQWEsSUFwQk07QUFxQm5CQyxzQkFBa0IsSUFyQkM7QUFzQm5CQyxtQkFBZSxJQXRCSTtBQXVCbkJDLGlCQUFhO0FBdkJNLENBQXZCOztBQTBCQTs7Ozs7O0FBTUEsU0FBU0MsU0FBVCxDQUFtQkMsTUFBbkIsRUFBMkJDLEdBQTNCLEVBQWdDO0FBQzVCLFdBQU9ELFNBQVNDLElBQUlDLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsRUFBVCxHQUF1Q0YsSUFBSUcsU0FBSixDQUFjLENBQWQsQ0FBOUM7QUFDSDs7QUFFRDs7OztBQUlBLElBQUlDLFdBQVcsQ0FBQyxRQUFELEVBQVcsSUFBWCxFQUFpQixLQUFqQixFQUF3QixHQUF4QixDQUFmOztBQUVBO0FBQ0E7QUFDQUMsT0FBT0MsSUFBUCxDQUFZOUIsZ0JBQVosRUFBOEIrQixPQUE5QixDQUFzQyxVQUFTQyxJQUFULEVBQWU7QUFDakRKLGFBQVNHLE9BQVQsQ0FBaUIsVUFBU1IsTUFBVCxFQUFpQjtBQUM5QnZCLHlCQUFpQnNCLFVBQVVDLE1BQVYsRUFBa0JTLElBQWxCLENBQWpCLElBQTRDaEMsaUJBQWlCZ0MsSUFBakIsQ0FBNUM7QUFDSCxLQUZEO0FBR0gsQ0FKRDs7QUFNQSxJQUFJQyxZQUFZLE1BQWhCOztBQUVBLElBQUlDLG9CQUFvQixVQUF4Qjs7QUFFQTs7Ozs7Ozs7Ozs7O0FBWUEsU0FBU0MsU0FBVCxDQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkIsV0FBT0EsT0FBT0MsT0FBUCxDQUFlSCxpQkFBZixFQUFrQyxLQUFsQyxFQUF5Q0ksV0FBekMsRUFBUDtBQUNIOztBQUVEOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVNDLGtCQUFULENBQTRCSCxNQUE1QixFQUFvQztBQUNoQyxXQUFPRCxVQUFVQyxNQUFWLEVBQWtCQyxPQUFsQixDQUEwQkosU0FBMUIsRUFBcUMsTUFBckMsQ0FBUDtBQUNIOztBQUVELElBQUlPLFVBQVVDLE1BQU1ELE9BQXBCO0FBQ0EsSUFBSVYsT0FBT0QsT0FBT0MsSUFBbEI7O0FBRUEsSUFBSVksVUFBVSxDQUFkO0FBQ0E7QUFDQTtBQUNBLElBQUlDLDRCQUE0QixtSEFBaEM7O0FBRUEsU0FBU0MsU0FBVCxDQUFtQnBCLEdBQW5CLEVBQXdCcUIsS0FBeEIsRUFBK0I7QUFDM0IsUUFBSSxDQUFDN0MsaUJBQWlCd0IsR0FBakIsQ0FBRCxJQUEwQixPQUFPcUIsS0FBUCxLQUFpQixRQUEvQyxFQUF5RDtBQUNyREEsZ0JBQVEsS0FBS0EsS0FBTCxHQUFhLElBQXJCO0FBQ0gsS0FGRCxNQUVPLElBQUlyQixRQUFRLFNBQVIsSUFBcUIsQ0FBQ21CLDBCQUEwQkcsSUFBMUIsQ0FBK0JELEtBQS9CLENBQTFCLEVBQWlFO0FBQ3BFQSxnQkFBUSxNQUFNQSxNQUFNUixPQUFOLENBQWMsSUFBZCxFQUFvQixLQUFwQixDQUFOLEdBQW1DLEdBQTNDO0FBQ0g7O0FBRUQsV0FBT0UsbUJBQW1CZixHQUFuQixJQUEwQixJQUExQixHQUFpQ3FCLEtBQWpDLEdBQXlDLEtBQWhEO0FBQ0g7O0FBRUQsU0FBU0UsZ0JBQVQsQ0FBMEJDLEtBQTFCLEVBQWlDO0FBQzdCLFFBQUlDLFNBQVMsRUFBYjtBQUNBLFFBQUksT0FBT0QsS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUMzQixlQUFPQSxLQUFQO0FBQ0g7QUFDRCxRQUFJLENBQUNBLEtBQUQsSUFBVWxCLEtBQUtrQixLQUFMLEVBQVlFLE1BQVosS0FBdUIsQ0FBckMsRUFBd0M7QUFDcEMsZUFBT0QsTUFBUDtBQUNIO0FBQ0QsUUFBSUUsWUFBWXJCLEtBQUtrQixLQUFMLENBQWhCO0FBQ0EsU0FBSyxJQUFJSSxJQUFJLENBQVIsRUFBV0MsSUFBSUYsVUFBVUQsTUFBOUIsRUFBc0NFLElBQUlDLENBQTFDLEVBQTZDRCxHQUE3QyxFQUFrRDtBQUM5QyxZQUFJRSxXQUFXSCxVQUFVQyxDQUFWLENBQWY7QUFDQSxZQUFJUCxRQUFRRyxNQUFNTSxRQUFOLENBQVo7O0FBRUEsWUFBSWQsUUFBUUssS0FBUixDQUFKLEVBQW9CO0FBQ2hCLGlCQUFLLElBQUlVLElBQUksQ0FBUixFQUFXQyxNQUFNWCxNQUFNSyxNQUE1QixFQUFvQ0ssSUFBSUMsR0FBeEMsRUFBNkNELEdBQTdDLEVBQWtEO0FBQzlDTiwwQkFBVUwsVUFBVVUsUUFBVixFQUFvQlQsTUFBTVUsQ0FBTixDQUFwQixDQUFWO0FBQ0g7QUFDSixTQUpELE1BSU87QUFDSE4sc0JBQVVMLFVBQVVVLFFBQVYsRUFBb0JULEtBQXBCLENBQVY7QUFDSDtBQUNKO0FBQ0QsV0FBT0ksTUFBUDtBQUNIOztBQUVEUSxPQUFPQyxPQUFQLEdBQWlCWCxnQkFBakIiLCJmaWxlIjoic3R5bGVUb0Nzc1N0cmluZy5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDU1MgcHJvcGVydGllcyB3aGljaCBhY2NlcHQgbnVtYmVycyBidXQgYXJlIG5vdCBpbiB1bml0cyBvZiBcInB4XCIuXG4gKi9cbnZhciBpc1VuaXRsZXNzTnVtYmVyID0ge1xuICAgIGJveEZsZXg6IHRydWUsXG4gICAgYm94RmxleEdyb3VwOiB0cnVlLFxuICAgIGNvbHVtbkNvdW50OiB0cnVlLFxuICAgIGZsZXg6IHRydWUsXG4gICAgZmxleEdyb3c6IHRydWUsXG4gICAgZmxleFBvc2l0aXZlOiB0cnVlLFxuICAgIGZsZXhTaHJpbms6IHRydWUsXG4gICAgZmxleE5lZ2F0aXZlOiB0cnVlLFxuICAgIGZvbnRXZWlnaHQ6IHRydWUsXG4gICAgbGluZUNsYW1wOiB0cnVlLFxuICAgIGxpbmVIZWlnaHQ6IHRydWUsXG4gICAgb3BhY2l0eTogdHJ1ZSxcbiAgICBvcmRlcjogdHJ1ZSxcbiAgICBvcnBoYW5zOiB0cnVlLFxuICAgIHdpZG93czogdHJ1ZSxcbiAgICB6SW5kZXg6IHRydWUsXG4gICAgem9vbTogdHJ1ZSxcblxuICAgIC8vIFNWRy1yZWxhdGVkIHByb3BlcnRpZXNcbiAgICBmaWxsT3BhY2l0eTogdHJ1ZSxcbiAgICBzdHJva2VEYXNob2Zmc2V0OiB0cnVlLFxuICAgIHN0cm9rZU9wYWNpdHk6IHRydWUsXG4gICAgc3Ryb2tlV2lkdGg6IHRydWVcbn07XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHByZWZpeCB2ZW5kb3Itc3BlY2lmaWMgcHJlZml4LCBlZzogV2Via2l0XG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IHN0eWxlIG5hbWUsIGVnOiB0cmFuc2l0aW9uRHVyYXRpb25cbiAqIEByZXR1cm4ge3N0cmluZ30gc3R5bGUgbmFtZSBwcmVmaXhlZCB3aXRoIGBwcmVmaXhgLCBwcm9wZXJseSBjYW1lbENhc2VkLCBlZzpcbiAqIFdlYmtpdFRyYW5zaXRpb25EdXJhdGlvblxuICovXG5mdW5jdGlvbiBwcmVmaXhLZXkocHJlZml4LCBrZXkpIHtcbiAgICByZXR1cm4gcHJlZml4ICsga2V5LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsga2V5LnN1YnN0cmluZygxKTtcbn1cblxuLyoqXG4gKiBTdXBwb3J0IHN0eWxlIG5hbWVzIHRoYXQgbWF5IGNvbWUgcGFzc2VkIGluIHByZWZpeGVkIGJ5IGFkZGluZyBwZXJtdXRhdGlvbnNcbiAqIG9mIHZlbmRvciBwcmVmaXhlcy5cbiAqL1xudmFyIHByZWZpeGVzID0gWydXZWJraXQnLCAnbXMnLCAnTW96JywgJ08nXTtcblxuLy8gVXNpbmcgT2JqZWN0LmtleXMgaGVyZSwgb3IgZWxzZSB0aGUgdmFuaWxsYSBmb3ItaW4gbG9vcCBtYWtlcyBJRTggZ28gaW50byBhblxuLy8gaW5maW5pdGUgbG9vcCwgYmVjYXVzZSBpdCBpdGVyYXRlcyBvdmVyIHRoZSBuZXdseSBhZGRlZCBwcm9wcyB0b28uXG5PYmplY3Qua2V5cyhpc1VuaXRsZXNzTnVtYmVyKS5mb3JFYWNoKGZ1bmN0aW9uKHByb3ApIHtcbiAgICBwcmVmaXhlcy5mb3JFYWNoKGZ1bmN0aW9uKHByZWZpeCkge1xuICAgICAgICBpc1VuaXRsZXNzTnVtYmVyW3ByZWZpeEtleShwcmVmaXgsIHByb3ApXSA9IGlzVW5pdGxlc3NOdW1iZXJbcHJvcF07XG4gICAgfSk7XG59KTtcblxudmFyIG1zUGF0dGVybiA9IC9ebXMtLztcblxudmFyIF91cHBlcmNhc2VQYXR0ZXJuID0gLyhbQS1aXSkvZztcblxuLyoqXG4gKiBIeXBoZW5hdGVzIGEgY2FtZWxjYXNlZCBzdHJpbmcsIGZvciBleGFtcGxlOlxuICpcbiAqICAgPiBoeXBoZW5hdGUoJ2JhY2tncm91bmRDb2xvcicpXG4gKiAgIDwgXCJiYWNrZ3JvdW5kLWNvbG9yXCJcbiAqXG4gKiBGb3IgQ1NTIHN0eWxlIG5hbWVzLCB1c2UgYGh5cGhlbmF0ZVN0eWxlTmFtZWAgaW5zdGVhZCB3aGljaCB3b3JrcyBwcm9wZXJseVxuICogd2l0aCBhbGwgdmVuZG9yIHByZWZpeGVzLCBpbmNsdWRpbmcgYG1zYC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGh5cGhlbmF0ZShzdHJpbmcpIHtcbiAgICByZXR1cm4gc3RyaW5nLnJlcGxhY2UoX3VwcGVyY2FzZVBhdHRlcm4sICctJDEnKS50b0xvd2VyQ2FzZSgpO1xufVxuXG4vKipcbiAqIEh5cGhlbmF0ZXMgYSBjYW1lbGNhc2VkIENTUyBwcm9wZXJ0eSBuYW1lLCBmb3IgZXhhbXBsZTpcbiAqXG4gKiAgID4gaHlwaGVuYXRlU3R5bGVOYW1lKCdiYWNrZ3JvdW5kQ29sb3InKVxuICogICA8IFwiYmFja2dyb3VuZC1jb2xvclwiXG4gKiAgID4gaHlwaGVuYXRlU3R5bGVOYW1lKCdNb3pUcmFuc2l0aW9uJylcbiAqICAgPCBcIi1tb3otdHJhbnNpdGlvblwiXG4gKiAgID4gaHlwaGVuYXRlU3R5bGVOYW1lKCdtc1RyYW5zaXRpb24nKVxuICogICA8IFwiLW1zLXRyYW5zaXRpb25cIlxuICpcbiAqIEFzIE1vZGVybml6ciBzdWdnZXN0cyAoaHR0cDovL21vZGVybml6ci5jb20vZG9jcy8jcHJlZml4ZWQpLCBhbiBgbXNgIHByZWZpeFxuICogaXMgY29udmVydGVkIHRvIGAtbXMtYC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGh5cGhlbmF0ZVN0eWxlTmFtZShzdHJpbmcpIHtcbiAgICByZXR1cm4gaHlwaGVuYXRlKHN0cmluZykucmVwbGFjZShtc1BhdHRlcm4sICctbXMtJyk7XG59XG5cbnZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbnZhciBrZXlzID0gT2JqZWN0LmtleXM7XG5cbnZhciBjb3VudGVyID0gMTtcbi8vIEZvbGxvd3Mgc3ludGF4IGF0IGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0NTUy9jb250ZW50LFxuLy8gaW5jbHVkaW5nIG11bHRpcGxlIHNwYWNlIHNlcGFyYXRlZCB2YWx1ZXMuXG52YXIgdW5xdW90ZWRDb250ZW50VmFsdWVSZWdleCA9IC9eKG5vcm1hbHxub25lfChcXGIodXJsXFwoW14pXSpcXCl8Y2hhcHRlcl9jb3VudGVyfGF0dHJcXChbXildKlxcKXwobm8tKT8ob3BlbnxjbG9zZSktcXVvdGV8aW5oZXJpdCkoKFxcYlxccyopfCR8XFxzKykpKykkLztcblxuZnVuY3Rpb24gYnVpbGRSdWxlKGtleSwgdmFsdWUpIHtcbiAgICBpZiAoIWlzVW5pdGxlc3NOdW1iZXJba2V5XSAmJiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHZhbHVlID0gJycgKyB2YWx1ZSArICdweCc7XG4gICAgfSBlbHNlIGlmIChrZXkgPT09ICdjb250ZW50JyAmJiAhdW5xdW90ZWRDb250ZW50VmFsdWVSZWdleC50ZXN0KHZhbHVlKSkge1xuICAgICAgICB2YWx1ZSA9IFwiJ1wiICsgdmFsdWUucmVwbGFjZSgvJy9nLCBcIlxcXFwnXCIpICsgXCInXCI7XG4gICAgfVxuXG4gICAgcmV0dXJuIGh5cGhlbmF0ZVN0eWxlTmFtZShrZXkpICsgJzogJyArIHZhbHVlICsgJzsgICc7XG59XG5cbmZ1bmN0aW9uIHN0eWxlVG9Dc3NTdHJpbmcocnVsZXMpIHtcbiAgICB2YXIgcmVzdWx0ID0gJydcbiAgICBpZiAodHlwZW9mIHJ1bGVzID09PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gcnVsZXNcbiAgICB9XG4gICAgaWYgKCFydWxlcyB8fCBrZXlzKHJ1bGVzKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgdmFyIHN0eWxlS2V5cyA9IGtleXMocnVsZXMpO1xuICAgIGZvciAodmFyIGogPSAwLCBsID0gc3R5bGVLZXlzLmxlbmd0aDsgaiA8IGw7IGorKykge1xuICAgICAgICB2YXIgc3R5bGVLZXkgPSBzdHlsZUtleXNbal07XG4gICAgICAgIHZhciB2YWx1ZSA9IHJ1bGVzW3N0eWxlS2V5XTtcblxuICAgICAgICBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSB2YWx1ZS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIHJlc3VsdCArPSBidWlsZFJ1bGUoc3R5bGVLZXksIHZhbHVlW2ldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc3VsdCArPSBidWlsZFJ1bGUoc3R5bGVLZXksIHZhbHVlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHN0eWxlVG9Dc3NTdHJpbmc7XG4iXX0=