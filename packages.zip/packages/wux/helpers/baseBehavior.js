'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

/**
 * Simple bind, faster than native
 *
 * @param {Function} fn
 * @param {Object} ctx
 * @return {Function}
 */
var bind = function bind(fn, ctx) {
    return function () {
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return args.length ? fn.apply(ctx, args) : fn.call(ctx);
    };
};

/**
 * Object assign
 */
var assign = function assign() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
    }

    return Object.assign.apply(Object, [{}].concat(args));
};

exports.default = Behavior({
    properties: {
        visible: {
            type: Boolean,
            value: false
        }
    },
    methods: {
        /**
         * 合并参数并绑定方法
         *
         * @param {Object} opts 参数对象
         * @param {Object} fns 方法挂载的属性
         */
        $$mergeOptionsAndBindMethods: function $$mergeOptionsAndBindMethods() {
            var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var fns = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.fns;

            var options = Object.assign({}, opts);

            for (var key in options) {
                if (options.hasOwnProperty(key) && typeof options[key] === 'function') {
                    fns[key] = bind(options[key], this);
                    delete options[key];
                }
            }

            return options;
        },

        /**
         * Promise setData
         * @param {Array} args 参数对象
         */
        $$setData: function $$setData() {
            var _this = this;

            for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
                args[_key3] = arguments[_key3];
            }

            var params = assign.apply(undefined, [{}].concat(_toConsumableArray(args)));

            return new Promise(function (resolve) {
                _this.setData(params, resolve);
            });
        },

        /**
         * 延迟指定时间执行回调函数
         * @param {Function} callback 回调函数
         * @param {Number} timeout 延迟时间
         */
        $$requestAnimationFrame: function $$requestAnimationFrame() {
            var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};
            var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000 / 60;

            return new Promise(function (resolve) {
                return setTimeout(resolve, timeout);
            }).then(callback);
        }
    },
    /**
     * 组件生命周期函数，在组件实例进入页面节点树时执行
     */
    created: function created() {
        this.fns = {};
    },

    /**
     * 组件生命周期函数，在组件实例被从页面节点树移除时执行
     */
    detached: function detached() {
        this.fns = {};
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhc2VCZWhhdmlvci5qcyJdLCJuYW1lcyI6WyJiaW5kIiwiZm4iLCJjdHgiLCJhcmdzIiwibGVuZ3RoIiwiYXBwbHkiLCJjYWxsIiwiYXNzaWduIiwiT2JqZWN0IiwiQmVoYXZpb3IiLCJwcm9wZXJ0aWVzIiwidmlzaWJsZSIsInR5cGUiLCJCb29sZWFuIiwidmFsdWUiLCJtZXRob2RzIiwiJCRtZXJnZU9wdGlvbnNBbmRCaW5kTWV0aG9kcyIsIm9wdHMiLCJmbnMiLCJvcHRpb25zIiwia2V5IiwiaGFzT3duUHJvcGVydHkiLCIkJHNldERhdGEiLCJwYXJhbXMiLCJQcm9taXNlIiwicmVzb2x2ZSIsInNldERhdGEiLCIkJHJlcXVlc3RBbmltYXRpb25GcmFtZSIsImNhbGxiYWNrIiwidGltZW91dCIsInNldFRpbWVvdXQiLCJ0aGVuIiwiY3JlYXRlZCIsImRldGFjaGVkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBOzs7Ozs7O0FBT0EsSUFBTUEsT0FBTyxTQUFQQSxJQUFPLENBQUNDLEVBQUQsRUFBS0MsR0FBTCxFQUFhO0FBQ3RCLFdBQU8sWUFBYTtBQUFBLDBDQUFUQyxJQUFTO0FBQVRBLGdCQUFTO0FBQUE7O0FBQ2hCLGVBQU9BLEtBQUtDLE1BQUwsR0FBY0gsR0FBR0ksS0FBSCxDQUFTSCxHQUFULEVBQWNDLElBQWQsQ0FBZCxHQUFvQ0YsR0FBR0ssSUFBSCxDQUFRSixHQUFSLENBQTNDO0FBQ0gsS0FGRDtBQUdILENBSkQ7O0FBTUE7OztBQUdBLElBQU1LLFNBQVMsU0FBVEEsTUFBUztBQUFBLHVDQUFJSixJQUFKO0FBQUlBLFlBQUo7QUFBQTs7QUFBQSxXQUFhSyxPQUFPRCxNQUFQLGdCQUFjLEVBQWQsU0FBcUJKLElBQXJCLEVBQWI7QUFBQSxDQUFmOztrQkFFZU0sU0FBUztBQUNwQkMsZ0JBQVk7QUFDUkMsaUJBQVM7QUFDTEMsa0JBQU1DLE9BREQ7QUFFTEMsbUJBQU87QUFGRjtBQURELEtBRFE7QUFPcEJDLGFBQVM7QUFDTDs7Ozs7O0FBTUFDLG9DQVBLLDBDQU9vRDtBQUFBLGdCQUEzQkMsSUFBMkIsdUVBQXBCLEVBQW9CO0FBQUEsZ0JBQWhCQyxHQUFnQix1RUFBVixLQUFLQSxHQUFLOztBQUNyRCxnQkFBTUMsVUFBVVgsT0FBT0QsTUFBUCxDQUFjLEVBQWQsRUFBa0JVLElBQWxCLENBQWhCOztBQUVBLGlCQUFLLElBQU1HLEdBQVgsSUFBa0JELE9BQWxCLEVBQTJCO0FBQ3ZCLG9CQUFJQSxRQUFRRSxjQUFSLENBQXVCRCxHQUF2QixLQUErQixPQUFPRCxRQUFRQyxHQUFSLENBQVAsS0FBd0IsVUFBM0QsRUFBdUU7QUFDbkVGLHdCQUFJRSxHQUFKLElBQVdwQixLQUFLbUIsUUFBUUMsR0FBUixDQUFMLEVBQW1CLElBQW5CLENBQVg7QUFDQSwyQkFBT0QsUUFBUUMsR0FBUixDQUFQO0FBQ0g7QUFDSjs7QUFFRCxtQkFBT0QsT0FBUDtBQUNILFNBbEJJOztBQW1CTDs7OztBQUlBRyxpQkF2QkssdUJBdUJlO0FBQUE7O0FBQUEsK0NBQU5uQixJQUFNO0FBQU5BLG9CQUFNO0FBQUE7O0FBQ2hCLGdCQUFNb0IsU0FBU2hCLHlCQUFPLEVBQVAsNEJBQWNKLElBQWQsR0FBZjs7QUFFQSxtQkFBTyxJQUFJcUIsT0FBSixDQUFZLFVBQUNDLE9BQUQsRUFBYTtBQUM1QixzQkFBS0MsT0FBTCxDQUFhSCxNQUFiLEVBQXFCRSxPQUFyQjtBQUNILGFBRk0sQ0FBUDtBQUdILFNBN0JJOztBQThCTDs7Ozs7QUFLQUUsK0JBbkNLLHFDQW1DOEQ7QUFBQSxnQkFBMUNDLFFBQTBDLHVFQUEvQixZQUFNLENBQUUsQ0FBdUI7QUFBQSxnQkFBckJDLE9BQXFCLHVFQUFYLE9BQU8sRUFBSTs7QUFDL0QsbUJBQU8sSUFBSUwsT0FBSixDQUFZLFVBQUNDLE9BQUQ7QUFBQSx1QkFBYUssV0FBV0wsT0FBWCxFQUFvQkksT0FBcEIsQ0FBYjtBQUFBLGFBQVosRUFBdURFLElBQXZELENBQTRESCxRQUE1RCxDQUFQO0FBQ0g7QUFyQ0ksS0FQVztBQThDcEI7OztBQUdBSSxXQWpEb0IscUJBaURUO0FBQ1AsYUFBS2QsR0FBTCxHQUFXLEVBQVg7QUFDSCxLQW5EbUI7O0FBb0RwQjs7O0FBR0FlLFlBdkRvQixzQkF1RFI7QUFDUixhQUFLZixHQUFMLEdBQVcsRUFBWDtBQUNIO0FBekRtQixDQUFULEMiLCJmaWxlIjoiYmFzZUJlaGF2aW9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBTaW1wbGUgYmluZCwgZmFzdGVyIHRoYW4gbmF0aXZlXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAqIEBwYXJhbSB7T2JqZWN0fSBjdHhcbiAqIEByZXR1cm4ge0Z1bmN0aW9ufVxuICovXG5jb25zdCBiaW5kID0gKGZuLCBjdHgpID0+IHtcbiAgICByZXR1cm4gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgcmV0dXJuIGFyZ3MubGVuZ3RoID8gZm4uYXBwbHkoY3R4LCBhcmdzKSA6IGZuLmNhbGwoY3R4KVxuICAgIH1cbn1cblxuLyoqXG4gKiBPYmplY3QgYXNzaWduXG4gKi9cbmNvbnN0IGFzc2lnbiA9ICguLi5hcmdzKSA9PiBPYmplY3QuYXNzaWduKHt9LCAuLi5hcmdzKVxuXG5leHBvcnQgZGVmYXVsdCBCZWhhdmlvcih7XG4gICAgcHJvcGVydGllczoge1xuICAgICAgICB2aXNpYmxlOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IGZhbHNlLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICAvKipcbiAgICAgICAgICog5ZCI5bm25Y+C5pWw5bm257uR5a6a5pa55rOVXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzIOWPguaVsOWvueixoVxuICAgICAgICAgKiBAcGFyYW0ge09iamVjdH0gZm5zIOaWueazleaMgui9veeahOWxnuaAp1xuICAgICAgICAgKi9cbiAgICAgICAgJCRtZXJnZU9wdGlvbnNBbmRCaW5kTWV0aG9kcyAob3B0cyA9IHt9LCBmbnMgPSB0aGlzLmZucykge1xuICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdHMpXG5cbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShrZXkpICYmIHR5cGVvZiBvcHRpb25zW2tleV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgZm5zW2tleV0gPSBiaW5kKG9wdGlvbnNba2V5XSwgdGhpcylcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9wdGlvbnNba2V5XVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIG9wdGlvbnNcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb21pc2Ugc2V0RGF0YVxuICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBhcmdzIOWPguaVsOWvueixoVxuICAgICAgICAgKi9cbiAgICAgICAgJCRzZXREYXRhICguLi5hcmdzKSB7XG4gICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBhc3NpZ24oe30sIC4uLmFyZ3MpXG5cbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMsIHJlc29sdmUpXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog5bu26L+f5oyH5a6a5pe26Ze05omn6KGM5Zue6LCD5Ye95pWwXG4gICAgICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIOWbnuiwg+WHveaVsFxuICAgICAgICAgKiBAcGFyYW0ge051bWJlcn0gdGltZW91dCDlu7bov5/ml7bpl7RcbiAgICAgICAgICovXG4gICAgICAgICQkcmVxdWVzdEFuaW1hdGlvbkZyYW1lIChjYWxsYmFjayA9ICgpID0+IHt9LCB0aW1lb3V0ID0gMTAwMCAvIDYwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZW91dCkpLnRoZW4oY2FsbGJhY2spXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDnu4Tku7bnlJ/lkb3lkajmnJ/lh73mlbDvvIzlnKjnu4Tku7blrp7kvovov5vlhaXpobXpnaLoioLngrnmoJHml7bmiafooYxcbiAgICAgKi9cbiAgICBjcmVhdGVkICgpIHtcbiAgICAgICAgdGhpcy5mbnMgPSB7fVxuICAgIH0sXG4gICAgLyoqXG4gICAgICog57uE5Lu255Sf5ZG95ZGo5pyf5Ye95pWw77yM5Zyo57uE5Lu25a6e5L6L6KKr5LuO6aG16Z2i6IqC54K55qCR56e76Zmk5pe25omn6KGMXG4gICAgICovXG4gICAgZGV0YWNoZWQgKCkge1xuICAgICAgICB0aGlzLmZucyA9IHt9XG4gICAgfSxcbn0pXG4iXX0=