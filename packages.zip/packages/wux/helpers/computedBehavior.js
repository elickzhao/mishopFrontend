'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; /**
                                                                                                                                                                                                                                                                               * weapp custom component extend behavior -- computed
                                                                                                                                                                                                                                                                               * https://github.com/wechat-miniprogram/computed
                                                                                                                                                                                                                                                                               */

var _isEmpty = require('./isEmpty.js');

var _isEmpty2 = _interopRequireDefault(_isEmpty);

var _shallowEqual = require('./shallowEqual.js');

var _shallowEqual2 = _interopRequireDefault(_shallowEqual);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = Behavior({
    lifetimes: {
        created: function created() {
            this._computedCache = {};
            this._originalSetData = this.setData;
            this.setData = this._setData;
            this._doingSetData = false;
        }
    },
    definitionFilter: function definitionFilter(defFields) {
        var computed = defFields.computed || {};
        var computedKeys = Object.keys(computed);

        // 计算 computed
        var calcComputed = function calcComputed(scope) {
            var needUpdate = {};
            var computedCache = scope._computedCache || scope.data;

            for (var i = 0, len = computedKeys.length; i < len; i++) {
                var key = computedKeys[i];
                var getter = computed[key];

                if (typeof getter === 'function') {
                    var value = getter.call(scope);

                    if (!(0, _shallowEqual2.default)(computedCache[key], value)) {
                        needUpdate[key] = value;
                        computedCache[key] = value;
                    }
                }
            }

            return needUpdate;
        };

        // 初始化 computed
        var initComputed = function initComputed() {
            defFields.data = defFields.data || {};

            // 先将 properties 里的字段写入到 data 中
            var data = defFields.data;
            var properties = defFields.properties;
            var hasOwnProperty = Object.prototype.hasOwnProperty;
            if (properties) {
                // eslint-disable-next-line complexity
                Object.keys(properties).forEach(function (key) {
                    var value = properties[key];
                    var oldObserver = void 0;

                    // eslint-disable-next-line max-len
                    if (value === null || value === Number || value === String || value === Boolean || value === Object || value === Array) {
                        properties[key] = {
                            type: value
                        };
                    } else if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object') {
                        if (hasOwnProperty.call(value, 'value')) {
                            // 处理值
                            data[key] = value.value;
                        }

                        if (hasOwnProperty.call(value, 'observer')) {
                            if (typeof value.observer === 'function') {
                                oldObserver = value.observer;
                            } else if (typeof value.observer === 'string') {
                                oldObserver = defFields.methods[value.observer];
                            }
                        }
                    }

                    // 追加 observer，用于监听变动
                    properties[key].observer = function () {
                        var originalSetData = this._originalSetData;

                        if (this._doingSetData) {
                            // eslint-disable-next-line no-console
                            console.warn('can\'t call setData in computed getter function!');
                            return;
                        }

                        this._doingSetData = true;

                        // 计算 computed
                        var needUpdate = calcComputed(this);

                        // 做 computed 属性的 setData
                        if (!(0, _isEmpty2.default)(needUpdate)) {
                            originalSetData.call(this, needUpdate);
                        }

                        this._doingSetData = false;

                        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
                            args[_key] = arguments[_key];
                        }

                        if (oldObserver) oldObserver.apply(this, args);
                    };
                });
            }

            // 计算 computed
            calcComputed(defFields, true);
        };

        initComputed();

        defFields.methods = defFields.methods || {};
        defFields.methods._setData = function (data, callback) {
            var originalSetData = this._originalSetData;

            if (this._doingSetData) {
                // eslint-disable-next-line no-console
                console.warn('can\'t call setData in computed getter function!');
                return;
            }

            this._doingSetData = true;

            // TODO 过滤掉 data 中的 computed 字段
            var dataKeys = Object.keys(data);
            for (var i = 0, len = dataKeys.length; i < len; i++) {
                var key = dataKeys[i];

                if (computed[key]) delete data[key];
            }

            // 做 data 属性的 setData
            originalSetData.call(this, data, callback);

            // 计算 computed
            var needUpdate = calcComputed(this);

            // 做 computed 属性的 setData
            if (!(0, _isEmpty2.default)(needUpdate)) {
                originalSetData.call(this, needUpdate);
            }

            this._doingSetData = false;
        };
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXB1dGVkQmVoYXZpb3IuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkJlaGF2aW9yIiwibGlmZXRpbWVzIiwiY3JlYXRlZCIsIl9jb21wdXRlZENhY2hlIiwiX29yaWdpbmFsU2V0RGF0YSIsInNldERhdGEiLCJfc2V0RGF0YSIsIl9kb2luZ1NldERhdGEiLCJkZWZpbml0aW9uRmlsdGVyIiwiZGVmRmllbGRzIiwiY29tcHV0ZWQiLCJjb21wdXRlZEtleXMiLCJPYmplY3QiLCJrZXlzIiwiY2FsY0NvbXB1dGVkIiwic2NvcGUiLCJuZWVkVXBkYXRlIiwiY29tcHV0ZWRDYWNoZSIsImRhdGEiLCJpIiwibGVuIiwibGVuZ3RoIiwia2V5IiwiZ2V0dGVyIiwidmFsdWUiLCJjYWxsIiwiaW5pdENvbXB1dGVkIiwicHJvcGVydGllcyIsImhhc093blByb3BlcnR5IiwicHJvdG90eXBlIiwiZm9yRWFjaCIsIm9sZE9ic2VydmVyIiwiTnVtYmVyIiwiU3RyaW5nIiwiQm9vbGVhbiIsIkFycmF5IiwidHlwZSIsIm9ic2VydmVyIiwibWV0aG9kcyIsIm9yaWdpbmFsU2V0RGF0YSIsImNvbnNvbGUiLCJ3YXJuIiwiYXJncyIsImFwcGx5IiwiY2FsbGJhY2siLCJkYXRhS2V5cyJdLCJtYXBwaW5ncyI6Ijs7OFFBQUE7Ozs7O0FBS0E7Ozs7QUFDQTs7Ozs7O0FBRUFBLE9BQU9DLE9BQVAsR0FBaUJDLFNBQVM7QUFDdEJDLGVBQVc7QUFDUEMsZUFETyxxQkFDSTtBQUNQLGlCQUFLQyxjQUFMLEdBQXNCLEVBQXRCO0FBQ0EsaUJBQUtDLGdCQUFMLEdBQXdCLEtBQUtDLE9BQTdCO0FBQ0EsaUJBQUtBLE9BQUwsR0FBZSxLQUFLQyxRQUFwQjtBQUNBLGlCQUFLQyxhQUFMLEdBQXFCLEtBQXJCO0FBQ0g7QUFOTSxLQURXO0FBU3RCQyxvQkFUc0IsNEJBU0pDLFNBVEksRUFTTztBQUN6QixZQUFNQyxXQUFXRCxVQUFVQyxRQUFWLElBQXNCLEVBQXZDO0FBQ0EsWUFBTUMsZUFBZUMsT0FBT0MsSUFBUCxDQUFZSCxRQUFaLENBQXJCOztBQUVBO0FBQ0EsWUFBTUksZUFBZSxTQUFmQSxZQUFlLENBQUNDLEtBQUQsRUFBVztBQUM1QixnQkFBTUMsYUFBYSxFQUFuQjtBQUNBLGdCQUFNQyxnQkFBZ0JGLE1BQU1aLGNBQU4sSUFBd0JZLE1BQU1HLElBQXBEOztBQUVBLGlCQUFLLElBQUlDLElBQUksQ0FBUixFQUFXQyxNQUFNVCxhQUFhVSxNQUFuQyxFQUEyQ0YsSUFBSUMsR0FBL0MsRUFBb0RELEdBQXBELEVBQXlEO0FBQ3JELG9CQUFNRyxNQUFNWCxhQUFhUSxDQUFiLENBQVo7QUFDQSxvQkFBTUksU0FBU2IsU0FBU1ksR0FBVCxDQUFmOztBQUVBLG9CQUFJLE9BQU9DLE1BQVAsS0FBa0IsVUFBdEIsRUFBa0M7QUFDOUIsd0JBQU1DLFFBQVFELE9BQU9FLElBQVAsQ0FBWVYsS0FBWixDQUFkOztBQUVBLHdCQUFJLENBQUMsNEJBQWFFLGNBQWNLLEdBQWQsQ0FBYixFQUFpQ0UsS0FBakMsQ0FBTCxFQUE4QztBQUMxQ1IsbUNBQVdNLEdBQVgsSUFBa0JFLEtBQWxCO0FBQ0FQLHNDQUFjSyxHQUFkLElBQXFCRSxLQUFyQjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxtQkFBT1IsVUFBUDtBQUNILFNBbkJEOztBQXFCQTtBQUNBLFlBQU1VLGVBQWUsU0FBZkEsWUFBZSxHQUFNO0FBQ3ZCakIsc0JBQVVTLElBQVYsR0FBaUJULFVBQVVTLElBQVYsSUFBa0IsRUFBbkM7O0FBRUE7QUFDQSxnQkFBTUEsT0FBT1QsVUFBVVMsSUFBdkI7QUFDQSxnQkFBTVMsYUFBYWxCLFVBQVVrQixVQUE3QjtBQUNBLGdCQUFNQyxpQkFBaUJoQixPQUFPaUIsU0FBUCxDQUFpQkQsY0FBeEM7QUFDQSxnQkFBSUQsVUFBSixFQUFnQjtBQUNaO0FBQ0FmLHVCQUFPQyxJQUFQLENBQVljLFVBQVosRUFBd0JHLE9BQXhCLENBQWdDLFVBQUNSLEdBQUQsRUFBUztBQUNyQyx3QkFBTUUsUUFBUUcsV0FBV0wsR0FBWCxDQUFkO0FBQ0Esd0JBQUlTLG9CQUFKOztBQUVBO0FBQ0Esd0JBQUlQLFVBQVUsSUFBVixJQUFrQkEsVUFBVVEsTUFBNUIsSUFBc0NSLFVBQVVTLE1BQWhELElBQTBEVCxVQUFVVSxPQUFwRSxJQUErRVYsVUFBVVosTUFBekYsSUFBbUdZLFVBQVVXLEtBQWpILEVBQXdIO0FBQ3BIUixtQ0FBV0wsR0FBWCxJQUFrQjtBQUNkYyxrQ0FBTVo7QUFEUSx5QkFBbEI7QUFHSCxxQkFKRCxNQUlPLElBQUksUUFBT0EsS0FBUCx5Q0FBT0EsS0FBUCxPQUFpQixRQUFyQixFQUErQjtBQUNsQyw0QkFBSUksZUFBZUgsSUFBZixDQUFvQkQsS0FBcEIsRUFBMkIsT0FBM0IsQ0FBSixFQUF5QztBQUNyQztBQUNBTixpQ0FBS0ksR0FBTCxJQUFZRSxNQUFNQSxLQUFsQjtBQUNIOztBQUVELDRCQUFJSSxlQUFlSCxJQUFmLENBQW9CRCxLQUFwQixFQUEyQixVQUEzQixDQUFKLEVBQTRDO0FBQ3hDLGdDQUFJLE9BQU9BLE1BQU1hLFFBQWIsS0FBMEIsVUFBOUIsRUFBMEM7QUFDdENOLDhDQUFjUCxNQUFNYSxRQUFwQjtBQUNILDZCQUZELE1BRU8sSUFBSSxPQUFPYixNQUFNYSxRQUFiLEtBQTBCLFFBQTlCLEVBQXdDO0FBQzNDTiw4Q0FBY3RCLFVBQVU2QixPQUFWLENBQWtCZCxNQUFNYSxRQUF4QixDQUFkO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0FWLCtCQUFXTCxHQUFYLEVBQWdCZSxRQUFoQixHQUEyQixZQUFtQjtBQUMxQyw0QkFBTUUsa0JBQWtCLEtBQUtuQyxnQkFBN0I7O0FBRUEsNEJBQUksS0FBS0csYUFBVCxFQUF3QjtBQUNwQjtBQUNBaUMsb0NBQVFDLElBQVIsQ0FBYSxrREFBYjtBQUNBO0FBQ0g7O0FBRUQsNkJBQUtsQyxhQUFMLEdBQXFCLElBQXJCOztBQUVBO0FBQ0EsNEJBQU1TLGFBQWFGLGFBQWEsSUFBYixDQUFuQjs7QUFFQTtBQUNBLDRCQUFJLENBQUMsdUJBQVFFLFVBQVIsQ0FBTCxFQUEwQjtBQUN0QnVCLDRDQUFnQmQsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkJULFVBQTNCO0FBQ0g7O0FBRUQsNkJBQUtULGFBQUwsR0FBcUIsS0FBckI7O0FBbkIwQywwREFBTm1DLElBQU07QUFBTkEsZ0NBQU07QUFBQTs7QUFxQjFDLDRCQUFJWCxXQUFKLEVBQWlCQSxZQUFZWSxLQUFaLENBQWtCLElBQWxCLEVBQXdCRCxJQUF4QjtBQUNwQixxQkF0QkQ7QUF1QkgsaUJBaEREO0FBaURIOztBQUVEO0FBQ0E1Qix5QkFBYUwsU0FBYixFQUF3QixJQUF4QjtBQUNILFNBOUREOztBQWdFQWlCOztBQUVBakIsa0JBQVU2QixPQUFWLEdBQW9CN0IsVUFBVTZCLE9BQVYsSUFBcUIsRUFBekM7QUFDQTdCLGtCQUFVNkIsT0FBVixDQUFrQmhDLFFBQWxCLEdBQTZCLFVBQVVZLElBQVYsRUFBZ0IwQixRQUFoQixFQUEwQjtBQUNuRCxnQkFBTUwsa0JBQWtCLEtBQUtuQyxnQkFBN0I7O0FBRUEsZ0JBQUksS0FBS0csYUFBVCxFQUF3QjtBQUNwQjtBQUNBaUMsd0JBQVFDLElBQVIsQ0FBYSxrREFBYjtBQUNBO0FBQ0g7O0FBRUQsaUJBQUtsQyxhQUFMLEdBQXFCLElBQXJCOztBQUVBO0FBQ0EsZ0JBQU1zQyxXQUFXakMsT0FBT0MsSUFBUCxDQUFZSyxJQUFaLENBQWpCO0FBQ0EsaUJBQUssSUFBSUMsSUFBSSxDQUFSLEVBQVdDLE1BQU15QixTQUFTeEIsTUFBL0IsRUFBdUNGLElBQUlDLEdBQTNDLEVBQWdERCxHQUFoRCxFQUFxRDtBQUNqRCxvQkFBTUcsTUFBTXVCLFNBQVMxQixDQUFULENBQVo7O0FBRUEsb0JBQUlULFNBQVNZLEdBQVQsQ0FBSixFQUFtQixPQUFPSixLQUFLSSxHQUFMLENBQVA7QUFDdEI7O0FBRUQ7QUFDQWlCLDRCQUFnQmQsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkJQLElBQTNCLEVBQWlDMEIsUUFBakM7O0FBRUE7QUFDQSxnQkFBTTVCLGFBQWFGLGFBQWEsSUFBYixDQUFuQjs7QUFFQTtBQUNBLGdCQUFJLENBQUMsdUJBQVFFLFVBQVIsQ0FBTCxFQUEwQjtBQUN0QnVCLGdDQUFnQmQsSUFBaEIsQ0FBcUIsSUFBckIsRUFBMkJULFVBQTNCO0FBQ0g7O0FBRUQsaUJBQUtULGFBQUwsR0FBcUIsS0FBckI7QUFDSCxTQS9CRDtBQWdDSDtBQXZJcUIsQ0FBVCxDQUFqQiIsImZpbGUiOiJjb21wdXRlZEJlaGF2aW9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiB3ZWFwcCBjdXN0b20gY29tcG9uZW50IGV4dGVuZCBiZWhhdmlvciAtLSBjb21wdXRlZFxuICogaHR0cHM6Ly9naXRodWIuY29tL3dlY2hhdC1taW5pcHJvZ3JhbS9jb21wdXRlZFxuICovXG5cbmltcG9ydCBpc0VtcHR5IGZyb20gJy4vaXNFbXB0eSdcbmltcG9ydCBzaGFsbG93RXF1YWwgZnJvbSAnLi9zaGFsbG93RXF1YWwnXG5cbm1vZHVsZS5leHBvcnRzID0gQmVoYXZpb3Ioe1xuICAgIGxpZmV0aW1lczoge1xuICAgICAgICBjcmVhdGVkICgpIHtcbiAgICAgICAgICAgIHRoaXMuX2NvbXB1dGVkQ2FjaGUgPSB7fVxuICAgICAgICAgICAgdGhpcy5fb3JpZ2luYWxTZXREYXRhID0gdGhpcy5zZXREYXRhXG4gICAgICAgICAgICB0aGlzLnNldERhdGEgPSB0aGlzLl9zZXREYXRhXG4gICAgICAgICAgICB0aGlzLl9kb2luZ1NldERhdGEgPSBmYWxzZVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgZGVmaW5pdGlvbkZpbHRlciAoZGVmRmllbGRzKSB7XG4gICAgICAgIGNvbnN0IGNvbXB1dGVkID0gZGVmRmllbGRzLmNvbXB1dGVkIHx8IHt9XG4gICAgICAgIGNvbnN0IGNvbXB1dGVkS2V5cyA9IE9iamVjdC5rZXlzKGNvbXB1dGVkKVxuXG4gICAgICAgIC8vIOiuoeeulyBjb21wdXRlZFxuICAgICAgICBjb25zdCBjYWxjQ29tcHV0ZWQgPSAoc2NvcGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5lZWRVcGRhdGUgPSB7fVxuICAgICAgICAgICAgY29uc3QgY29tcHV0ZWRDYWNoZSA9IHNjb3BlLl9jb21wdXRlZENhY2hlIHx8IHNjb3BlLmRhdGFcblxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGNvbXB1dGVkS2V5cy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGtleSA9IGNvbXB1dGVkS2V5c1tpXVxuICAgICAgICAgICAgICAgIGNvbnN0IGdldHRlciA9IGNvbXB1dGVkW2tleV1cblxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZ2V0dGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0dGVyLmNhbGwoc2NvcGUpXG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzaGFsbG93RXF1YWwoY29tcHV0ZWRDYWNoZVtrZXldLCB2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5lZWRVcGRhdGVba2V5XSA9IHZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wdXRlZENhY2hlW2tleV0gPSB2YWx1ZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gbmVlZFVwZGF0ZVxuICAgICAgICB9XG5cbiAgICAgICAgLy8g5Yid5aeL5YyWIGNvbXB1dGVkXG4gICAgICAgIGNvbnN0IGluaXRDb21wdXRlZCA9ICgpID0+IHtcbiAgICAgICAgICAgIGRlZkZpZWxkcy5kYXRhID0gZGVmRmllbGRzLmRhdGEgfHwge31cblxuICAgICAgICAgICAgLy8g5YWI5bCGIHByb3BlcnRpZXMg6YeM55qE5a2X5q615YaZ5YWl5YiwIGRhdGEg5LitXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gZGVmRmllbGRzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IHByb3BlcnRpZXMgPSBkZWZGaWVsZHMucHJvcGVydGllc1xuICAgICAgICAgICAgY29uc3QgaGFzT3duUHJvcGVydHkgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcykge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb21wbGV4aXR5XG4gICAgICAgICAgICAgICAgT2JqZWN0LmtleXMocHJvcGVydGllcykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gcHJvcGVydGllc1trZXldXG4gICAgICAgICAgICAgICAgICAgIGxldCBvbGRPYnNlcnZlclxuXG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtbGVuXG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gTnVtYmVyIHx8IHZhbHVlID09PSBTdHJpbmcgfHwgdmFsdWUgPT09IEJvb2xlYW4gfHwgdmFsdWUgPT09IE9iamVjdCB8fCB2YWx1ZSA9PT0gQXJyYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnRpZXNba2V5XSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgJ3ZhbHVlJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDlpITnkIblgLxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhW2tleV0gPSB2YWx1ZS52YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgJ29ic2VydmVyJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlLm9ic2VydmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9sZE9ic2VydmVyID0gdmFsdWUub2JzZXJ2ZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZS5vYnNlcnZlciA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2xkT2JzZXJ2ZXIgPSBkZWZGaWVsZHMubWV0aG9kc1t2YWx1ZS5vYnNlcnZlcl1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyDov73liqAgb2JzZXJ2ZXLvvIznlKjkuo7nm5HlkKzlj5jliqhcbiAgICAgICAgICAgICAgICAgICAgcHJvcGVydGllc1trZXldLm9ic2VydmVyID0gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsU2V0RGF0YSA9IHRoaXMuX29yaWdpbmFsU2V0RGF0YVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fZG9pbmdTZXREYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ2NhblxcJ3QgY2FsbCBzZXREYXRhIGluIGNvbXB1dGVkIGdldHRlciBmdW5jdGlvbiEnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb2luZ1NldERhdGEgPSB0cnVlXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIOiuoeeulyBjb21wdXRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmVlZFVwZGF0ZSA9IGNhbGNDb21wdXRlZCh0aGlzKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyDlgZogY29tcHV0ZWQg5bGe5oCn55qEIHNldERhdGFcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNFbXB0eShuZWVkVXBkYXRlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yaWdpbmFsU2V0RGF0YS5jYWxsKHRoaXMsIG5lZWRVcGRhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvaW5nU2V0RGF0YSA9IGZhbHNlXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvbGRPYnNlcnZlcikgb2xkT2JzZXJ2ZXIuYXBwbHkodGhpcywgYXJncylcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOiuoeeulyBjb21wdXRlZFxuICAgICAgICAgICAgY2FsY0NvbXB1dGVkKGRlZkZpZWxkcywgdHJ1ZSlcbiAgICAgICAgfVxuXG4gICAgICAgIGluaXRDb21wdXRlZCgpXG5cbiAgICAgICAgZGVmRmllbGRzLm1ldGhvZHMgPSBkZWZGaWVsZHMubWV0aG9kcyB8fCB7fVxuICAgICAgICBkZWZGaWVsZHMubWV0aG9kcy5fc2V0RGF0YSA9IGZ1bmN0aW9uIChkYXRhLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgY29uc3Qgb3JpZ2luYWxTZXREYXRhID0gdGhpcy5fb3JpZ2luYWxTZXREYXRhXG5cbiAgICAgICAgICAgIGlmICh0aGlzLl9kb2luZ1NldERhdGEpIHtcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZVxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignY2FuXFwndCBjYWxsIHNldERhdGEgaW4gY29tcHV0ZWQgZ2V0dGVyIGZ1bmN0aW9uIScpXG4gICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuX2RvaW5nU2V0RGF0YSA9IHRydWVcblxuICAgICAgICAgICAgLy8gVE9ETyDov4fmu6TmjokgZGF0YSDkuK3nmoQgY29tcHV0ZWQg5a2X5q61XG4gICAgICAgICAgICBjb25zdCBkYXRhS2V5cyA9IE9iamVjdC5rZXlzKGRhdGEpXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gZGF0YUtleXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXkgPSBkYXRhS2V5c1tpXVxuXG4gICAgICAgICAgICAgICAgaWYgKGNvbXB1dGVkW2tleV0pIGRlbGV0ZSBkYXRhW2tleV1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8g5YGaIGRhdGEg5bGe5oCn55qEIHNldERhdGFcbiAgICAgICAgICAgIG9yaWdpbmFsU2V0RGF0YS5jYWxsKHRoaXMsIGRhdGEsIGNhbGxiYWNrKVxuXG4gICAgICAgICAgICAvLyDorqHnrpcgY29tcHV0ZWRcbiAgICAgICAgICAgIGNvbnN0IG5lZWRVcGRhdGUgPSBjYWxjQ29tcHV0ZWQodGhpcylcblxuICAgICAgICAgICAgLy8g5YGaIGNvbXB1dGVkIOWxnuaAp+eahCBzZXREYXRhXG4gICAgICAgICAgICBpZiAoIWlzRW1wdHkobmVlZFVwZGF0ZSkpIHtcbiAgICAgICAgICAgICAgICBvcmlnaW5hbFNldERhdGEuY2FsbCh0aGlzLCBuZWVkVXBkYXRlKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLl9kb2luZ1NldERhdGEgPSBmYWxzZVxuICAgICAgICB9XG4gICAgfSxcbn0pXG4iXX0=