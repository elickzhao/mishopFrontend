'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames2 = require('./../helpers/classNames.js');

var _classNames3 = _interopRequireDefault(_classNames2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _baseComponent2.default)({
    relations: {
        '../sticky/index': {
            type: 'parent'
        }
    },
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-sticky-item'
        },
        title: {
            type: String,
            value: ''
        },
        content: {
            type: String,
            value: ''
        }
    },
    data: {
        isFixed: false,
        index: 0,
        top: 0,
        height: 0
    },
    computed: {
        classes: function classes() {
            var _data = this.data,
                prefixCls = _data.prefixCls,
                isFixed = _data.isFixed;

            var wrap = (0, _classNames3.default)(prefixCls, _defineProperty({}, prefixCls + '--fixed', isFixed));
            var hd = prefixCls + '__hd';
            var title = prefixCls + '__title';
            var bd = prefixCls + '__bd';
            var content = prefixCls + '__content';

            return {
                wrap: wrap,
                hd: hd,
                title: title,
                bd: bd,
                content: content
            };
        }
    },
    methods: {
        onScroll: function onScroll(scrollTop) {
            var _data2 = this.data,
                top = _data2.top,
                height = _data2.height;

            var isFixed = scrollTop >= top && scrollTop < top + height;

            if (isFixed !== this.data.isFixed) {
                this.setData({
                    isFixed: isFixed
                });
            }
        },
        updated: function updated(index) {
            var _this = this;

            var className = '.' + this.data.prefixCls;
            wx.createSelectorQuery().in(this).select(className).boundingClientRect(function (rect) {
                if (!rect) return;

                _this.setData({
                    top: rect.top,
                    height: rect.height,
                    index: index
                });
            }).exec();
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInJlbGF0aW9ucyIsInR5cGUiLCJwcm9wZXJ0aWVzIiwicHJlZml4Q2xzIiwiU3RyaW5nIiwidmFsdWUiLCJ0aXRsZSIsImNvbnRlbnQiLCJkYXRhIiwiaXNGaXhlZCIsImluZGV4IiwidG9wIiwiaGVpZ2h0IiwiY29tcHV0ZWQiLCJjbGFzc2VzIiwid3JhcCIsImhkIiwiYmQiLCJtZXRob2RzIiwib25TY3JvbGwiLCJzY3JvbGxUb3AiLCJzZXREYXRhIiwidXBkYXRlZCIsImNsYXNzTmFtZSIsInd4IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsImluIiwic2VsZWN0IiwiYm91bmRpbmdDbGllbnRSZWN0IiwicmVjdCIsImV4ZWMiXSwibWFwcGluZ3MiOiI7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7QUFFQSw2QkFBYztBQUNWQSxlQUFXO0FBQ1AsMkJBQW1CO0FBQ2ZDLGtCQUFNO0FBRFM7QUFEWixLQUREO0FBTVZDLGdCQUFZO0FBQ1JDLG1CQUFXO0FBQ1BGLGtCQUFNRyxNQURDO0FBRVBDLG1CQUFPO0FBRkEsU0FESDtBQUtSQyxlQUFPO0FBQ0hMLGtCQUFNRyxNQURIO0FBRUhDLG1CQUFPO0FBRkosU0FMQztBQVNSRSxpQkFBUztBQUNMTixrQkFBTUcsTUFERDtBQUVMQyxtQkFBTztBQUZGO0FBVEQsS0FORjtBQW9CVkcsVUFBTTtBQUNGQyxpQkFBUyxLQURQO0FBRUZDLGVBQU8sQ0FGTDtBQUdGQyxhQUFLLENBSEg7QUFJRkMsZ0JBQVE7QUFKTixLQXBCSTtBQTBCVkMsY0FBVTtBQUNOQyxlQURNLHFCQUNJO0FBQUEsd0JBQ3lCLEtBQUtOLElBRDlCO0FBQUEsZ0JBQ0VMLFNBREYsU0FDRUEsU0FERjtBQUFBLGdCQUNhTSxPQURiLFNBQ2FBLE9BRGI7O0FBRU4sZ0JBQU1NLE9BQU8sMEJBQVdaLFNBQVgsc0JBQ0xBLFNBREssY0FDZ0JNLE9BRGhCLEVBQWI7QUFHQSxnQkFBTU8sS0FBUWIsU0FBUixTQUFOO0FBQ0EsZ0JBQU1HLFFBQVdILFNBQVgsWUFBTjtBQUNBLGdCQUFNYyxLQUFRZCxTQUFSLFNBQU47QUFDQSxnQkFBTUksVUFBYUosU0FBYixjQUFOOztBQUVBLG1CQUFPO0FBQ0hZLDBCQURHO0FBRUhDLHNCQUZHO0FBR0hWLDRCQUhHO0FBSUhXLHNCQUpHO0FBS0hWO0FBTEcsYUFBUDtBQU9IO0FBbEJLLEtBMUJBO0FBOENWVyxhQUFTO0FBQ0xDLGdCQURLLG9CQUNJQyxTQURKLEVBQ2U7QUFBQSx5QkFDUSxLQUFLWixJQURiO0FBQUEsZ0JBQ1JHLEdBRFEsVUFDUkEsR0FEUTtBQUFBLGdCQUNIQyxNQURHLFVBQ0hBLE1BREc7O0FBRWhCLGdCQUFNSCxVQUFVVyxhQUFhVCxHQUFiLElBQW9CUyxZQUFZVCxNQUFNQyxNQUF0RDs7QUFFQSxnQkFBSUgsWUFBWSxLQUFLRCxJQUFMLENBQVVDLE9BQTFCLEVBQW1DO0FBQy9CLHFCQUFLWSxPQUFMLENBQWE7QUFDVFo7QUFEUyxpQkFBYjtBQUdIO0FBQ0osU0FWSTtBQVdSYSxlQVhRLG1CQVdBWixLQVhBLEVBV087QUFBQTs7QUFDUixnQkFBTWEsa0JBQWdCLEtBQUtmLElBQUwsQ0FBVUwsU0FBaEM7QUFDTnFCLGVBQ1dDLG1CQURYLEdBRVdDLEVBRlgsQ0FFYyxJQUZkLEVBR1dDLE1BSFgsQ0FHa0JKLFNBSGxCLEVBSVdLLGtCQUpYLENBSThCLFVBQUNDLElBQUQsRUFBVTtBQUMxQixvQkFBSSxDQUFDQSxJQUFMLEVBQVc7O0FBRVgsc0JBQUtSLE9BQUwsQ0FBYTtBQUNUVix5QkFBS2tCLEtBQUtsQixHQUREO0FBRVRDLDRCQUFRaUIsS0FBS2pCLE1BRko7QUFHVEY7QUFIUyxpQkFBYjtBQUtILGFBWlgsRUFhV29CLElBYlg7QUFjQTtBQTNCTztBQTlDQyxDQUFkIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGJhc2VDb21wb25lbnQgZnJvbSAnLi4vaGVscGVycy9iYXNlQ29tcG9uZW50J1xuaW1wb3J0IGNsYXNzTmFtZXMgZnJvbSAnLi4vaGVscGVycy9jbGFzc05hbWVzJ1xuXG5iYXNlQ29tcG9uZW50KHtcbiAgICByZWxhdGlvbnM6IHtcbiAgICAgICAgJy4uL3N0aWNreS9pbmRleCc6IHtcbiAgICAgICAgICAgIHR5cGU6ICdwYXJlbnQnLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBwcmVmaXhDbHM6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnd3V4LXN0aWNreS1pdGVtJyxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgY29udGVudDoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgZGF0YToge1xuICAgICAgICBpc0ZpeGVkOiBmYWxzZSxcbiAgICAgICAgaW5kZXg6IDAsXG4gICAgICAgIHRvcDogMCxcbiAgICAgICAgaGVpZ2h0OiAwLFxuICAgIH0sXG4gICAgY29tcHV0ZWQ6IHtcbiAgICAgICAgY2xhc3NlcygpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcHJlZml4Q2xzLCBpc0ZpeGVkIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IHdyYXAgPSBjbGFzc05hbWVzKHByZWZpeENscywge1xuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1maXhlZGBdOiBpc0ZpeGVkLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIGNvbnN0IGhkID0gYCR7cHJlZml4Q2xzfV9faGRgXG4gICAgICAgICAgICBjb25zdCB0aXRsZSA9IGAke3ByZWZpeENsc31fX3RpdGxlYFxuICAgICAgICAgICAgY29uc3QgYmQgPSBgJHtwcmVmaXhDbHN9X19iZGBcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBgJHtwcmVmaXhDbHN9X19jb250ZW50YFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdyYXAsXG4gICAgICAgICAgICAgICAgaGQsXG4gICAgICAgICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgICAgICAgYmQsXG4gICAgICAgICAgICAgICAgY29udGVudCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICB9LFxuICAgIG1ldGhvZHM6IHtcbiAgICAgICAgb25TY3JvbGwoc2Nyb2xsVG9wKSB7XG4gICAgICAgICAgICBjb25zdCB7IHRvcCwgaGVpZ2h0IH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IGlzRml4ZWQgPSBzY3JvbGxUb3AgPj0gdG9wICYmIHNjcm9sbFRvcCA8IHRvcCArIGhlaWdodFxuXG4gICAgICAgICAgICBpZiAoaXNGaXhlZCAhPT0gdGhpcy5kYXRhLmlzRml4ZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgICAgICAgICBpc0ZpeGVkLFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgXHR1cGRhdGVkKGluZGV4KSB7XG4gICAgICAgICAgICBjb25zdCBjbGFzc05hbWUgPSBgLiR7dGhpcy5kYXRhLnByZWZpeENsc31gXG4gICAgXHRcdHd4XG4gICAgICAgICAgICAgICAgLmNyZWF0ZVNlbGVjdG9yUXVlcnkoKVxuICAgICAgICAgICAgICAgIC5pbih0aGlzKVxuICAgICAgICAgICAgICAgIC5zZWxlY3QoY2xhc3NOYW1lKVxuICAgICAgICAgICAgICAgIC5ib3VuZGluZ0NsaWVudFJlY3QoKHJlY3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZWN0KSByZXR1cm5cblxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldERhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiByZWN0LnRvcCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogcmVjdC5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5leGVjKClcbiAgICBcdH0sXG4gICAgfSxcbn0pXG4iXX0=