'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.$wuxCountUp = exports.$wuxCountDown = exports.$stopWuxLoader = exports.$stopWuxRefresher = exports.$wuxCalendar = exports.$wuxSelect = exports.$wuxKeyBoard = exports.$wuxNotification = exports.$wuxGallery = exports.$wuxToptips = exports.$wuxDialog = exports.$wuxLoading = exports.$wuxToast = exports.$wuxBackdrop = exports.$wuxActionSheet = undefined;

var _index = require('./countdown/index.js');

var _index2 = _interopRequireDefault(_index);

var _index3 = require('./countup/index.js');

var _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * 使用选择器选择组件实例节点，返回匹配到的第一个组件实例对象
 * @param {String} selector 节点选择器
 * @param {Object} ctx 页面栈或组件的实例，默认为当前页面栈实例
 */
var getCtx = function getCtx(selector) {
    var ctx = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : getCurrentPages()[getCurrentPages().length - 1];

    var componentCtx = ctx.selectComponent(selector);

    if (!componentCtx) {
        throw new Error('无法找到对应的组件，请按文档说明使用组件');
    }

    return componentCtx;
};

var $wuxActionSheet = function $wuxActionSheet() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-actionsheet';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxBackdrop = function $wuxBackdrop() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-backdrop';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxToast = function $wuxToast() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-toast';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxLoading = function $wuxLoading() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-loading';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxDialog = function $wuxDialog() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-dialog';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxToptips = function $wuxToptips() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-toptips';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxGallery = function $wuxGallery() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-gallery';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxNotification = function $wuxNotification() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-notification';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxKeyBoard = function $wuxKeyBoard() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-keyboard';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxSelect = function $wuxSelect() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-select';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $wuxCalendar = function $wuxCalendar() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-calendar';
    var ctx = arguments[1];
    return getCtx(selector, ctx);
};
var $stopWuxRefresher = function $stopWuxRefresher() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-refresher';
    var ctx = arguments[1];
    return getCtx(selector, ctx).finishPullToRefresh();
};
var $stopWuxLoader = function $stopWuxLoader() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#wux-refresher';
    var ctx = arguments[1];
    var isEnd = arguments[2];
    return getCtx(selector, ctx).finishLoadmore(isEnd);
};

exports.$wuxActionSheet = $wuxActionSheet;
exports.$wuxBackdrop = $wuxBackdrop;
exports.$wuxToast = $wuxToast;
exports.$wuxLoading = $wuxLoading;
exports.$wuxDialog = $wuxDialog;
exports.$wuxToptips = $wuxToptips;
exports.$wuxGallery = $wuxGallery;
exports.$wuxNotification = $wuxNotification;
exports.$wuxKeyBoard = $wuxKeyBoard;
exports.$wuxSelect = $wuxSelect;
exports.$wuxCalendar = $wuxCalendar;
exports.$stopWuxRefresher = $stopWuxRefresher;
exports.$stopWuxLoader = $stopWuxLoader;
exports.$wuxCountDown = _index2.default;
exports.$wuxCountUp = _index4.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbImdldEN0eCIsInNlbGVjdG9yIiwiY3R4IiwiZ2V0Q3VycmVudFBhZ2VzIiwibGVuZ3RoIiwiY29tcG9uZW50Q3R4Iiwic2VsZWN0Q29tcG9uZW50IiwiRXJyb3IiLCIkd3V4QWN0aW9uU2hlZXQiLCIkd3V4QmFja2Ryb3AiLCIkd3V4VG9hc3QiLCIkd3V4TG9hZGluZyIsIiR3dXhEaWFsb2ciLCIkd3V4VG9wdGlwcyIsIiR3dXhHYWxsZXJ5IiwiJHd1eE5vdGlmaWNhdGlvbiIsIiR3dXhLZXlCb2FyZCIsIiR3dXhTZWxlY3QiLCIkd3V4Q2FsZW5kYXIiLCIkc3RvcFd1eFJlZnJlc2hlciIsImZpbmlzaFB1bGxUb1JlZnJlc2giLCIkc3RvcFd1eExvYWRlciIsImlzRW5kIiwiZmluaXNoTG9hZG1vcmUiLCIkd3V4Q291bnREb3duIiwiJHd1eENvdW50VXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7QUFFQTs7Ozs7QUFLQSxJQUFNQSxTQUFTLFNBQVRBLE1BQVMsQ0FBQ0MsUUFBRCxFQUFxRTtBQUFBLFFBQTFEQyxHQUEwRCx1RUFBcERDLGtCQUFrQkEsa0JBQWtCQyxNQUFsQixHQUEyQixDQUE3QyxDQUFvRDs7QUFDaEYsUUFBTUMsZUFBZUgsSUFBSUksZUFBSixDQUFvQkwsUUFBcEIsQ0FBckI7O0FBRUEsUUFBSSxDQUFDSSxZQUFMLEVBQW1CO0FBQ2YsY0FBTSxJQUFJRSxLQUFKLENBQVUsc0JBQVYsQ0FBTjtBQUNIOztBQUVELFdBQU9GLFlBQVA7QUFDSCxDQVJEOztBQVVBLElBQU1HLGtCQUFrQixTQUFsQkEsZUFBa0I7QUFBQSxRQUFDUCxRQUFELHVFQUFZLGtCQUFaO0FBQUEsUUFBZ0NDLEdBQWhDO0FBQUEsV0FBd0NGLE9BQU9DLFFBQVAsRUFBaUJDLEdBQWpCLENBQXhDO0FBQUEsQ0FBeEI7QUFDQSxJQUFNTyxlQUFlLFNBQWZBLFlBQWU7QUFBQSxRQUFDUixRQUFELHVFQUFZLGVBQVo7QUFBQSxRQUE2QkMsR0FBN0I7QUFBQSxXQUFxQ0YsT0FBT0MsUUFBUCxFQUFpQkMsR0FBakIsQ0FBckM7QUFBQSxDQUFyQjtBQUNBLElBQU1RLFlBQVksU0FBWkEsU0FBWTtBQUFBLFFBQUNULFFBQUQsdUVBQVksWUFBWjtBQUFBLFFBQTBCQyxHQUExQjtBQUFBLFdBQWtDRixPQUFPQyxRQUFQLEVBQWlCQyxHQUFqQixDQUFsQztBQUFBLENBQWxCO0FBQ0EsSUFBTVMsY0FBYyxTQUFkQSxXQUFjO0FBQUEsUUFBQ1YsUUFBRCx1RUFBWSxjQUFaO0FBQUEsUUFBNEJDLEdBQTVCO0FBQUEsV0FBb0NGLE9BQU9DLFFBQVAsRUFBaUJDLEdBQWpCLENBQXBDO0FBQUEsQ0FBcEI7QUFDQSxJQUFNVSxhQUFhLFNBQWJBLFVBQWE7QUFBQSxRQUFDWCxRQUFELHVFQUFZLGFBQVo7QUFBQSxRQUEyQkMsR0FBM0I7QUFBQSxXQUFtQ0YsT0FBT0MsUUFBUCxFQUFpQkMsR0FBakIsQ0FBbkM7QUFBQSxDQUFuQjtBQUNBLElBQU1XLGNBQWMsU0FBZEEsV0FBYztBQUFBLFFBQUNaLFFBQUQsdUVBQVksY0FBWjtBQUFBLFFBQTRCQyxHQUE1QjtBQUFBLFdBQW9DRixPQUFPQyxRQUFQLEVBQWlCQyxHQUFqQixDQUFwQztBQUFBLENBQXBCO0FBQ0EsSUFBTVksY0FBYyxTQUFkQSxXQUFjO0FBQUEsUUFBQ2IsUUFBRCx1RUFBWSxjQUFaO0FBQUEsUUFBNEJDLEdBQTVCO0FBQUEsV0FBb0NGLE9BQU9DLFFBQVAsRUFBaUJDLEdBQWpCLENBQXBDO0FBQUEsQ0FBcEI7QUFDQSxJQUFNYSxtQkFBbUIsU0FBbkJBLGdCQUFtQjtBQUFBLFFBQUNkLFFBQUQsdUVBQVksbUJBQVo7QUFBQSxRQUFpQ0MsR0FBakM7QUFBQSxXQUF5Q0YsT0FBT0MsUUFBUCxFQUFpQkMsR0FBakIsQ0FBekM7QUFBQSxDQUF6QjtBQUNBLElBQU1jLGVBQWUsU0FBZkEsWUFBZTtBQUFBLFFBQUNmLFFBQUQsdUVBQVksZUFBWjtBQUFBLFFBQTZCQyxHQUE3QjtBQUFBLFdBQXFDRixPQUFPQyxRQUFQLEVBQWlCQyxHQUFqQixDQUFyQztBQUFBLENBQXJCO0FBQ0EsSUFBTWUsYUFBYSxTQUFiQSxVQUFhO0FBQUEsUUFBQ2hCLFFBQUQsdUVBQVksYUFBWjtBQUFBLFFBQTJCQyxHQUEzQjtBQUFBLFdBQW1DRixPQUFPQyxRQUFQLEVBQWlCQyxHQUFqQixDQUFuQztBQUFBLENBQW5CO0FBQ0EsSUFBTWdCLGVBQWUsU0FBZkEsWUFBZTtBQUFBLFFBQUNqQixRQUFELHVFQUFZLGVBQVo7QUFBQSxRQUE2QkMsR0FBN0I7QUFBQSxXQUFxQ0YsT0FBT0MsUUFBUCxFQUFpQkMsR0FBakIsQ0FBckM7QUFBQSxDQUFyQjtBQUNBLElBQU1pQixvQkFBb0IsU0FBcEJBLGlCQUFvQjtBQUFBLFFBQUNsQixRQUFELHVFQUFZLGdCQUFaO0FBQUEsUUFBOEJDLEdBQTlCO0FBQUEsV0FBc0NGLE9BQU9DLFFBQVAsRUFBaUJDLEdBQWpCLEVBQXNCa0IsbUJBQXRCLEVBQXRDO0FBQUEsQ0FBMUI7QUFDQSxJQUFNQyxpQkFBaUIsU0FBakJBLGNBQWlCO0FBQUEsUUFBQ3BCLFFBQUQsdUVBQVksZ0JBQVo7QUFBQSxRQUE4QkMsR0FBOUI7QUFBQSxRQUFtQ29CLEtBQW5DO0FBQUEsV0FBNkN0QixPQUFPQyxRQUFQLEVBQWlCQyxHQUFqQixFQUFzQnFCLGNBQXRCLENBQXFDRCxLQUFyQyxDQUE3QztBQUFBLENBQXZCOztRQUdJZCxlLEdBQUFBLGU7UUFDQUMsWSxHQUFBQSxZO1FBQ0FDLFMsR0FBQUEsUztRQUNBQyxXLEdBQUFBLFc7UUFDQUMsVSxHQUFBQSxVO1FBQ0FDLFcsR0FBQUEsVztRQUNBQyxXLEdBQUFBLFc7UUFDQUMsZ0IsR0FBQUEsZ0I7UUFDQUMsWSxHQUFBQSxZO1FBQ0FDLFUsR0FBQUEsVTtRQUNBQyxZLEdBQUFBLFk7UUFDQUMsaUIsR0FBQUEsaUI7UUFDQUUsYyxHQUFBQSxjO1FBQ0FHLGEsR0FBQUEsZTtRQUNBQyxXLEdBQUFBLGUiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJHd1eENvdW50RG93biBmcm9tICcuL2NvdW50ZG93bi9pbmRleCdcbmltcG9ydCAkd3V4Q291bnRVcCBmcm9tICcuL2NvdW50dXAvaW5kZXgnXG5cbi8qKlxuICog5L2/55So6YCJ5oup5Zmo6YCJ5oup57uE5Lu25a6e5L6L6IqC54K577yM6L+U5Zue5Yy56YWN5Yiw55qE56ys5LiA5Liq57uE5Lu25a6e5L6L5a+56LGhXG4gKiBAcGFyYW0ge1N0cmluZ30gc2VsZWN0b3Ig6IqC54K56YCJ5oup5ZmoXG4gKiBAcGFyYW0ge09iamVjdH0gY3R4IOmhtemdouagiOaIlue7hOS7tueahOWunuS+i++8jOm7mOiupOS4uuW9k+WJjemhtemdouagiOWunuS+i1xuICovXG5jb25zdCBnZXRDdHggPSAoc2VsZWN0b3IsIGN0eCA9IGdldEN1cnJlbnRQYWdlcygpW2dldEN1cnJlbnRQYWdlcygpLmxlbmd0aCAtIDFdKSA9PiB7XG4gICAgY29uc3QgY29tcG9uZW50Q3R4ID0gY3R4LnNlbGVjdENvbXBvbmVudChzZWxlY3RvcilcblxuICAgIGlmICghY29tcG9uZW50Q3R4KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcign5peg5rOV5om+5Yiw5a+55bqU55qE57uE5Lu277yM6K+35oyJ5paH5qGj6K+05piO5L2/55So57uE5Lu2JylcbiAgICB9XG5cbiAgICByZXR1cm4gY29tcG9uZW50Q3R4XG59XG5cbmNvbnN0ICR3dXhBY3Rpb25TaGVldCA9IChzZWxlY3RvciA9ICcjd3V4LWFjdGlvbnNoZWV0JywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICR3dXhCYWNrZHJvcCA9IChzZWxlY3RvciA9ICcjd3V4LWJhY2tkcm9wJywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICR3dXhUb2FzdCA9IChzZWxlY3RvciA9ICcjd3V4LXRvYXN0JywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICR3dXhMb2FkaW5nID0gKHNlbGVjdG9yID0gJyN3dXgtbG9hZGluZycsIGN0eCkgPT4gZ2V0Q3R4KHNlbGVjdG9yLCBjdHgpXG5jb25zdCAkd3V4RGlhbG9nID0gKHNlbGVjdG9yID0gJyN3dXgtZGlhbG9nJywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICR3dXhUb3B0aXBzID0gKHNlbGVjdG9yID0gJyN3dXgtdG9wdGlwcycsIGN0eCkgPT4gZ2V0Q3R4KHNlbGVjdG9yLCBjdHgpXG5jb25zdCAkd3V4R2FsbGVyeSA9IChzZWxlY3RvciA9ICcjd3V4LWdhbGxlcnknLCBjdHgpID0+IGdldEN0eChzZWxlY3RvciwgY3R4KVxuY29uc3QgJHd1eE5vdGlmaWNhdGlvbiA9IChzZWxlY3RvciA9ICcjd3V4LW5vdGlmaWNhdGlvbicsIGN0eCkgPT4gZ2V0Q3R4KHNlbGVjdG9yLCBjdHgpXG5jb25zdCAkd3V4S2V5Qm9hcmQgPSAoc2VsZWN0b3IgPSAnI3d1eC1rZXlib2FyZCcsIGN0eCkgPT4gZ2V0Q3R4KHNlbGVjdG9yLCBjdHgpXG5jb25zdCAkd3V4U2VsZWN0ID0gKHNlbGVjdG9yID0gJyN3dXgtc2VsZWN0JywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICR3dXhDYWxlbmRhciA9IChzZWxlY3RvciA9ICcjd3V4LWNhbGVuZGFyJywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eClcbmNvbnN0ICRzdG9wV3V4UmVmcmVzaGVyID0gKHNlbGVjdG9yID0gJyN3dXgtcmVmcmVzaGVyJywgY3R4KSA9PiBnZXRDdHgoc2VsZWN0b3IsIGN0eCkuZmluaXNoUHVsbFRvUmVmcmVzaCgpXG5jb25zdCAkc3RvcFd1eExvYWRlciA9IChzZWxlY3RvciA9ICcjd3V4LXJlZnJlc2hlcicsIGN0eCwgaXNFbmQpID0+IGdldEN0eChzZWxlY3RvciwgY3R4KS5maW5pc2hMb2FkbW9yZShpc0VuZClcblxuZXhwb3J0IHtcbiAgICAkd3V4QWN0aW9uU2hlZXQsXG4gICAgJHd1eEJhY2tkcm9wLFxuICAgICR3dXhUb2FzdCxcbiAgICAkd3V4TG9hZGluZyxcbiAgICAkd3V4RGlhbG9nLFxuICAgICR3dXhUb3B0aXBzLFxuICAgICR3dXhHYWxsZXJ5LFxuICAgICR3dXhOb3RpZmljYXRpb24sXG4gICAgJHd1eEtleUJvYXJkLFxuICAgICR3dXhTZWxlY3QsXG4gICAgJHd1eENhbGVuZGFyLFxuICAgICRzdG9wV3V4UmVmcmVzaGVyLFxuICAgICRzdG9wV3V4TG9hZGVyLFxuICAgICR3dXhDb3VudERvd24sXG4gICAgJHd1eENvdW50VXAsXG59Il19