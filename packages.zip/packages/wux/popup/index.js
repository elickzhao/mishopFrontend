'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames2 = require('./../helpers/classNames.js');

var _classNames3 = _interopRequireDefault(_classNames2);

var _styleToCssString = require('./../helpers/styleToCssString.js');

var _styleToCssString2 = _interopRequireDefault(_styleToCssString);

var _index = require('./../index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _baseComponent2.default)({
    externalClasses: ['wux-content-class', 'wux-header-class', 'wux-body-class', 'wux-footer-class', 'wux-close-class'],
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-popup'
        },
        animationPrefixCls: {
            type: String,
            value: 'wux-animate'
        },
        title: {
            type: String,
            value: ''
        },
        content: {
            type: String,
            value: ''
        },
        extra: {
            type: String,
            value: ''
        },
        position: {
            type: String,
            value: 'center',
            observer: 'getTransitionName'
        },
        wrapStyle: {
            type: [String, Object],
            value: '',
            observer: function observer(newVal) {
                this.setData({
                    extStyle: (0, _styleToCssString2.default)(newVal)
                });
            }
        },
        closable: {
            type: Boolean,
            value: false
        },
        mask: {
            type: Boolean,
            value: true
        },
        maskClosable: {
            type: Boolean,
            value: true
        },
        visible: {
            type: Boolean,
            value: false,
            observer: 'setPopupVisible'
        },
        zIndex: {
            type: Number,
            value: 1000
        }
    },
    data: {
        transitionName: '',
        popupVisible: false,
        extStyle: ''
    },
    computed: {
        classes: function classes() {
            var _data = this.data,
                prefixCls = _data.prefixCls,
                position = _data.position;

            var wrap = (0, _classNames3.default)(prefixCls + '-position', _defineProperty({}, prefixCls + '-position--' + position, position));
            var content = prefixCls + '__content';
            var hd = prefixCls + '__hd';
            var title = prefixCls + '__title';
            var bd = prefixCls + '__bd';
            var ft = prefixCls + '__ft';
            var extra = prefixCls + '__extra';
            var close = prefixCls + '__close';
            var x = prefixCls + '__close-x';

            return {
                wrap: wrap,
                content: content,
                hd: hd,
                title: title,
                bd: bd,
                ft: ft,
                extra: extra,
                close: close,
                x: x
            };
        }
    },
    methods: {
        /**
         * 点击关闭按钮事件
         */
        close: function close() {
            this.triggerEvent('close');
        },

        /**
         * 点击蒙层事件
         */
        onMaskClick: function onMaskClick() {
            if (this.data.maskClosable) {
                this.close();
            }
        },

        /**
         * 组件关闭后的回调函数
         */
        onExited: function onExited() {
            this.triggerEvent('closed');
        },

        /**
         * 获取过渡的类名
         */
        getTransitionName: function getTransitionName() {
            var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.position;
            var animationPrefixCls = this.data.animationPrefixCls;

            var transitionName = '';

            switch (value) {
                case 'top':
                    transitionName = animationPrefixCls + '--slideInDown';
                    break;
                case 'right':
                    transitionName = animationPrefixCls + '--slideInRight';
                    break;
                case 'bottom':
                    transitionName = animationPrefixCls + '--slideInUp';
                    break;
                case 'left':
                    transitionName = animationPrefixCls + '--slideInLeft';
                    break;
                default:
                    transitionName = animationPrefixCls + '--fadeIn';
                    break;
            }

            this.setData({ transitionName: transitionName });
        },

        /**
         * 设置 popup 组件的显示隐藏
         */
        setPopupVisible: function setPopupVisible(popupVisible) {
            if (this.data.popupVisible !== popupVisible) {
                this.setData({ popupVisible: popupVisible });
                this.setBackdropVisible(popupVisible);
            }
        },

        /**
         * 设置 backdrop 组件的显示隐藏
         */
        setBackdropVisible: function setBackdropVisible(visible) {
            if (this.data.mask && this.$wuxBackdrop) {
                this.$wuxBackdrop[visible ? 'retain' : 'release']();
            }
        }
    },
    created: function created() {
        if (this.data.mask) {
            this.$wuxBackdrop = (0, _index.$wuxBackdrop)('#wux-backdrop', this);
        }
    },
    attached: function attached() {
        this.setPopupVisible(this.data.visible);
        this.getTransitionName();
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbImV4dGVybmFsQ2xhc3NlcyIsInByb3BlcnRpZXMiLCJwcmVmaXhDbHMiLCJ0eXBlIiwiU3RyaW5nIiwidmFsdWUiLCJhbmltYXRpb25QcmVmaXhDbHMiLCJ0aXRsZSIsImNvbnRlbnQiLCJleHRyYSIsInBvc2l0aW9uIiwib2JzZXJ2ZXIiLCJ3cmFwU3R5bGUiLCJPYmplY3QiLCJuZXdWYWwiLCJzZXREYXRhIiwiZXh0U3R5bGUiLCJjbG9zYWJsZSIsIkJvb2xlYW4iLCJtYXNrIiwibWFza0Nsb3NhYmxlIiwidmlzaWJsZSIsInpJbmRleCIsIk51bWJlciIsImRhdGEiLCJ0cmFuc2l0aW9uTmFtZSIsInBvcHVwVmlzaWJsZSIsImNvbXB1dGVkIiwiY2xhc3NlcyIsIndyYXAiLCJoZCIsImJkIiwiZnQiLCJjbG9zZSIsIngiLCJtZXRob2RzIiwidHJpZ2dlckV2ZW50Iiwib25NYXNrQ2xpY2siLCJvbkV4aXRlZCIsImdldFRyYW5zaXRpb25OYW1lIiwic2V0UG9wdXBWaXNpYmxlIiwic2V0QmFja2Ryb3BWaXNpYmxlIiwiJHd1eEJhY2tkcm9wIiwiY3JlYXRlZCIsImF0dGFjaGVkIl0sIm1hcHBpbmdzIjoiOztBQUFBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7QUFFQSw2QkFBYztBQUNWQSxxQkFBaUIsQ0FBQyxtQkFBRCxFQUFzQixrQkFBdEIsRUFBMEMsZ0JBQTFDLEVBQTRELGtCQUE1RCxFQUFnRixpQkFBaEYsQ0FEUDtBQUVWQyxnQkFBWTtBQUNSQyxtQkFBVztBQUNQQyxrQkFBTUMsTUFEQztBQUVQQyxtQkFBTztBQUZBLFNBREg7QUFLUkMsNEJBQW9CO0FBQ2hCSCxrQkFBTUMsTUFEVTtBQUVoQkMsbUJBQU87QUFGUyxTQUxaO0FBU1JFLGVBQU87QUFDSEosa0JBQU1DLE1BREg7QUFFSEMsbUJBQU87QUFGSixTQVRDO0FBYVJHLGlCQUFTO0FBQ0xMLGtCQUFNQyxNQUREO0FBRUxDLG1CQUFPO0FBRkYsU0FiRDtBQWlCUkksZUFBTztBQUNITixrQkFBTUMsTUFESDtBQUVIQyxtQkFBTztBQUZKLFNBakJDO0FBcUJSSyxrQkFBVTtBQUNOUCxrQkFBTUMsTUFEQTtBQUVOQyxtQkFBTyxRQUZEO0FBR05NLHNCQUFVO0FBSEosU0FyQkY7QUEwQlJDLG1CQUFXO0FBQ1BULGtCQUFNLENBQUNDLE1BQUQsRUFBU1MsTUFBVCxDQURDO0FBRVBSLG1CQUFPLEVBRkE7QUFHUE0sb0JBSE8sb0JBR0VHLE1BSEYsRUFHVTtBQUNiLHFCQUFLQyxPQUFMLENBQWE7QUFDVEMsOEJBQVUsZ0NBQWlCRixNQUFqQjtBQURELGlCQUFiO0FBR0g7QUFQTSxTQTFCSDtBQW1DUkcsa0JBQVU7QUFDTmQsa0JBQU1lLE9BREE7QUFFTmIsbUJBQU87QUFGRCxTQW5DRjtBQXVDUmMsY0FBTTtBQUNGaEIsa0JBQU1lLE9BREo7QUFFRmIsbUJBQU87QUFGTCxTQXZDRTtBQTJDUmUsc0JBQWM7QUFDVmpCLGtCQUFNZSxPQURJO0FBRVZiLG1CQUFPO0FBRkcsU0EzQ047QUErQ1JnQixpQkFBUztBQUNMbEIsa0JBQU1lLE9BREQ7QUFFTGIsbUJBQU8sS0FGRjtBQUdMTSxzQkFBVTtBQUhMLFNBL0NEO0FBb0RSVyxnQkFBUTtBQUNKbkIsa0JBQU1vQixNQURGO0FBRUpsQixtQkFBTztBQUZIO0FBcERBLEtBRkY7QUEyRFZtQixVQUFNO0FBQ0ZDLHdCQUFnQixFQURkO0FBRUZDLHNCQUFjLEtBRlo7QUFHRlYsa0JBQVU7QUFIUixLQTNESTtBQWdFVlcsY0FBVTtBQUNOQyxlQURNLHFCQUNJO0FBQUEsd0JBQzBCLEtBQUtKLElBRC9CO0FBQUEsZ0JBQ0V0QixTQURGLFNBQ0VBLFNBREY7QUFBQSxnQkFDYVEsUUFEYixTQUNhQSxRQURiOztBQUVOLGdCQUFNbUIsT0FBTywwQkFBYzNCLFNBQWQsb0NBQ0xBLFNBREssbUJBQ2tCUSxRQURsQixFQUMrQkEsUUFEL0IsRUFBYjtBQUdBLGdCQUFNRixVQUFhTixTQUFiLGNBQU47QUFDQSxnQkFBTTRCLEtBQVE1QixTQUFSLFNBQU47QUFDQSxnQkFBTUssUUFBV0wsU0FBWCxZQUFOO0FBQ0EsZ0JBQU02QixLQUFRN0IsU0FBUixTQUFOO0FBQ0EsZ0JBQU04QixLQUFROUIsU0FBUixTQUFOO0FBQ0EsZ0JBQU1PLFFBQVdQLFNBQVgsWUFBTjtBQUNBLGdCQUFNK0IsUUFBVy9CLFNBQVgsWUFBTjtBQUNBLGdCQUFNZ0MsSUFBT2hDLFNBQVAsY0FBTjs7QUFFQSxtQkFBTztBQUNIMkIsMEJBREc7QUFFSHJCLGdDQUZHO0FBR0hzQixzQkFIRztBQUlIdkIsNEJBSkc7QUFLSHdCLHNCQUxHO0FBTUhDLHNCQU5HO0FBT0h2Qiw0QkFQRztBQVFId0IsNEJBUkc7QUFTSEM7QUFURyxhQUFQO0FBV0g7QUExQkssS0FoRUE7QUE0RlZDLGFBQVM7QUFDTDs7O0FBR0FGLGFBSkssbUJBSUc7QUFDSixpQkFBS0csWUFBTCxDQUFrQixPQUFsQjtBQUNILFNBTkk7O0FBT0w7OztBQUdBQyxtQkFWSyx5QkFVUztBQUNWLGdCQUFJLEtBQUtiLElBQUwsQ0FBVUosWUFBZCxFQUE0QjtBQUN4QixxQkFBS2EsS0FBTDtBQUNIO0FBQ0osU0FkSTs7QUFlTDs7O0FBR0FLLGdCQWxCSyxzQkFrQk07QUFDUCxpQkFBS0YsWUFBTCxDQUFrQixRQUFsQjtBQUNILFNBcEJJOztBQXFCTDs7O0FBR0FHLHlCQXhCSywrQkF3QnlDO0FBQUEsZ0JBQTVCbEMsS0FBNEIsdUVBQXBCLEtBQUttQixJQUFMLENBQVVkLFFBQVU7QUFBQSxnQkFDbENKLGtCQURrQyxHQUNYLEtBQUtrQixJQURNLENBQ2xDbEIsa0JBRGtDOztBQUUxQyxnQkFBSW1CLGlCQUFpQixFQUFyQjs7QUFFQSxvQkFBUXBCLEtBQVI7QUFDSSxxQkFBSyxLQUFMO0FBQ0lvQixxQ0FBb0JuQixrQkFBcEI7QUFDQTtBQUNKLHFCQUFLLE9BQUw7QUFDSW1CLHFDQUFvQm5CLGtCQUFwQjtBQUNBO0FBQ0oscUJBQUssUUFBTDtBQUNJbUIscUNBQW9CbkIsa0JBQXBCO0FBQ0E7QUFDSixxQkFBSyxNQUFMO0FBQ0ltQixxQ0FBb0JuQixrQkFBcEI7QUFDQTtBQUNKO0FBQ0ltQixxQ0FBb0JuQixrQkFBcEI7QUFDQTtBQWZSOztBQWtCQSxpQkFBS1MsT0FBTCxDQUFhLEVBQUVVLDhCQUFGLEVBQWI7QUFDSCxTQS9DSTs7QUFnREw7OztBQUdBZSx1QkFuREssMkJBbURXZCxZQW5EWCxFQW1EeUI7QUFDMUIsZ0JBQUksS0FBS0YsSUFBTCxDQUFVRSxZQUFWLEtBQTJCQSxZQUEvQixFQUE2QztBQUN6QyxxQkFBS1gsT0FBTCxDQUFhLEVBQUVXLDBCQUFGLEVBQWI7QUFDQSxxQkFBS2Usa0JBQUwsQ0FBd0JmLFlBQXhCO0FBQ0g7QUFDSixTQXhESTs7QUF5REw7OztBQUdBZSwwQkE1REssOEJBNERjcEIsT0E1RGQsRUE0RHVCO0FBQ3hCLGdCQUFJLEtBQUtHLElBQUwsQ0FBVUwsSUFBVixJQUFrQixLQUFLdUIsWUFBM0IsRUFBeUM7QUFDckMscUJBQUtBLFlBQUwsQ0FBa0JyQixVQUFVLFFBQVYsR0FBcUIsU0FBdkM7QUFDSDtBQUNKO0FBaEVJLEtBNUZDO0FBOEpWc0IsV0E5SlUscUJBOEpBO0FBQ04sWUFBSSxLQUFLbkIsSUFBTCxDQUFVTCxJQUFkLEVBQW9CO0FBQ2hCLGlCQUFLdUIsWUFBTCxHQUFvQix5QkFBYSxlQUFiLEVBQThCLElBQTlCLENBQXBCO0FBQ0g7QUFDSixLQWxLUztBQW1LVkUsWUFuS1Usc0JBbUtDO0FBQ1AsYUFBS0osZUFBTCxDQUFxQixLQUFLaEIsSUFBTCxDQUFVSCxPQUEvQjtBQUNBLGFBQUtrQixpQkFBTDtBQUNIO0FBdEtTLENBQWQiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmFzZUNvbXBvbmVudCBmcm9tICcuLi9oZWxwZXJzL2Jhc2VDb21wb25lbnQnXG5pbXBvcnQgY2xhc3NOYW1lcyBmcm9tICcuLi9oZWxwZXJzL2NsYXNzTmFtZXMnXG5pbXBvcnQgc3R5bGVUb0Nzc1N0cmluZyBmcm9tICcuLi9oZWxwZXJzL3N0eWxlVG9Dc3NTdHJpbmcnXG5pbXBvcnQgeyAkd3V4QmFja2Ryb3AgfSBmcm9tICcuLi9pbmRleCdcblxuYmFzZUNvbXBvbmVudCh7XG4gICAgZXh0ZXJuYWxDbGFzc2VzOiBbJ3d1eC1jb250ZW50LWNsYXNzJywgJ3d1eC1oZWFkZXItY2xhc3MnLCAnd3V4LWJvZHktY2xhc3MnLCAnd3V4LWZvb3Rlci1jbGFzcycsICd3dXgtY2xvc2UtY2xhc3MnXSxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHByZWZpeENsczoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICd3dXgtcG9wdXAnLFxuICAgICAgICB9LFxuICAgICAgICBhbmltYXRpb25QcmVmaXhDbHM6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnd3V4LWFuaW1hdGUnLFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBjb250ZW50OiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIGV4dHJhOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIHBvc2l0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ2NlbnRlcicsXG4gICAgICAgICAgICBvYnNlcnZlcjogJ2dldFRyYW5zaXRpb25OYW1lJyxcbiAgICAgICAgfSxcbiAgICAgICAgd3JhcFN0eWxlOiB7XG4gICAgICAgICAgICB0eXBlOiBbU3RyaW5nLCBPYmplY3RdLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICAgICAgb2JzZXJ2ZXIobmV3VmFsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgZXh0U3R5bGU6IHN0eWxlVG9Dc3NTdHJpbmcobmV3VmFsKSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgY2xvc2FibGU6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIG1hc2s6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgbWFza0Nsb3NhYmxlOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHZpc2libGU6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgICAgICBvYnNlcnZlcjogJ3NldFBvcHVwVmlzaWJsZScsXG4gICAgICAgIH0sXG4gICAgICAgIHpJbmRleDoge1xuICAgICAgICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgICAgICAgdmFsdWU6IDEwMDAsXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBkYXRhOiB7XG4gICAgICAgIHRyYW5zaXRpb25OYW1lOiAnJyxcbiAgICAgICAgcG9wdXBWaXNpYmxlOiBmYWxzZSxcbiAgICAgICAgZXh0U3R5bGU6ICcnLFxuICAgIH0sXG4gICAgY29tcHV0ZWQ6IHtcbiAgICAgICAgY2xhc3NlcygpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcHJlZml4Q2xzLCBwb3NpdGlvbiB9ID0gdGhpcy5kYXRhXG4gICAgICAgICAgICBjb25zdCB3cmFwID0gY2xhc3NOYW1lcyhgJHtwcmVmaXhDbHN9LXBvc2l0aW9uYCwge1xuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LXBvc2l0aW9uLS0ke3Bvc2l0aW9ufWBdOiBwb3NpdGlvbixcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID0gYCR7cHJlZml4Q2xzfV9fY29udGVudGBcbiAgICAgICAgICAgIGNvbnN0IGhkID0gYCR7cHJlZml4Q2xzfV9faGRgXG4gICAgICAgICAgICBjb25zdCB0aXRsZSA9IGAke3ByZWZpeENsc31fX3RpdGxlYFxuICAgICAgICAgICAgY29uc3QgYmQgPSBgJHtwcmVmaXhDbHN9X19iZGBcbiAgICAgICAgICAgIGNvbnN0IGZ0ID0gYCR7cHJlZml4Q2xzfV9fZnRgXG4gICAgICAgICAgICBjb25zdCBleHRyYSA9IGAke3ByZWZpeENsc31fX2V4dHJhYFxuICAgICAgICAgICAgY29uc3QgY2xvc2UgPSBgJHtwcmVmaXhDbHN9X19jbG9zZWBcbiAgICAgICAgICAgIGNvbnN0IHggPSBgJHtwcmVmaXhDbHN9X19jbG9zZS14YFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdyYXAsXG4gICAgICAgICAgICAgICAgY29udGVudCxcbiAgICAgICAgICAgICAgICBoZCxcbiAgICAgICAgICAgICAgICB0aXRsZSxcbiAgICAgICAgICAgICAgICBiZCxcbiAgICAgICAgICAgICAgICBmdCxcbiAgICAgICAgICAgICAgICBleHRyYSxcbiAgICAgICAgICAgICAgICBjbG9zZSxcbiAgICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICAvKipcbiAgICAgICAgICog54K55Ye75YWz6Zet5oyJ6ZKu5LqL5Lu2XG4gICAgICAgICAqL1xuICAgICAgICBjbG9zZSgpIHtcbiAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KCdjbG9zZScpXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDngrnlh7vokpnlsYLkuovku7ZcbiAgICAgICAgICovXG4gICAgICAgIG9uTWFza0NsaWNrKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YS5tYXNrQ2xvc2FibGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNsb3NlKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOe7hOS7tuWFs+mXreWQjueahOWbnuiwg+WHveaVsFxuICAgICAgICAgKi9cbiAgICAgICAgb25FeGl0ZWQoKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2xvc2VkJylcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOiOt+WPlui/h+a4oeeahOexu+WQjVxuICAgICAgICAgKi9cbiAgICAgICAgZ2V0VHJhbnNpdGlvbk5hbWUodmFsdWUgPSB0aGlzLmRhdGEucG9zaXRpb24pIHtcbiAgICAgICAgICAgIGNvbnN0IHsgYW5pbWF0aW9uUHJlZml4Q2xzIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGxldCB0cmFuc2l0aW9uTmFtZSA9ICcnXG5cbiAgICAgICAgICAgIHN3aXRjaCAodmFsdWUpIHtcbiAgICAgICAgICAgICAgICBjYXNlICd0b3AnOlxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uTmFtZSA9IGAke2FuaW1hdGlvblByZWZpeENsc30tLXNsaWRlSW5Eb3duYFxuICAgICAgICAgICAgICAgICAgICBicmVha1xuICAgICAgICAgICAgICAgIGNhc2UgJ3JpZ2h0JzpcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbk5hbWUgPSBgJHthbmltYXRpb25QcmVmaXhDbHN9LS1zbGlkZUluUmlnaHRgXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICAgICAgY2FzZSAnYm90dG9tJzpcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbk5hbWUgPSBgJHthbmltYXRpb25QcmVmaXhDbHN9LS1zbGlkZUluVXBgXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICAgICAgY2FzZSAnbGVmdCc6XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb25OYW1lID0gYCR7YW5pbWF0aW9uUHJlZml4Q2xzfS0tc2xpZGVJbkxlZnRgXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbk5hbWUgPSBgJHthbmltYXRpb25QcmVmaXhDbHN9LS1mYWRlSW5gXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IHRyYW5zaXRpb25OYW1lIH0pXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDorr7nva4gcG9wdXAg57uE5Lu255qE5pi+56S66ZqQ6JePXG4gICAgICAgICAqL1xuICAgICAgICBzZXRQb3B1cFZpc2libGUocG9wdXBWaXNpYmxlKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhLnBvcHVwVmlzaWJsZSAhPT0gcG9wdXBWaXNpYmxlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgcG9wdXBWaXNpYmxlIH0pXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRCYWNrZHJvcFZpc2libGUocG9wdXBWaXNpYmxlKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog6K6+572uIGJhY2tkcm9wIOe7hOS7tueahOaYvuekuumakOiXj1xuICAgICAgICAgKi9cbiAgICAgICAgc2V0QmFja2Ryb3BWaXNpYmxlKHZpc2libGUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmRhdGEubWFzayAmJiB0aGlzLiR3dXhCYWNrZHJvcCkge1xuICAgICAgICAgICAgICAgIHRoaXMuJHd1eEJhY2tkcm9wW3Zpc2libGUgPyAncmV0YWluJyA6ICdyZWxlYXNlJ10oKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgY3JlYXRlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuZGF0YS5tYXNrKSB7XG4gICAgICAgICAgICB0aGlzLiR3dXhCYWNrZHJvcCA9ICR3dXhCYWNrZHJvcCgnI3d1eC1iYWNrZHJvcCcsIHRoaXMpXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGF0dGFjaGVkKCkge1xuICAgICAgICB0aGlzLnNldFBvcHVwVmlzaWJsZSh0aGlzLmRhdGEudmlzaWJsZSlcbiAgICAgICAgdGhpcy5nZXRUcmFuc2l0aW9uTmFtZSgpXG4gICAgfSxcbn0pXG4iXX0=