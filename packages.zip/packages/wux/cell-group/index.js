'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames = require('./../helpers/classNames.js');

var _classNames2 = _interopRequireDefault(_classNames);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _baseComponent2.default)({
    relations: {
        '../cell/index': {
            type: 'child',
            observer: function observer() {
                this.debounce(this.updateIsLastElement);
            }
        }
    },
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-cell-group'
        },
        title: {
            type: String,
            value: ''
        },
        label: {
            type: String,
            value: ''
        }
    },
    computed: {
        classes: function classes() {
            var prefixCls = this.data.prefixCls;

            var wrap = (0, _classNames2.default)(prefixCls);
            var hd = prefixCls + '__hd';
            var bd = prefixCls + '__bd';
            var ft = prefixCls + '__ft';

            return {
                wrap: wrap,
                hd: hd,
                bd: bd,
                ft: ft
            };
        }
    },
    methods: {
        updateIsLastElement: function updateIsLastElement() {
            var elements = this.getRelationNodes('../cell/index');
            if (elements.length > 0) {
                var lastIndex = elements.length - 1;
                elements.forEach(function (element, index) {
                    element.updateIsLastElement(index === lastIndex);
                });
            }
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInJlbGF0aW9ucyIsInR5cGUiLCJvYnNlcnZlciIsImRlYm91bmNlIiwidXBkYXRlSXNMYXN0RWxlbWVudCIsInByb3BlcnRpZXMiLCJwcmVmaXhDbHMiLCJTdHJpbmciLCJ2YWx1ZSIsInRpdGxlIiwibGFiZWwiLCJjb21wdXRlZCIsImNsYXNzZXMiLCJkYXRhIiwid3JhcCIsImhkIiwiYmQiLCJmdCIsIm1ldGhvZHMiLCJlbGVtZW50cyIsImdldFJlbGF0aW9uTm9kZXMiLCJsZW5ndGgiLCJsYXN0SW5kZXgiLCJmb3JFYWNoIiwiZWxlbWVudCIsImluZGV4Il0sIm1hcHBpbmdzIjoiOztBQUFBOzs7O0FBQ0E7Ozs7OztBQUVBLDZCQUFjO0FBQ1ZBLGVBQVc7QUFDUCx5QkFBaUI7QUFDYkMsa0JBQU0sT0FETztBQUViQyxvQkFGYSxzQkFFRjtBQUNQLHFCQUFLQyxRQUFMLENBQWMsS0FBS0MsbUJBQW5CO0FBQ0g7QUFKWTtBQURWLEtBREQ7QUFTVkMsZ0JBQVk7QUFDUkMsbUJBQVc7QUFDUEwsa0JBQU1NLE1BREM7QUFFUEMsbUJBQU87QUFGQSxTQURIO0FBS1JDLGVBQU87QUFDSFIsa0JBQU1NLE1BREg7QUFFSEMsbUJBQU87QUFGSixTQUxDO0FBU1JFLGVBQU87QUFDSFQsa0JBQU1NLE1BREg7QUFFSEMsbUJBQU87QUFGSjtBQVRDLEtBVEY7QUF1QlZHLGNBQVU7QUFDTkMsZUFETSxxQkFDSTtBQUFBLGdCQUNFTixTQURGLEdBQ2dCLEtBQUtPLElBRHJCLENBQ0VQLFNBREY7O0FBRU4sZ0JBQU1RLE9BQU8sMEJBQVdSLFNBQVgsQ0FBYjtBQUNBLGdCQUFNUyxLQUFRVCxTQUFSLFNBQU47QUFDQSxnQkFBTVUsS0FBUVYsU0FBUixTQUFOO0FBQ0EsZ0JBQU1XLEtBQVFYLFNBQVIsU0FBTjs7QUFFQSxtQkFBTztBQUNIUSwwQkFERztBQUVIQyxzQkFGRztBQUdIQyxzQkFIRztBQUlIQztBQUpHLGFBQVA7QUFNSDtBQWRLLEtBdkJBO0FBdUNWQyxhQUFTO0FBQ0xkLDJCQURLLGlDQUNpQjtBQUNsQixnQkFBTWUsV0FBVyxLQUFLQyxnQkFBTCxDQUFzQixlQUF0QixDQUFqQjtBQUNBLGdCQUFJRCxTQUFTRSxNQUFULEdBQWtCLENBQXRCLEVBQXlCO0FBQ3JCLG9CQUFNQyxZQUFZSCxTQUFTRSxNQUFULEdBQWtCLENBQXBDO0FBQ0FGLHlCQUFTSSxPQUFULENBQWlCLFVBQUNDLE9BQUQsRUFBVUMsS0FBVixFQUFvQjtBQUNqQ0QsNEJBQVFwQixtQkFBUixDQUE0QnFCLFVBQVVILFNBQXRDO0FBQ0gsaUJBRkQ7QUFHSDtBQUNKO0FBVEk7QUF2Q0MsQ0FBZCIsImZpbGUiOiJpbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBiYXNlQ29tcG9uZW50IGZyb20gJy4uL2hlbHBlcnMvYmFzZUNvbXBvbmVudCdcbmltcG9ydCBjbGFzc05hbWVzIGZyb20gJy4uL2hlbHBlcnMvY2xhc3NOYW1lcydcblxuYmFzZUNvbXBvbmVudCh7XG4gICAgcmVsYXRpb25zOiB7XG4gICAgICAgICcuLi9jZWxsL2luZGV4Jzoge1xuICAgICAgICAgICAgdHlwZTogJ2NoaWxkJyxcbiAgICAgICAgICAgIG9ic2VydmVyKCkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGVib3VuY2UodGhpcy51cGRhdGVJc0xhc3RFbGVtZW50KVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcHJlZml4Q2xzOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ3d1eC1jZWxsLWdyb3VwJyxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgbGFiZWw6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIGNvbXB1dGVkOiB7XG4gICAgICAgIGNsYXNzZXMoKSB7XG4gICAgICAgICAgICBjb25zdCB7IHByZWZpeENscyB9ID0gdGhpcy5kYXRhXG4gICAgICAgICAgICBjb25zdCB3cmFwID0gY2xhc3NOYW1lcyhwcmVmaXhDbHMpXG4gICAgICAgICAgICBjb25zdCBoZCA9IGAke3ByZWZpeENsc31fX2hkYFxuICAgICAgICAgICAgY29uc3QgYmQgPSBgJHtwcmVmaXhDbHN9X19iZGBcbiAgICAgICAgICAgIGNvbnN0IGZ0ID0gYCR7cHJlZml4Q2xzfV9fZnRgXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgd3JhcCxcbiAgICAgICAgICAgICAgICBoZCxcbiAgICAgICAgICAgICAgICBiZCxcbiAgICAgICAgICAgICAgICBmdCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICB9LFxuICAgIG1ldGhvZHM6IHtcbiAgICAgICAgdXBkYXRlSXNMYXN0RWxlbWVudCgpIHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzID0gdGhpcy5nZXRSZWxhdGlvbk5vZGVzKCcuLi9jZWxsL2luZGV4JylcbiAgICAgICAgICAgIGlmIChlbGVtZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbGFzdEluZGV4ID0gZWxlbWVudHMubGVuZ3RoIC0gMVxuICAgICAgICAgICAgICAgIGVsZW1lbnRzLmZvckVhY2goKGVsZW1lbnQsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQudXBkYXRlSXNMYXN0RWxlbWVudChpbmRleCA9PT0gbGFzdEluZGV4KVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG4iXX0=