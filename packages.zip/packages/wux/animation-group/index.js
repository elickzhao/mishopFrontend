'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _styleToCssString = require('./../helpers/styleToCssString.js');

var _styleToCssString2 = _interopRequireDefault(_styleToCssString);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ENTER = 'enter';
var ENTERING = 'entering';
var ENTERED = 'entered';
var EXIT = 'exit';
var EXITING = 'exiting';
var EXITED = 'exited';
var UNMOUNTED = 'unmounted';

var TRANSITION = 'transition';
var ANIMATION = 'animation';

var TIMEOUT = 1000 / 60;

var defaultClassNames = {
    enter: '', // 进入过渡的开始状态，在过渡过程完成之后移除
    enterActive: '', // 进入过渡的结束状态，在过渡过程完成之后移除
    enterDone: '', // 进入过渡的完成状态
    exit: '', // 离开过渡的开始状态，在过渡过程完成之后移除
    exitActive: '', // 离开过渡的结束状态，在过渡过程完成之后移除
    exitDone: '' // 离开过渡的完成状态
};

(0, _baseComponent2.default)({
    properties: {
        // 触发组件进入或离开过渡的状态
        in: {
            type: Boolean,
            value: false,
            observer: function observer(newVal) {
                if (this.data.isMounting) {
                    this.updated(newVal);
                }
            }
        },
        // 过渡的类名
        classNames: {
            type: null,
            value: defaultClassNames
        },
        // 过渡持续时间
        duration: {
            type: null,
            value: null
        },
        // 过渡动效的类型
        type: {
            type: String,
            value: TRANSITION
        },
        // 首次挂载时是否触发进入过渡
        appear: {
            type: Boolean,
            value: false
        },
        // 是否启用进入过渡
        enter: {
            type: Boolean,
            value: true
        },
        // 是否启用离开过渡
        exit: {
            type: Boolean,
            value: true
        },
        // 首次进入过渡时是否懒挂载组件
        mountOnEnter: {
            type: Boolean,
            value: true
        },
        // 离开过渡完成时是否卸载组件
        unmountOnExit: {
            type: Boolean,
            value: true
        },
        // 自定义类名
        wrapCls: {
            type: String,
            value: ''
        },
        // 自定义样式
        wrapStyle: {
            type: [String, Object],
            value: '',
            observer: function observer(newVal) {
                this.setData({
                    extStyle: (0, _styleToCssString2.default)(newVal)
                });
            }
        }
    },
    data: {
        animateCss: '', // 动画样式
        animateStatus: EXITED, // 动画状态，可选值 entering、entered、exiting、exited
        isMounting: false, // 是否首次挂载
        extStyle: '' // 组件样式
    },
    methods: {
        /**
         * 监听过渡或动画的回调函数
         */
        addEventListener: function addEventListener() {
            var animateStatus = this.data.animateStatus;

            var _getTimeouts = this.getTimeouts(),
                enter = _getTimeouts.enter,
                exit = _getTimeouts.exit;

            if (animateStatus === ENTERING && !enter && this.data.enter) {
                this.performEntered();
            }

            if (animateStatus === EXITING && !exit && this.data.exit) {
                this.performExited();
            }
        },

        /**
         * 会在 WXSS transition 或 wx.createAnimation 动画结束后触发
         */
        onTransitionEnd: function onTransitionEnd() {
            if (this.data.type === TRANSITION) {
                this.addEventListener();
            }
        },

        /**
         * 会在一个 WXSS animation 动画完成时触发
         */
        onAnimationEnd: function onAnimationEnd() {
            if (this.data.type === ANIMATION) {
                this.addEventListener();
            }
        },

        /**
         * 更新组件状态
         * @param {String} nextStatus 下一状态，ENTERING 或 EXITING
         * @param {Boolean} mounting 是否首次挂载
         */
        updateStatus: function updateStatus(nextStatus) {
            var mounting = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

            if (nextStatus !== null) {
                this.cancelNextCallback();
                this.isAppearing = mounting;

                if (nextStatus === ENTERING) {
                    this.performEnter();
                } else {
                    this.performExit();
                }
            }
        },

        /**
         * 进入过渡
         */
        performEnter: function performEnter() {
            var _this = this;

            var _getClassNames = this.getClassNames(ENTER),
                className = _getClassNames.className,
                activeClassName = _getClassNames.activeClassName;

            var _getTimeouts2 = this.getTimeouts(),
                enter = _getTimeouts2.enter;

            var enterParams = {
                animateStatus: ENTER,
                animateCss: className
            };
            var enteringParams = {
                animateStatus: ENTERING,
                animateCss: className + ' ' + activeClassName

                // 若已禁用进入过渡，则更新状态至 ENTERED
            };if (!this.isAppearing && !this.data.enter) {
                return this.performEntered();
            }

            // 第一阶段：设置进入过渡的开始状态，并触发 ENTER 事件
            // 第二阶段：延迟一帧后，设置进入过渡的结束状态，并触发 ENTERING 事件
            // 第三阶段：若已设置过渡的持续时间，则延迟指定时间后触发进入过渡完成 performEntered，否则等待触发 onTransitionEnd 或 onAnimationEnd
            this.safeSetData(enterParams, function () {
                _this.triggerEvent('change', { animateStatus: ENTER });
                _this.triggerEvent(ENTER, { isAppearing: _this.isAppearing });

                // 由于有些时候不能正确的触发动画完成的回调，具体原因未知
                // 所以采用延迟一帧的方式来确保可以触发回调
                _this.delayHandler(TIMEOUT, function () {
                    _this.safeSetData(enteringParams, function () {
                        _this.triggerEvent('change', { animateStatus: ENTERING });
                        _this.triggerEvent(ENTERING, { isAppearing: _this.isAppearing });

                        if (enter) {
                            _this.delayHandler(enter, _this.performEntered);
                        }
                    });
                });
            });
        },

        /**
         * 进入过渡完成
         */
        performEntered: function performEntered() {
            var _this2 = this;

            var _getClassNames2 = this.getClassNames(ENTER),
                doneClassName = _getClassNames2.doneClassName;

            var enteredParams = {
                animateStatus: ENTERED,
                animateCss: doneClassName

                // 第三阶段：设置进入过渡的完成状态，并触发 ENTERED 事件
            };this.safeSetData(enteredParams, function () {
                _this2.triggerEvent('change', { animateStatus: ENTERED });
                _this2.triggerEvent(ENTERED, { isAppearing: _this2.isAppearing });
            });
        },

        /**
         * 离开过渡
         */
        performExit: function performExit() {
            var _this3 = this;

            var _getClassNames3 = this.getClassNames(EXIT),
                className = _getClassNames3.className,
                activeClassName = _getClassNames3.activeClassName;

            var _getTimeouts3 = this.getTimeouts(),
                exit = _getTimeouts3.exit;

            var exitParams = {
                animateStatus: EXIT,
                animateCss: className
            };
            var exitingParams = {
                animateStatus: EXITING,
                animateCss: className + ' ' + activeClassName

                // 若已禁用离开过渡，则更新状态至 EXITED
            };if (!this.data.exit) {
                return this.performExited();
            }

            // 第一阶段：设置离开过渡的开始状态，并触发 EXIT 事件
            // 第二阶段：延迟一帧后，设置离开过渡的结束状态，并触发 EXITING 事件
            // 第三阶段：若已设置过渡的持续时间，则延迟指定时间后触发离开过渡完成 performExited，否则等待触发 onTransitionEnd 或 onAnimationEnd
            this.safeSetData(exitParams, function () {
                _this3.triggerEvent('change', { animateStatus: EXIT });
                _this3.triggerEvent(EXIT);

                _this3.delayHandler(TIMEOUT, function () {
                    _this3.safeSetData(exitingParams, function () {
                        _this3.triggerEvent('change', { animateStatus: EXITING });
                        _this3.triggerEvent(EXITING);

                        if (exit) {
                            _this3.delayHandler(exit, _this3.performExited);
                        }
                    });
                });
            });
        },

        /**
         * 离开过渡完成
         */
        performExited: function performExited() {
            var _this4 = this;

            var _getClassNames4 = this.getClassNames(EXIT),
                doneClassName = _getClassNames4.doneClassName;

            var exitedParams = {
                animateStatus: EXITED,
                animateCss: doneClassName

                // 第三阶段：设置离开过渡的完成状态，并触发 EXITED 事件
            };this.safeSetData(exitedParams, function () {
                _this4.triggerEvent('change', { animateStatus: EXITED });
                _this4.triggerEvent(EXITED);

                // 判断离开过渡完成时是否卸载组件
                if (_this4.data.unmountOnExit) {
                    _this4.setData({ animateStatus: UNMOUNTED }, function () {
                        _this4.triggerEvent('change', { animateStatus: UNMOUNTED });
                    });
                }
            });
        },

        /**
         * 获取指定状态下的类名
         * @param {String} type 过渡类型，enter 或 exit
         */
        getClassNames: function getClassNames(type) {
            var classNames = this.data.classNames;

            var className = typeof classNames !== 'string' ? classNames[type] : classNames + '-' + type;
            var activeClassName = typeof classNames !== 'string' ? classNames[type + 'Active'] : classNames + '-' + type + '-active';
            var doneClassName = typeof classNames !== 'string' ? classNames[type + 'Done'] : classNames + '-' + type + '-done';

            return {
                className: className,
                activeClassName: activeClassName,
                doneClassName: doneClassName
            };
        },

        /**
         * 获取过渡持续时间
         */
        getTimeouts: function getTimeouts() {
            var duration = this.data.duration;


            if (duration !== null && (typeof duration === 'undefined' ? 'undefined' : _typeof(duration)) === 'object') {
                return {
                    enter: duration.enter,
                    exit: duration.exit
                };
            } else if (typeof duration === 'number') {
                return {
                    enter: duration,
                    exit: duration
                };
            }

            return {};
        },

        /**
         * 属性值 in 被更改时的响应函数
         * @param {Boolean} newVal 触发组件进入或离开过渡的状态
         */
        updated: function updated(newVal) {
            var _this5 = this;

            var _ref = this.pendingData || this.data,
                animateStatus = _ref.animateStatus;

            var nextStatus = null;

            if (newVal) {
                if (animateStatus === UNMOUNTED) {
                    animateStatus = EXITED;
                    this.setData({ animateStatus: EXITED }, function () {
                        _this5.triggerEvent('change', { animateStatus: EXITED });
                    });
                }
                if (animateStatus !== ENTER && animateStatus !== ENTERING && animateStatus !== ENTERED) {
                    nextStatus = ENTERING;
                }
            } else {
                if (animateStatus === ENTER || animateStatus === ENTERING || animateStatus === ENTERED) {
                    nextStatus = EXITING;
                }
            }

            this.updateStatus(nextStatus);
        },

        /**
         * 延迟一段时间触发回调
         * @param {Number} timeout 延迟时间
         * @param {Function} handler 回调函数
         */
        delayHandler: function delayHandler(timeout, handler) {
            if (timeout) {
                this.setNextCallback(handler);
                setTimeout(this.nextCallback, timeout);
            }
        },

        /**
         * 点击事件
         */
        onTap: function onTap() {
            this.triggerEvent('click');
        }
    },
    attached: function attached() {
        var _this6 = this;

        var animateStatus = null;
        var appearStatus = null;

        if (this.data.in) {
            if (this.data.appear) {
                animateStatus = EXITED;
                appearStatus = ENTERING;
            } else {
                animateStatus = ENTERED;
            }
        } else {
            if (this.data.unmountOnExit || this.data.mountOnEnter) {
                animateStatus = UNMOUNTED;
            } else {
                animateStatus = EXITED;
            }
        }

        // 由于小程序组件首次挂载时 observer 事件总是优先于 attached 事件
        // 所以使用 isMounting 来强制优先触发 attached 事件
        this.safeSetData({ animateStatus: animateStatus, isMounting: true }, function () {
            _this6.triggerEvent('change', { animateStatus: animateStatus });
            _this6.updateStatus(appearStatus, true);
        });
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkVOVEVSIiwiRU5URVJJTkciLCJFTlRFUkVEIiwiRVhJVCIsIkVYSVRJTkciLCJFWElURUQiLCJVTk1PVU5URUQiLCJUUkFOU0lUSU9OIiwiQU5JTUFUSU9OIiwiVElNRU9VVCIsImRlZmF1bHRDbGFzc05hbWVzIiwiZW50ZXIiLCJlbnRlckFjdGl2ZSIsImVudGVyRG9uZSIsImV4aXQiLCJleGl0QWN0aXZlIiwiZXhpdERvbmUiLCJwcm9wZXJ0aWVzIiwiaW4iLCJ0eXBlIiwiQm9vbGVhbiIsInZhbHVlIiwib2JzZXJ2ZXIiLCJuZXdWYWwiLCJkYXRhIiwiaXNNb3VudGluZyIsInVwZGF0ZWQiLCJjbGFzc05hbWVzIiwiZHVyYXRpb24iLCJTdHJpbmciLCJhcHBlYXIiLCJtb3VudE9uRW50ZXIiLCJ1bm1vdW50T25FeGl0Iiwid3JhcENscyIsIndyYXBTdHlsZSIsIk9iamVjdCIsInNldERhdGEiLCJleHRTdHlsZSIsImFuaW1hdGVDc3MiLCJhbmltYXRlU3RhdHVzIiwibWV0aG9kcyIsImFkZEV2ZW50TGlzdGVuZXIiLCJnZXRUaW1lb3V0cyIsInBlcmZvcm1FbnRlcmVkIiwicGVyZm9ybUV4aXRlZCIsIm9uVHJhbnNpdGlvbkVuZCIsIm9uQW5pbWF0aW9uRW5kIiwidXBkYXRlU3RhdHVzIiwibmV4dFN0YXR1cyIsIm1vdW50aW5nIiwiY2FuY2VsTmV4dENhbGxiYWNrIiwiaXNBcHBlYXJpbmciLCJwZXJmb3JtRW50ZXIiLCJwZXJmb3JtRXhpdCIsImdldENsYXNzTmFtZXMiLCJjbGFzc05hbWUiLCJhY3RpdmVDbGFzc05hbWUiLCJlbnRlclBhcmFtcyIsImVudGVyaW5nUGFyYW1zIiwic2FmZVNldERhdGEiLCJ0cmlnZ2VyRXZlbnQiLCJkZWxheUhhbmRsZXIiLCJkb25lQ2xhc3NOYW1lIiwiZW50ZXJlZFBhcmFtcyIsImV4aXRQYXJhbXMiLCJleGl0aW5nUGFyYW1zIiwiZXhpdGVkUGFyYW1zIiwicGVuZGluZ0RhdGEiLCJ0aW1lb3V0IiwiaGFuZGxlciIsInNldE5leHRDYWxsYmFjayIsInNldFRpbWVvdXQiLCJuZXh0Q2FsbGJhY2siLCJvblRhcCIsImF0dGFjaGVkIiwiYXBwZWFyU3RhdHVzIl0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7Ozs7QUFDQTs7Ozs7O0FBRUEsSUFBTUEsUUFBUSxPQUFkO0FBQ0EsSUFBTUMsV0FBVyxVQUFqQjtBQUNBLElBQU1DLFVBQVUsU0FBaEI7QUFDQSxJQUFNQyxPQUFPLE1BQWI7QUFDQSxJQUFNQyxVQUFVLFNBQWhCO0FBQ0EsSUFBTUMsU0FBUyxRQUFmO0FBQ0EsSUFBTUMsWUFBWSxXQUFsQjs7QUFFQSxJQUFNQyxhQUFhLFlBQW5CO0FBQ0EsSUFBTUMsWUFBWSxXQUFsQjs7QUFFQSxJQUFNQyxVQUFVLE9BQU8sRUFBdkI7O0FBRUEsSUFBTUMsb0JBQW9CO0FBQ3RCQyxXQUFPLEVBRGUsRUFDWDtBQUNYQyxpQkFBYSxFQUZTLEVBRUw7QUFDakJDLGVBQVcsRUFIVyxFQUdQO0FBQ2ZDLFVBQU0sRUFKZ0IsRUFJWjtBQUNWQyxnQkFBWSxFQUxVLEVBS047QUFDaEJDLGNBQVUsRUFOWSxDQU1SO0FBTlEsQ0FBMUI7O0FBU0EsNkJBQWM7QUFDVkMsZ0JBQVk7QUFDUjtBQUNBQyxZQUFJO0FBQ0FDLGtCQUFNQyxPQUROO0FBRUFDLG1CQUFPLEtBRlA7QUFHQUMsb0JBSEEsb0JBR1NDLE1BSFQsRUFHaUI7QUFDYixvQkFBSSxLQUFLQyxJQUFMLENBQVVDLFVBQWQsRUFBMEI7QUFDdEIseUJBQUtDLE9BQUwsQ0FBYUgsTUFBYjtBQUNIO0FBQ0o7QUFQRCxTQUZJO0FBV1I7QUFDQUksb0JBQVk7QUFDUlIsa0JBQU0sSUFERTtBQUVSRSxtQkFBT1g7QUFGQyxTQVpKO0FBZ0JSO0FBQ0FrQixrQkFBVTtBQUNOVCxrQkFBTSxJQURBO0FBRU5FLG1CQUFPO0FBRkQsU0FqQkY7QUFxQlI7QUFDQUYsY0FBTTtBQUNGQSxrQkFBTVUsTUFESjtBQUVGUixtQkFBT2Q7QUFGTCxTQXRCRTtBQTBCUjtBQUNBdUIsZ0JBQVE7QUFDSlgsa0JBQU1DLE9BREY7QUFFSkMsbUJBQU87QUFGSCxTQTNCQTtBQStCUjtBQUNBVixlQUFPO0FBQ0hRLGtCQUFNQyxPQURIO0FBRUhDLG1CQUFPO0FBRkosU0FoQ0M7QUFvQ1I7QUFDQVAsY0FBTTtBQUNGSyxrQkFBTUMsT0FESjtBQUVGQyxtQkFBTztBQUZMLFNBckNFO0FBeUNSO0FBQ0FVLHNCQUFjO0FBQ1ZaLGtCQUFNQyxPQURJO0FBRVZDLG1CQUFPO0FBRkcsU0ExQ047QUE4Q1I7QUFDQVcsdUJBQWU7QUFDWGIsa0JBQU1DLE9BREs7QUFFWEMsbUJBQU87QUFGSSxTQS9DUDtBQW1EUjtBQUNBWSxpQkFBUztBQUNMZCxrQkFBTVUsTUFERDtBQUVMUixtQkFBTztBQUZGLFNBcEREO0FBd0RSO0FBQ0FhLG1CQUFXO0FBQ1BmLGtCQUFNLENBQUNVLE1BQUQsRUFBU00sTUFBVCxDQURDO0FBRVBkLG1CQUFPLEVBRkE7QUFHUEMsb0JBSE8sb0JBR0VDLE1BSEYsRUFHVTtBQUNiLHFCQUFLYSxPQUFMLENBQWE7QUFDVEMsOEJBQVUsZ0NBQWlCZCxNQUFqQjtBQURELGlCQUFiO0FBR0g7QUFQTTtBQXpESCxLQURGO0FBb0VWQyxVQUFNO0FBQ0ZjLG9CQUFZLEVBRFYsRUFDYztBQUNoQkMsdUJBQWVsQyxNQUZiLEVBRXFCO0FBQ3ZCb0Isb0JBQVksS0FIVixFQUdpQjtBQUNuQlksa0JBQVUsRUFKUixDQUlZO0FBSlosS0FwRUk7QUEwRVZHLGFBQVM7QUFDTDs7O0FBR0FDLHdCQUpLLDhCQUljO0FBQUEsZ0JBQ1BGLGFBRE8sR0FDVyxLQUFLZixJQURoQixDQUNQZSxhQURPOztBQUFBLCtCQUVTLEtBQUtHLFdBQUwsRUFGVDtBQUFBLGdCQUVQL0IsS0FGTyxnQkFFUEEsS0FGTztBQUFBLGdCQUVBRyxJQUZBLGdCQUVBQSxJQUZBOztBQUlmLGdCQUFJeUIsa0JBQWtCdEMsUUFBbEIsSUFBOEIsQ0FBQ1UsS0FBL0IsSUFBd0MsS0FBS2EsSUFBTCxDQUFVYixLQUF0RCxFQUE2RDtBQUN6RCxxQkFBS2dDLGNBQUw7QUFDSDs7QUFFRCxnQkFBSUosa0JBQWtCbkMsT0FBbEIsSUFBNkIsQ0FBQ1UsSUFBOUIsSUFBc0MsS0FBS1UsSUFBTCxDQUFVVixJQUFwRCxFQUEwRDtBQUN0RCxxQkFBSzhCLGFBQUw7QUFDSDtBQUNKLFNBZkk7O0FBZ0JMOzs7QUFHQUMsdUJBbkJLLDZCQW1CYTtBQUNkLGdCQUFJLEtBQUtyQixJQUFMLENBQVVMLElBQVYsS0FBbUJaLFVBQXZCLEVBQW1DO0FBQy9CLHFCQUFLa0MsZ0JBQUw7QUFDSDtBQUNKLFNBdkJJOztBQXdCTDs7O0FBR0FLLHNCQTNCSyw0QkEyQlk7QUFDYixnQkFBSSxLQUFLdEIsSUFBTCxDQUFVTCxJQUFWLEtBQW1CWCxTQUF2QixFQUFrQztBQUM5QixxQkFBS2lDLGdCQUFMO0FBQ0g7QUFDSixTQS9CSTs7QUFnQ0w7Ozs7O0FBS0FNLG9CQXJDSyx3QkFxQ1FDLFVBckNSLEVBcUNzQztBQUFBLGdCQUFsQkMsUUFBa0IsdUVBQVAsS0FBTzs7QUFDdkMsZ0JBQUlELGVBQWUsSUFBbkIsRUFBeUI7QUFDckIscUJBQUtFLGtCQUFMO0FBQ0EscUJBQUtDLFdBQUwsR0FBbUJGLFFBQW5COztBQUVBLG9CQUFJRCxlQUFlL0MsUUFBbkIsRUFBNkI7QUFDekIseUJBQUttRCxZQUFMO0FBQ0gsaUJBRkQsTUFFTztBQUNILHlCQUFLQyxXQUFMO0FBQ0g7QUFDSjtBQUNKLFNBaERJOztBQWlETDs7O0FBR0FELG9CQXBESywwQkFvRFU7QUFBQTs7QUFBQSxpQ0FDNEIsS0FBS0UsYUFBTCxDQUFtQnRELEtBQW5CLENBRDVCO0FBQUEsZ0JBQ0h1RCxTQURHLGtCQUNIQSxTQURHO0FBQUEsZ0JBQ1FDLGVBRFIsa0JBQ1FBLGVBRFI7O0FBQUEsZ0NBRU8sS0FBS2QsV0FBTCxFQUZQO0FBQUEsZ0JBRUgvQixLQUZHLGlCQUVIQSxLQUZHOztBQUdYLGdCQUFNOEMsY0FBYztBQUNoQmxCLCtCQUFldkMsS0FEQztBQUVoQnNDLDRCQUFZaUI7QUFGSSxhQUFwQjtBQUlBLGdCQUFNRyxpQkFBaUI7QUFDbkJuQiwrQkFBZXRDLFFBREk7QUFFbkJxQyw0QkFBZWlCLFNBQWYsU0FBNEJDOztBQUdoQztBQUx1QixhQUF2QixDQU1BLElBQUksQ0FBQyxLQUFLTCxXQUFOLElBQXFCLENBQUMsS0FBSzNCLElBQUwsQ0FBVWIsS0FBcEMsRUFBMkM7QUFDdkMsdUJBQU8sS0FBS2dDLGNBQUwsRUFBUDtBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNBLGlCQUFLZ0IsV0FBTCxDQUFpQkYsV0FBakIsRUFBOEIsWUFBTTtBQUNoQyxzQkFBS0csWUFBTCxDQUFrQixRQUFsQixFQUE0QixFQUFFckIsZUFBZXZDLEtBQWpCLEVBQTVCO0FBQ0Esc0JBQUs0RCxZQUFMLENBQWtCNUQsS0FBbEIsRUFBeUIsRUFBRW1ELGFBQWEsTUFBS0EsV0FBcEIsRUFBekI7O0FBRUE7QUFDQTtBQUNBLHNCQUFLVSxZQUFMLENBQWtCcEQsT0FBbEIsRUFBMkIsWUFBTTtBQUM3QiwwQkFBS2tELFdBQUwsQ0FBaUJELGNBQWpCLEVBQWlDLFlBQU07QUFDbkMsOEJBQUtFLFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsRUFBRXJCLGVBQWV0QyxRQUFqQixFQUE1QjtBQUNBLDhCQUFLMkQsWUFBTCxDQUFrQjNELFFBQWxCLEVBQTRCLEVBQUVrRCxhQUFhLE1BQUtBLFdBQXBCLEVBQTVCOztBQUVBLDRCQUFJeEMsS0FBSixFQUFXO0FBQ1Asa0NBQUtrRCxZQUFMLENBQWtCbEQsS0FBbEIsRUFBeUIsTUFBS2dDLGNBQTlCO0FBQ0g7QUFDSixxQkFQRDtBQVFILGlCQVREO0FBVUgsYUFoQkQ7QUFpQkgsU0F6Rkk7O0FBMEZMOzs7QUFHQUEsc0JBN0ZLLDRCQTZGWTtBQUFBOztBQUFBLGtDQUNhLEtBQUtXLGFBQUwsQ0FBbUJ0RCxLQUFuQixDQURiO0FBQUEsZ0JBQ0w4RCxhQURLLG1CQUNMQSxhQURLOztBQUViLGdCQUFNQyxnQkFBZ0I7QUFDbEJ4QiwrQkFBZXJDLE9BREc7QUFFbEJvQyw0QkFBWXdCOztBQUdoQjtBQUxzQixhQUF0QixDQU1BLEtBQUtILFdBQUwsQ0FBaUJJLGFBQWpCLEVBQWdDLFlBQU07QUFDbEMsdUJBQUtILFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsRUFBRXJCLGVBQWVyQyxPQUFqQixFQUE1QjtBQUNBLHVCQUFLMEQsWUFBTCxDQUFrQjFELE9BQWxCLEVBQTJCLEVBQUVpRCxhQUFhLE9BQUtBLFdBQXBCLEVBQTNCO0FBQ0gsYUFIRDtBQUlILFNBekdJOztBQTBHTDs7O0FBR0FFLG1CQTdHSyx5QkE2R1M7QUFBQTs7QUFBQSxrQ0FDNkIsS0FBS0MsYUFBTCxDQUFtQm5ELElBQW5CLENBRDdCO0FBQUEsZ0JBQ0ZvRCxTQURFLG1CQUNGQSxTQURFO0FBQUEsZ0JBQ1NDLGVBRFQsbUJBQ1NBLGVBRFQ7O0FBQUEsZ0NBRU8sS0FBS2QsV0FBTCxFQUZQO0FBQUEsZ0JBRUY1QixJQUZFLGlCQUVGQSxJQUZFOztBQUdWLGdCQUFNa0QsYUFBYTtBQUNmekIsK0JBQWVwQyxJQURBO0FBRWZtQyw0QkFBWWlCO0FBRkcsYUFBbkI7QUFJQSxnQkFBTVUsZ0JBQWdCO0FBQ2xCMUIsK0JBQWVuQyxPQURHO0FBRWxCa0MsNEJBQWVpQixTQUFmLFNBQTRCQzs7QUFHaEM7QUFMc0IsYUFBdEIsQ0FNQSxJQUFJLENBQUMsS0FBS2hDLElBQUwsQ0FBVVYsSUFBZixFQUFxQjtBQUNqQix1QkFBTyxLQUFLOEIsYUFBTCxFQUFQO0FBQ0g7O0FBRUQ7QUFDQTtBQUNBO0FBQ0EsaUJBQUtlLFdBQUwsQ0FBaUJLLFVBQWpCLEVBQTZCLFlBQU07QUFDL0IsdUJBQUtKLFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsRUFBRXJCLGVBQWVwQyxJQUFqQixFQUE1QjtBQUNBLHVCQUFLeUQsWUFBTCxDQUFrQnpELElBQWxCOztBQUVBLHVCQUFLMEQsWUFBTCxDQUFrQnBELE9BQWxCLEVBQTJCLFlBQU07QUFDN0IsMkJBQUtrRCxXQUFMLENBQWlCTSxhQUFqQixFQUFnQyxZQUFNO0FBQ2xDLCtCQUFLTCxZQUFMLENBQWtCLFFBQWxCLEVBQTRCLEVBQUVyQixlQUFlbkMsT0FBakIsRUFBNUI7QUFDQSwrQkFBS3dELFlBQUwsQ0FBa0J4RCxPQUFsQjs7QUFFQSw0QkFBSVUsSUFBSixFQUFVO0FBQ04sbUNBQUsrQyxZQUFMLENBQWtCL0MsSUFBbEIsRUFBd0IsT0FBSzhCLGFBQTdCO0FBQ0g7QUFDSixxQkFQRDtBQVFILGlCQVREO0FBVUgsYUFkRDtBQWVILFNBaEpJOztBQWlKTDs7O0FBR0FBLHFCQXBKSywyQkFvSlc7QUFBQTs7QUFBQSxrQ0FDYyxLQUFLVSxhQUFMLENBQW1CbkQsSUFBbkIsQ0FEZDtBQUFBLGdCQUNKMkQsYUFESSxtQkFDSkEsYUFESTs7QUFFWixnQkFBTUksZUFBZTtBQUNqQjNCLCtCQUFlbEMsTUFERTtBQUVqQmlDLDRCQUFZd0I7O0FBR2hCO0FBTHFCLGFBQXJCLENBTUEsS0FBS0gsV0FBTCxDQUFpQk8sWUFBakIsRUFBK0IsWUFBTTtBQUNqQyx1QkFBS04sWUFBTCxDQUFrQixRQUFsQixFQUE0QixFQUFFckIsZUFBZWxDLE1BQWpCLEVBQTVCO0FBQ0EsdUJBQUt1RCxZQUFMLENBQWtCdkQsTUFBbEI7O0FBRUE7QUFDQSxvQkFBSSxPQUFLbUIsSUFBTCxDQUFVUSxhQUFkLEVBQTZCO0FBQ3pCLDJCQUFLSSxPQUFMLENBQWEsRUFBRUcsZUFBZWpDLFNBQWpCLEVBQWIsRUFBMkMsWUFBTTtBQUM3QywrQkFBS3NELFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsRUFBRXJCLGVBQWVqQyxTQUFqQixFQUE1QjtBQUNILHFCQUZEO0FBR0g7QUFDSixhQVZEO0FBV0gsU0F2S0k7O0FBd0tMOzs7O0FBSUFnRCxxQkE1S0sseUJBNEtTbkMsSUE1S1QsRUE0S2U7QUFBQSxnQkFDUlEsVUFEUSxHQUNPLEtBQUtILElBRFosQ0FDUkcsVUFEUTs7QUFFaEIsZ0JBQU00QixZQUFZLE9BQU81QixVQUFQLEtBQXNCLFFBQXRCLEdBQWlDQSxXQUFXUixJQUFYLENBQWpDLEdBQXVEUSxVQUF2RCxTQUFxRVIsSUFBdkY7QUFDQSxnQkFBTXFDLGtCQUFrQixPQUFPN0IsVUFBUCxLQUFzQixRQUF0QixHQUFpQ0EsV0FBY1IsSUFBZCxZQUFqQyxHQUFrRVEsVUFBbEUsU0FBZ0ZSLElBQWhGLFlBQXhCO0FBQ0EsZ0JBQU0yQyxnQkFBZ0IsT0FBT25DLFVBQVAsS0FBc0IsUUFBdEIsR0FBaUNBLFdBQWNSLElBQWQsVUFBakMsR0FBZ0VRLFVBQWhFLFNBQThFUixJQUE5RSxVQUF0Qjs7QUFFQSxtQkFBTztBQUNIb0Msb0NBREc7QUFFSEMsZ0RBRkc7QUFHSE07QUFIRyxhQUFQO0FBS0gsU0F2TEk7O0FBd0xMOzs7QUFHQXBCLG1CQTNMSyx5QkEyTFM7QUFBQSxnQkFDRmQsUUFERSxHQUNXLEtBQUtKLElBRGhCLENBQ0ZJLFFBREU7OztBQUdWLGdCQUFJQSxhQUFhLElBQWIsSUFBcUIsUUFBT0EsUUFBUCx5Q0FBT0EsUUFBUCxPQUFvQixRQUE3QyxFQUF1RDtBQUNuRCx1QkFBTztBQUNIakIsMkJBQU9pQixTQUFTakIsS0FEYjtBQUVIRywwQkFBTWMsU0FBU2Q7QUFGWixpQkFBUDtBQUlILGFBTEQsTUFLTyxJQUFJLE9BQU9jLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDckMsdUJBQU87QUFDSGpCLDJCQUFPaUIsUUFESjtBQUVIZCwwQkFBTWM7QUFGSCxpQkFBUDtBQUlIOztBQUVELG1CQUFPLEVBQVA7QUFDSCxTQTNNSTs7QUE0TUw7Ozs7QUFJQUYsZUFoTkssbUJBZ05HSCxNQWhOSCxFQWdOVztBQUFBOztBQUFBLHVCQUNZLEtBQUs0QyxXQUFMLElBQW9CLEtBQUszQyxJQURyQztBQUFBLGdCQUNOZSxhQURNLFFBQ05BLGFBRE07O0FBRVosZ0JBQUlTLGFBQWEsSUFBakI7O0FBRUEsZ0JBQUl6QixNQUFKLEVBQVk7QUFDUixvQkFBSWdCLGtCQUFrQmpDLFNBQXRCLEVBQWlDO0FBQzdCaUMsb0NBQWdCbEMsTUFBaEI7QUFDQSx5QkFBSytCLE9BQUwsQ0FBYSxFQUFFRyxlQUFlbEMsTUFBakIsRUFBYixFQUF3QyxZQUFNO0FBQzFDLCtCQUFLdUQsWUFBTCxDQUFrQixRQUFsQixFQUE0QixFQUFFckIsZUFBZWxDLE1BQWpCLEVBQTVCO0FBQ0gscUJBRkQ7QUFHSDtBQUNELG9CQUFJa0Msa0JBQWtCdkMsS0FBbEIsSUFBMkJ1QyxrQkFBa0J0QyxRQUE3QyxJQUF5RHNDLGtCQUFrQnJDLE9BQS9FLEVBQXdGO0FBQ3BGOEMsaUNBQWEvQyxRQUFiO0FBQ0g7QUFDSixhQVZELE1BVU87QUFDSCxvQkFBSXNDLGtCQUFrQnZDLEtBQWxCLElBQTJCdUMsa0JBQWtCdEMsUUFBN0MsSUFBeURzQyxrQkFBa0JyQyxPQUEvRSxFQUF3RjtBQUNwRjhDLGlDQUFhNUMsT0FBYjtBQUNIO0FBQ0o7O0FBRUQsaUJBQUsyQyxZQUFMLENBQWtCQyxVQUFsQjtBQUNILFNBck9JOztBQXNPTDs7Ozs7QUFLQWEsb0JBM09LLHdCQTJPUU8sT0EzT1IsRUEyT2lCQyxPQTNPakIsRUEyTzBCO0FBQzNCLGdCQUFJRCxPQUFKLEVBQWE7QUFDVCxxQkFBS0UsZUFBTCxDQUFxQkQsT0FBckI7QUFDQUUsMkJBQVcsS0FBS0MsWUFBaEIsRUFBOEJKLE9BQTlCO0FBQ0g7QUFDSixTQWhQSTs7QUFpUEw7OztBQUdBSyxhQXBQSyxtQkFvUEc7QUFDSixpQkFBS2IsWUFBTCxDQUFrQixPQUFsQjtBQUNIO0FBdFBJLEtBMUVDO0FBa1VWYyxZQWxVVSxzQkFrVUM7QUFBQTs7QUFDUCxZQUFJbkMsZ0JBQWdCLElBQXBCO0FBQ0EsWUFBSW9DLGVBQWUsSUFBbkI7O0FBRUEsWUFBSSxLQUFLbkQsSUFBTCxDQUFVTixFQUFkLEVBQWtCO0FBQ2QsZ0JBQUksS0FBS00sSUFBTCxDQUFVTSxNQUFkLEVBQXNCO0FBQ2xCUyxnQ0FBZ0JsQyxNQUFoQjtBQUNBc0UsK0JBQWUxRSxRQUFmO0FBQ0gsYUFIRCxNQUdPO0FBQ0hzQyxnQ0FBZ0JyQyxPQUFoQjtBQUNIO0FBQ0osU0FQRCxNQU9PO0FBQ0gsZ0JBQUksS0FBS3NCLElBQUwsQ0FBVVEsYUFBVixJQUEyQixLQUFLUixJQUFMLENBQVVPLFlBQXpDLEVBQXVEO0FBQ25EUSxnQ0FBZ0JqQyxTQUFoQjtBQUNILGFBRkQsTUFFTztBQUNIaUMsZ0NBQWdCbEMsTUFBaEI7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDQSxhQUFLc0QsV0FBTCxDQUFpQixFQUFFcEIsNEJBQUYsRUFBaUJkLFlBQVksSUFBN0IsRUFBakIsRUFBc0QsWUFBTTtBQUN4RCxtQkFBS21DLFlBQUwsQ0FBa0IsUUFBbEIsRUFBNEIsRUFBRXJCLDRCQUFGLEVBQTVCO0FBQ0EsbUJBQUtRLFlBQUwsQ0FBa0I0QixZQUFsQixFQUFnQyxJQUFoQztBQUNILFNBSEQ7QUFJSDtBQTNWUyxDQUFkIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGJhc2VDb21wb25lbnQgZnJvbSAnLi4vaGVscGVycy9iYXNlQ29tcG9uZW50J1xuaW1wb3J0IHN0eWxlVG9Dc3NTdHJpbmcgZnJvbSAnLi4vaGVscGVycy9zdHlsZVRvQ3NzU3RyaW5nJ1xuXG5jb25zdCBFTlRFUiA9ICdlbnRlcidcbmNvbnN0IEVOVEVSSU5HID0gJ2VudGVyaW5nJ1xuY29uc3QgRU5URVJFRCA9ICdlbnRlcmVkJ1xuY29uc3QgRVhJVCA9ICdleGl0J1xuY29uc3QgRVhJVElORyA9ICdleGl0aW5nJ1xuY29uc3QgRVhJVEVEID0gJ2V4aXRlZCdcbmNvbnN0IFVOTU9VTlRFRCA9ICd1bm1vdW50ZWQnXG5cbmNvbnN0IFRSQU5TSVRJT04gPSAndHJhbnNpdGlvbidcbmNvbnN0IEFOSU1BVElPTiA9ICdhbmltYXRpb24nXG5cbmNvbnN0IFRJTUVPVVQgPSAxMDAwIC8gNjBcblxuY29uc3QgZGVmYXVsdENsYXNzTmFtZXMgPSB7XG4gICAgZW50ZXI6ICcnLCAvLyDov5vlhaXov4fmuKHnmoTlvIDlp4vnirbmgIHvvIzlnKjov4fmuKHov4fnqIvlrozmiJDkuYvlkI7np7vpmaRcbiAgICBlbnRlckFjdGl2ZTogJycsIC8vIOi/m+WFpei/h+a4oeeahOe7k+adn+eKtuaAge+8jOWcqOi/h+a4oei/h+eoi+WujOaIkOS5i+WQjuenu+mZpFxuICAgIGVudGVyRG9uZTogJycsIC8vIOi/m+WFpei/h+a4oeeahOWujOaIkOeKtuaAgVxuICAgIGV4aXQ6ICcnLCAvLyDnprvlvIDov4fmuKHnmoTlvIDlp4vnirbmgIHvvIzlnKjov4fmuKHov4fnqIvlrozmiJDkuYvlkI7np7vpmaRcbiAgICBleGl0QWN0aXZlOiAnJywgLy8g56a75byA6L+H5rih55qE57uT5p2f54q25oCB77yM5Zyo6L+H5rih6L+H56iL5a6M5oiQ5LmL5ZCO56e76ZmkXG4gICAgZXhpdERvbmU6ICcnLCAvLyDnprvlvIDov4fmuKHnmoTlrozmiJDnirbmgIFcbn1cblxuYmFzZUNvbXBvbmVudCh7XG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyDop6blj5Hnu4Tku7bov5vlhaXmiJbnprvlvIDov4fmuKHnmoTnirbmgIFcbiAgICAgICAgaW46IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgICAgICBvYnNlcnZlcihuZXdWYWwpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kYXRhLmlzTW91bnRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVkKG5ld1ZhbClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICAvLyDov4fmuKHnmoTnsbvlkI1cbiAgICAgICAgY2xhc3NOYW1lczoge1xuICAgICAgICAgICAgdHlwZTogbnVsbCxcbiAgICAgICAgICAgIHZhbHVlOiBkZWZhdWx0Q2xhc3NOYW1lcyxcbiAgICAgICAgfSxcbiAgICAgICAgLy8g6L+H5rih5oyB57ut5pe26Ze0XG4gICAgICAgIGR1cmF0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiBudWxsLFxuICAgICAgICAgICAgdmFsdWU6IG51bGwsXG4gICAgICAgIH0sXG4gICAgICAgIC8vIOi/h+a4oeWKqOaViOeahOexu+Wei1xuICAgICAgICB0eXBlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogVFJBTlNJVElPTixcbiAgICAgICAgfSxcbiAgICAgICAgLy8g6aaW5qyh5oyC6L295pe25piv5ZCm6Kem5Y+R6L+b5YWl6L+H5rihXG4gICAgICAgIGFwcGVhcjoge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgLy8g5piv5ZCm5ZCv55So6L+b5YWl6L+H5rihXG4gICAgICAgIGVudGVyOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIC8vIOaYr+WQpuWQr+eUqOemu+W8gOi/h+a4oVxuICAgICAgICBleGl0OiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIC8vIOmmluasoei/m+WFpei/h+a4oeaXtuaYr+WQpuaHkuaMgui9vee7hOS7tlxuICAgICAgICBtb3VudE9uRW50ZXI6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgLy8g56a75byA6L+H5rih5a6M5oiQ5pe25piv5ZCm5Y246L2957uE5Lu2XG4gICAgICAgIHVubW91bnRPbkV4aXQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgLy8g6Ieq5a6a5LmJ57G75ZCNXG4gICAgICAgIHdyYXBDbHM6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgLy8g6Ieq5a6a5LmJ5qC35byPXG4gICAgICAgIHdyYXBTdHlsZToge1xuICAgICAgICAgICAgdHlwZTogW1N0cmluZywgT2JqZWN0XSxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgICAgIG9ic2VydmVyKG5ld1ZhbCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIGV4dFN0eWxlOiBzdHlsZVRvQ3NzU3RyaW5nKG5ld1ZhbCksXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBkYXRhOiB7XG4gICAgICAgIGFuaW1hdGVDc3M6ICcnLCAvLyDliqjnlLvmoLflvI9cbiAgICAgICAgYW5pbWF0ZVN0YXR1czogRVhJVEVELCAvLyDliqjnlLvnirbmgIHvvIzlj6/pgInlgLwgZW50ZXJpbmfjgIFlbnRlcmVk44CBZXhpdGluZ+OAgWV4aXRlZFxuICAgICAgICBpc01vdW50aW5nOiBmYWxzZSwgLy8g5piv5ZCm6aaW5qyh5oyC6L29XG4gICAgICAgIGV4dFN0eWxlOiAnJywgLy8g57uE5Lu25qC35byPXG4gICAgfSxcbiAgICBtZXRob2RzOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiDnm5HlkKzov4fmuKHmiJbliqjnlLvnmoTlm57osIPlh73mlbBcbiAgICAgICAgICovXG4gICAgICAgIGFkZEV2ZW50TGlzdGVuZXIoKSB7XG4gICAgICAgICAgICBjb25zdCB7IGFuaW1hdGVTdGF0dXMgfSA9IHRoaXMuZGF0YVxuICAgICAgICAgICAgY29uc3QgeyBlbnRlciwgZXhpdCB9ID0gdGhpcy5nZXRUaW1lb3V0cygpXG5cbiAgICAgICAgICAgIGlmIChhbmltYXRlU3RhdHVzID09PSBFTlRFUklORyAmJiAhZW50ZXIgJiYgdGhpcy5kYXRhLmVudGVyKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wZXJmb3JtRW50ZXJlZCgpXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChhbmltYXRlU3RhdHVzID09PSBFWElUSU5HICYmICFleGl0ICYmIHRoaXMuZGF0YS5leGl0KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wZXJmb3JtRXhpdGVkKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOS8muWcqCBXWFNTIHRyYW5zaXRpb24g5oiWIHd4LmNyZWF0ZUFuaW1hdGlvbiDliqjnlLvnu5PmnZ/lkI7op6blj5FcbiAgICAgICAgICovXG4gICAgICAgIG9uVHJhbnNpdGlvbkVuZCgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmRhdGEudHlwZSA9PT0gVFJBTlNJVElPTikge1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcigpXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDkvJrlnKjkuIDkuKogV1hTUyBhbmltYXRpb24g5Yqo55S75a6M5oiQ5pe26Kem5Y+RXG4gICAgICAgICAqL1xuICAgICAgICBvbkFuaW1hdGlvbkVuZCgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmRhdGEudHlwZSA9PT0gQU5JTUFUSU9OKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOabtOaWsOe7hOS7tueKtuaAgVxuICAgICAgICAgKiBAcGFyYW0ge1N0cmluZ30gbmV4dFN0YXR1cyDkuIvkuIDnirbmgIHvvIxFTlRFUklORyDmiJYgRVhJVElOR1xuICAgICAgICAgKiBAcGFyYW0ge0Jvb2xlYW59IG1vdW50aW5nIOaYr+WQpummluasoeaMgui9vVxuICAgICAgICAgKi9cbiAgICAgICAgdXBkYXRlU3RhdHVzKG5leHRTdGF0dXMsIG1vdW50aW5nID0gZmFsc2UpIHtcbiAgICAgICAgICAgIGlmIChuZXh0U3RhdHVzICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jYW5jZWxOZXh0Q2FsbGJhY2soKVxuICAgICAgICAgICAgICAgIHRoaXMuaXNBcHBlYXJpbmcgPSBtb3VudGluZ1xuXG4gICAgICAgICAgICAgICAgaWYgKG5leHRTdGF0dXMgPT09IEVOVEVSSU5HKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGVyZm9ybUVudGVyKClcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBlcmZvcm1FeGl0KClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDov5vlhaXov4fmuKFcbiAgICAgICAgICovXG4gICAgICAgIHBlcmZvcm1FbnRlcigpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgY2xhc3NOYW1lLCBhY3RpdmVDbGFzc05hbWUgfSA9IHRoaXMuZ2V0Q2xhc3NOYW1lcyhFTlRFUilcbiAgICAgICAgICAgIGNvbnN0IHsgZW50ZXIgfSA9IHRoaXMuZ2V0VGltZW91dHMoKVxuICAgICAgICAgICAgY29uc3QgZW50ZXJQYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgYW5pbWF0ZVN0YXR1czogRU5URVIsXG4gICAgICAgICAgICAgICAgYW5pbWF0ZUNzczogY2xhc3NOYW1lLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZW50ZXJpbmdQYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgYW5pbWF0ZVN0YXR1czogRU5URVJJTkcsXG4gICAgICAgICAgICAgICAgYW5pbWF0ZUNzczogYCR7Y2xhc3NOYW1lfSAke2FjdGl2ZUNsYXNzTmFtZX1gLFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyDoi6Xlt7LnpoHnlKjov5vlhaXov4fmuKHvvIzliJnmm7TmlrDnirbmgIHoh7MgRU5URVJFRFxuICAgICAgICAgICAgaWYgKCF0aGlzLmlzQXBwZWFyaW5nICYmICF0aGlzLmRhdGEuZW50ZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wZXJmb3JtRW50ZXJlZCgpXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOesrOS4gOmYtuaute+8muiuvue9rui/m+WFpei/h+a4oeeahOW8gOWni+eKtuaAge+8jOW5tuinpuWPkSBFTlRFUiDkuovku7ZcbiAgICAgICAgICAgIC8vIOesrOS6jOmYtuaute+8muW7tui/n+S4gOW4p+WQju+8jOiuvue9rui/m+WFpei/h+a4oeeahOe7k+adn+eKtuaAge+8jOW5tuinpuWPkSBFTlRFUklORyDkuovku7ZcbiAgICAgICAgICAgIC8vIOesrOS4iemYtuaute+8muiLpeW3suiuvue9rui/h+a4oeeahOaMgee7reaXtumXtO+8jOWImeW7tui/n+aMh+WumuaXtumXtOWQjuinpuWPkei/m+WFpei/h+a4oeWujOaIkCBwZXJmb3JtRW50ZXJlZO+8jOWQpuWImeetieW+heinpuWPkSBvblRyYW5zaXRpb25FbmQg5oiWIG9uQW5pbWF0aW9uRW5kXG4gICAgICAgICAgICB0aGlzLnNhZmVTZXREYXRhKGVudGVyUGFyYW1zLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2NoYW5nZScsIHsgYW5pbWF0ZVN0YXR1czogRU5URVIgfSlcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudChFTlRFUiwgeyBpc0FwcGVhcmluZzogdGhpcy5pc0FwcGVhcmluZyB9KVxuXG4gICAgICAgICAgICAgICAgLy8g55Sx5LqO5pyJ5Lqb5pe25YCZ5LiN6IO95q2j56Gu55qE6Kem5Y+R5Yqo55S75a6M5oiQ55qE5Zue6LCD77yM5YW35L2T5Y6f5Zug5pyq55+lXG4gICAgICAgICAgICAgICAgLy8g5omA5Lul6YeH55So5bu26L+f5LiA5bin55qE5pa55byP5p2l56Gu5L+d5Y+v5Lul6Kem5Y+R5Zue6LCDXG4gICAgICAgICAgICAgICAgdGhpcy5kZWxheUhhbmRsZXIoVElNRU9VVCwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNhZmVTZXREYXRhKGVudGVyaW5nUGFyYW1zLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2hhbmdlJywgeyBhbmltYXRlU3RhdHVzOiBFTlRFUklORyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoRU5URVJJTkcsIHsgaXNBcHBlYXJpbmc6IHRoaXMuaXNBcHBlYXJpbmcgfSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVudGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWxheUhhbmRsZXIoZW50ZXIsIHRoaXMucGVyZm9ybUVudGVyZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDov5vlhaXov4fmuKHlrozmiJBcbiAgICAgICAgICovXG4gICAgICAgIHBlcmZvcm1FbnRlcmVkKCkge1xuICAgICAgICAgICAgY29uc3QgeyBkb25lQ2xhc3NOYW1lIH0gPSB0aGlzLmdldENsYXNzTmFtZXMoRU5URVIpXG4gICAgICAgICAgICBjb25zdCBlbnRlcmVkUGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGFuaW1hdGVTdGF0dXM6IEVOVEVSRUQsXG4gICAgICAgICAgICAgICAgYW5pbWF0ZUNzczogZG9uZUNsYXNzTmFtZSxcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8g56ys5LiJ6Zi25q6177ya6K6+572u6L+b5YWl6L+H5rih55qE5a6M5oiQ54q25oCB77yM5bm26Kem5Y+RIEVOVEVSRUQg5LqL5Lu2XG4gICAgICAgICAgICB0aGlzLnNhZmVTZXREYXRhKGVudGVyZWRQYXJhbXMsICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2hhbmdlJywgeyBhbmltYXRlU3RhdHVzOiBFTlRFUkVEIH0pXG4gICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoRU5URVJFRCwgeyBpc0FwcGVhcmluZzogdGhpcy5pc0FwcGVhcmluZyB9KVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOemu+W8gOi/h+a4oVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyZm9ybUV4aXQoKSB7XG4gICAgICAgICAgICBjb25zdCB7IGNsYXNzTmFtZSwgYWN0aXZlQ2xhc3NOYW1lIH0gPSB0aGlzLmdldENsYXNzTmFtZXMoRVhJVClcbiAgICAgICAgICAgIGNvbnN0IHsgZXhpdCB9ID0gdGhpcy5nZXRUaW1lb3V0cygpXG4gICAgICAgICAgICBjb25zdCBleGl0UGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGFuaW1hdGVTdGF0dXM6IEVYSVQsXG4gICAgICAgICAgICAgICAgYW5pbWF0ZUNzczogY2xhc3NOYW1lLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZXhpdGluZ1BhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICBhbmltYXRlU3RhdHVzOiBFWElUSU5HLFxuICAgICAgICAgICAgICAgIGFuaW1hdGVDc3M6IGAke2NsYXNzTmFtZX0gJHthY3RpdmVDbGFzc05hbWV9YCxcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8g6Iul5bey56aB55So56a75byA6L+H5rih77yM5YiZ5pu05paw54q25oCB6IezIEVYSVRFRFxuICAgICAgICAgICAgaWYgKCF0aGlzLmRhdGEuZXhpdCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnBlcmZvcm1FeGl0ZWQoKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyDnrKzkuIDpmLbmrrXvvJrorr7nva7nprvlvIDov4fmuKHnmoTlvIDlp4vnirbmgIHvvIzlubbop6blj5EgRVhJVCDkuovku7ZcbiAgICAgICAgICAgIC8vIOesrOS6jOmYtuaute+8muW7tui/n+S4gOW4p+WQju+8jOiuvue9ruemu+W8gOi/h+a4oeeahOe7k+adn+eKtuaAge+8jOW5tuinpuWPkSBFWElUSU5HIOS6i+S7tlxuICAgICAgICAgICAgLy8g56ys5LiJ6Zi25q6177ya6Iul5bey6K6+572u6L+H5rih55qE5oyB57ut5pe26Ze077yM5YiZ5bu26L+f5oyH5a6a5pe26Ze05ZCO6Kem5Y+R56a75byA6L+H5rih5a6M5oiQIHBlcmZvcm1FeGl0ZWTvvIzlkKbliJnnrYnlvoXop6blj5Egb25UcmFuc2l0aW9uRW5kIOaIliBvbkFuaW1hdGlvbkVuZFxuICAgICAgICAgICAgdGhpcy5zYWZlU2V0RGF0YShleGl0UGFyYW1zLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2NoYW5nZScsIHsgYW5pbWF0ZVN0YXR1czogRVhJVCB9KVxuICAgICAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KEVYSVQpXG5cbiAgICAgICAgICAgICAgICB0aGlzLmRlbGF5SGFuZGxlcihUSU1FT1VULCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2FmZVNldERhdGEoZXhpdGluZ1BhcmFtcywgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2NoYW5nZScsIHsgYW5pbWF0ZVN0YXR1czogRVhJVElORyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoRVhJVElORylcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV4aXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRlbGF5SGFuZGxlcihleGl0LCB0aGlzLnBlcmZvcm1FeGl0ZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDnprvlvIDov4fmuKHlrozmiJBcbiAgICAgICAgICovXG4gICAgICAgIHBlcmZvcm1FeGl0ZWQoKSB7XG4gICAgICAgICAgICBjb25zdCB7IGRvbmVDbGFzc05hbWUgfSA9IHRoaXMuZ2V0Q2xhc3NOYW1lcyhFWElUKVxuICAgICAgICAgICAgY29uc3QgZXhpdGVkUGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGFuaW1hdGVTdGF0dXM6IEVYSVRFRCxcbiAgICAgICAgICAgICAgICBhbmltYXRlQ3NzOiBkb25lQ2xhc3NOYW1lLFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyDnrKzkuInpmLbmrrXvvJrorr7nva7nprvlvIDov4fmuKHnmoTlrozmiJDnirbmgIHvvIzlubbop6blj5EgRVhJVEVEIOS6i+S7tlxuICAgICAgICAgICAgdGhpcy5zYWZlU2V0RGF0YShleGl0ZWRQYXJhbXMsICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2hhbmdlJywgeyBhbmltYXRlU3RhdHVzOiBFWElURUQgfSlcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudChFWElURUQpXG5cbiAgICAgICAgICAgICAgICAvLyDliKTmlq3nprvlvIDov4fmuKHlrozmiJDml7bmmK/lkKbljbjovb3nu4Tku7ZcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kYXRhLnVubW91bnRPbkV4aXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgYW5pbWF0ZVN0YXR1czogVU5NT1VOVEVEIH0sICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KCdjaGFuZ2UnLCB7IGFuaW1hdGVTdGF0dXM6IFVOTU9VTlRFRCB9KVxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDojrflj5bmjIflrprnirbmgIHkuIvnmoTnsbvlkI1cbiAgICAgICAgICogQHBhcmFtIHtTdHJpbmd9IHR5cGUg6L+H5rih57G75Z6L77yMZW50ZXIg5oiWIGV4aXRcbiAgICAgICAgICovXG4gICAgICAgIGdldENsYXNzTmFtZXModHlwZSkge1xuICAgICAgICAgICAgY29uc3QgeyBjbGFzc05hbWVzIH0gPSB0aGlzLmRhdGFcbiAgICAgICAgICAgIGNvbnN0IGNsYXNzTmFtZSA9IHR5cGVvZiBjbGFzc05hbWVzICE9PSAnc3RyaW5nJyA/IGNsYXNzTmFtZXNbdHlwZV0gOiBgJHtjbGFzc05hbWVzfS0ke3R5cGV9YFxuICAgICAgICAgICAgY29uc3QgYWN0aXZlQ2xhc3NOYW1lID0gdHlwZW9mIGNsYXNzTmFtZXMgIT09ICdzdHJpbmcnID8gY2xhc3NOYW1lc1tgJHt0eXBlfUFjdGl2ZWBdIDogYCR7Y2xhc3NOYW1lc30tJHt0eXBlfS1hY3RpdmVgXG4gICAgICAgICAgICBjb25zdCBkb25lQ2xhc3NOYW1lID0gdHlwZW9mIGNsYXNzTmFtZXMgIT09ICdzdHJpbmcnID8gY2xhc3NOYW1lc1tgJHt0eXBlfURvbmVgXSA6IGAke2NsYXNzTmFtZXN9LSR7dHlwZX0tZG9uZWBcblxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgICAgICAgICAgYWN0aXZlQ2xhc3NOYW1lLFxuICAgICAgICAgICAgICAgIGRvbmVDbGFzc05hbWUsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiDojrflj5bov4fmuKHmjIHnu63ml7bpl7RcbiAgICAgICAgICovXG4gICAgICAgIGdldFRpbWVvdXRzKCkge1xuICAgICAgICAgICAgY29uc3QgeyBkdXJhdGlvbiB9ID0gdGhpcy5kYXRhXG5cbiAgICAgICAgICAgIGlmIChkdXJhdGlvbiAhPT0gbnVsbCAmJiB0eXBlb2YgZHVyYXRpb24gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgZW50ZXI6IGR1cmF0aW9uLmVudGVyLFxuICAgICAgICAgICAgICAgICAgICBleGl0OiBkdXJhdGlvbi5leGl0LFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGR1cmF0aW9uID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGVudGVyOiBkdXJhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgZXhpdDogZHVyYXRpb24sXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4ge31cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOWxnuaAp+WAvCBpbiDooqvmm7TmlLnml7bnmoTlk43lupTlh73mlbBcbiAgICAgICAgICogQHBhcmFtIHtCb29sZWFufSBuZXdWYWwg6Kem5Y+R57uE5Lu26L+b5YWl5oiW56a75byA6L+H5rih55qE54q25oCBXG4gICAgICAgICAqL1xuICAgICAgICB1cGRhdGVkKG5ld1ZhbCkge1xuICAgICAgICAgICAgbGV0IHsgYW5pbWF0ZVN0YXR1cyB9ID0gdGhpcy5wZW5kaW5nRGF0YSB8fCB0aGlzLmRhdGFcbiAgICAgICAgICAgIGxldCBuZXh0U3RhdHVzID0gbnVsbFxuXG4gICAgICAgICAgICBpZiAobmV3VmFsKSB7XG4gICAgICAgICAgICAgICAgaWYgKGFuaW1hdGVTdGF0dXMgPT09IFVOTU9VTlRFRCkge1xuICAgICAgICAgICAgICAgICAgICBhbmltYXRlU3RhdHVzID0gRVhJVEVEXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7IGFuaW1hdGVTdGF0dXM6IEVYSVRFRCB9LCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2hhbmdlJywgeyBhbmltYXRlU3RhdHVzOiBFWElURUQgfSlcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGFuaW1hdGVTdGF0dXMgIT09IEVOVEVSICYmIGFuaW1hdGVTdGF0dXMgIT09IEVOVEVSSU5HICYmIGFuaW1hdGVTdGF0dXMgIT09IEVOVEVSRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dFN0YXR1cyA9IEVOVEVSSU5HXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoYW5pbWF0ZVN0YXR1cyA9PT0gRU5URVIgfHwgYW5pbWF0ZVN0YXR1cyA9PT0gRU5URVJJTkcgfHwgYW5pbWF0ZVN0YXR1cyA9PT0gRU5URVJFRCkge1xuICAgICAgICAgICAgICAgICAgICBuZXh0U3RhdHVzID0gRVhJVElOR1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy51cGRhdGVTdGF0dXMobmV4dFN0YXR1cylcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOW7tui/n+S4gOauteaXtumXtOinpuWPkeWbnuiwg1xuICAgICAgICAgKiBAcGFyYW0ge051bWJlcn0gdGltZW91dCDlu7bov5/ml7bpl7RcbiAgICAgICAgICogQHBhcmFtIHtGdW5jdGlvbn0gaGFuZGxlciDlm57osIPlh73mlbBcbiAgICAgICAgICovXG4gICAgICAgIGRlbGF5SGFuZGxlcih0aW1lb3V0LCBoYW5kbGVyKSB7XG4gICAgICAgICAgICBpZiAodGltZW91dCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0TmV4dENhbGxiYWNrKGhhbmRsZXIpXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCh0aGlzLm5leHRDYWxsYmFjaywgdGltZW91dClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOeCueWHu+S6i+S7tlxuICAgICAgICAgKi9cbiAgICAgICAgb25UYXAoKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2xpY2snKVxuICAgICAgICB9LFxuICAgIH0sXG4gICAgYXR0YWNoZWQoKSB7XG4gICAgICAgIGxldCBhbmltYXRlU3RhdHVzID0gbnVsbFxuICAgICAgICBsZXQgYXBwZWFyU3RhdHVzID0gbnVsbFxuXG4gICAgICAgIGlmICh0aGlzLmRhdGEuaW4pIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmRhdGEuYXBwZWFyKSB7XG4gICAgICAgICAgICAgICAgYW5pbWF0ZVN0YXR1cyA9IEVYSVRFRFxuICAgICAgICAgICAgICAgIGFwcGVhclN0YXR1cyA9IEVOVEVSSU5HXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGFuaW1hdGVTdGF0dXMgPSBFTlRFUkVEXG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhLnVubW91bnRPbkV4aXQgfHwgdGhpcy5kYXRhLm1vdW50T25FbnRlcikge1xuICAgICAgICAgICAgICAgIGFuaW1hdGVTdGF0dXMgPSBVTk1PVU5URURcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgYW5pbWF0ZVN0YXR1cyA9IEVYSVRFRFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8g55Sx5LqO5bCP56iL5bqP57uE5Lu26aaW5qyh5oyC6L295pe2IG9ic2VydmVyIOS6i+S7tuaAu+aYr+S8mOWFiOS6jiBhdHRhY2hlZCDkuovku7ZcbiAgICAgICAgLy8g5omA5Lul5L2/55SoIGlzTW91bnRpbmcg5p2l5by65Yi25LyY5YWI6Kem5Y+RIGF0dGFjaGVkIOS6i+S7tlxuICAgICAgICB0aGlzLnNhZmVTZXREYXRhKHsgYW5pbWF0ZVN0YXR1cywgaXNNb3VudGluZzogdHJ1ZSB9LCAoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2hhbmdlJywgeyBhbmltYXRlU3RhdHVzIH0pXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN0YXR1cyhhcHBlYXJTdGF0dXMsIHRydWUpXG4gICAgICAgIH0pXG4gICAgfSxcbn0pXG4iXX0=