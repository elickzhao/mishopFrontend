"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Countdown = function () {
    function Countdown() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var page = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : getCurrentPages()[getCurrentPages().length - 1];

        _classCallCheck(this, Countdown);

        Object.assign(this, {
            page: page,
            options: options
        });
        this.__init();
    }

    /**
     * 初始化
     */


    _createClass(Countdown, [{
        key: "__init",
        value: function __init() {
            this.setData = this.page.setData.bind(this.page);
            this.restart(this.options);
        }

        /**
         * 默认参数
         */

    }, {
        key: "setDefaults",
        value: function setDefaults() {
            return {
                date: "June 7, 2087 15:03:25",
                refresh: 1000,
                offset: 0,
                onEnd: function onEnd() {},
                render: function render(date) {}
            };
        }

        /**
         * 合并参数
         */

    }, {
        key: "mergeOptions",
        value: function mergeOptions(options) {
            var defaultOptions = this.setDefaults();

            for (var i in defaultOptions) {
                if (defaultOptions.hasOwnProperty(i)) {
                    this.options[i] = typeof options[i] !== "undefined" ? options[i] : defaultOptions[i];

                    if (i === "date" && typeof this.options.date !== "object") {
                        this.options.date = new Date(this.options.date);
                    }

                    if (typeof this.options[i] === "function") {
                        this.options[i] = this.options[i].bind(this);
                    }
                }
            }

            if (typeof this.options.date !== "object") {
                this.options.date = new Date(this.options.date);
            }
        }

        /**
         * 计算日期差
         */

    }, {
        key: "getDiffDate",
        value: function getDiffDate() {
            var diff = (this.options.date.getTime() - Date.now() + this.options.offset) / 1000;

            var dateData = {
                years: 0,
                days: 0,
                hours: 0,
                min: 0,
                sec: 0,
                millisec: 0
            };

            if (diff <= 0) {
                if (this.interval) {
                    this.stop();
                    this.options.onEnd();
                }
                return dateData;
            }

            if (diff >= 365.25 * 86400) {
                dateData.years = Math.floor(diff / (365.25 * 86400));
                diff -= dateData.years * 365.25 * 86400;
            }

            if (diff >= 86400) {
                dateData.days = Math.floor(diff / 86400);
                diff -= dateData.days * 86400;
            }

            if (diff >= 3600) {
                dateData.hours = Math.floor(diff / 3600);
                diff -= dateData.hours * 3600;
            }

            if (diff >= 60) {
                dateData.min = Math.floor(diff / 60);
                diff -= dateData.min * 60;
            }

            dateData.sec = Math.round(diff);

            dateData.millisec = diff % 1 * 1000;

            return dateData;
        }

        /**
         * 补零
         */

    }, {
        key: "leadingZeros",
        value: function leadingZeros(num) {
            var length = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

            num = String(num);
            if (num.length > length) return num;
            return (Array(length + 1).join("0") + num).substr(-length);
        }

        /**
         * 更新组件
         */

    }, {
        key: "update",
        value: function update(newDate) {
            this.options.date = typeof newDate !== "object" ? new Date(newDate) : newDate;
            this.render();
            return this;
        }

        /**
         * 停止倒计时
         */

    }, {
        key: "stop",
        value: function stop() {
            if (this.interval) {
                clearInterval(this.interval);
                this.interval = !1;
            }
            return this;
        }

        /**
         * 渲染组件
         */

    }, {
        key: "render",
        value: function render() {
            this.options.render(this.getDiffDate());
            return this;
        }

        /**
         * 启动倒计时
         */

    }, {
        key: "start",
        value: function start() {
            var _this = this;

            if (this.interval) return !1;
            this.render();
            if (this.options.refresh) {
                this.interval = setInterval(function () {
                    _this.render();
                }, this.options.refresh);
            }
            return this;
        }

        /**
         * 更新offset
         */

    }, {
        key: "updateOffset",
        value: function updateOffset(offset) {
            this.options.offset = offset;
            return this;
        }

        /**
         * 重启倒计时
         */

    }, {
        key: "restart",
        value: function restart() {
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            this.mergeOptions(options);
            this.interval = !1;
            this.start();
            return this;
        }
    }]);

    return Countdown;
}();

exports.default = Countdown;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkNvdW50ZG93biIsIm9wdGlvbnMiLCJwYWdlIiwiZ2V0Q3VycmVudFBhZ2VzIiwibGVuZ3RoIiwiT2JqZWN0IiwiYXNzaWduIiwiX19pbml0Iiwic2V0RGF0YSIsImJpbmQiLCJyZXN0YXJ0IiwiZGF0ZSIsInJlZnJlc2giLCJvZmZzZXQiLCJvbkVuZCIsInJlbmRlciIsImRlZmF1bHRPcHRpb25zIiwic2V0RGVmYXVsdHMiLCJpIiwiaGFzT3duUHJvcGVydHkiLCJEYXRlIiwiZGlmZiIsImdldFRpbWUiLCJub3ciLCJkYXRlRGF0YSIsInllYXJzIiwiZGF5cyIsImhvdXJzIiwibWluIiwic2VjIiwibWlsbGlzZWMiLCJpbnRlcnZhbCIsInN0b3AiLCJNYXRoIiwiZmxvb3IiLCJyb3VuZCIsIm51bSIsIlN0cmluZyIsIkFycmF5Iiwiam9pbiIsInN1YnN0ciIsIm5ld0RhdGUiLCJjbGVhckludGVydmFsIiwiZ2V0RGlmZkRhdGUiLCJzZXRJbnRlcnZhbCIsIm1lcmdlT3B0aW9ucyIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0lBQU1BLFM7QUFDRix5QkFBa0Y7QUFBQSxZQUF0RUMsT0FBc0UsdUVBQTVELEVBQTREO0FBQUEsWUFBeERDLElBQXdELHVFQUFqREMsa0JBQWtCQSxrQkFBa0JDLE1BQWxCLEdBQTJCLENBQTdDLENBQWlEOztBQUFBOztBQUM5RUMsZUFBT0MsTUFBUCxDQUFjLElBQWQsRUFBb0I7QUFDaEJKLHNCQURnQjtBQUVoQkQ7QUFGZ0IsU0FBcEI7QUFJQSxhQUFLTSxNQUFMO0FBQ0g7O0FBRUQ7Ozs7Ozs7aUNBR1M7QUFDTCxpQkFBS0MsT0FBTCxHQUFlLEtBQUtOLElBQUwsQ0FBVU0sT0FBVixDQUFrQkMsSUFBbEIsQ0FBdUIsS0FBS1AsSUFBNUIsQ0FBZjtBQUNBLGlCQUFLUSxPQUFMLENBQWEsS0FBS1QsT0FBbEI7QUFDSDs7QUFFRDs7Ozs7O3NDQUdjO0FBQ1YsbUJBQU87QUFDSFUsNkNBREc7QUFFSEMseUJBQVMsSUFGTjtBQUdIQyx3QkFBUSxDQUhMO0FBSUhDLHFCQUpHLG1CQUlLLENBQUUsQ0FKUDtBQUtIQyxzQkFMRyxrQkFLSUosSUFMSixFQUtVLENBQUU7QUFMWixhQUFQO0FBT0g7O0FBRUQ7Ozs7OztxQ0FHYVYsTyxFQUFTO0FBQ2xCLGdCQUFNZSxpQkFBaUIsS0FBS0MsV0FBTCxFQUF2Qjs7QUFFQSxpQkFBSyxJQUFJQyxDQUFULElBQWNGLGNBQWQsRUFBOEI7QUFDMUIsb0JBQUlBLGVBQWVHLGNBQWYsQ0FBOEJELENBQTlCLENBQUosRUFBc0M7QUFDbEMseUJBQUtqQixPQUFMLENBQWFpQixDQUFiLElBQWtCLE9BQU9qQixRQUFRaUIsQ0FBUixDQUFQLG1CQUFvQ2pCLFFBQVFpQixDQUFSLENBQXBDLEdBQWlERixlQUFlRSxDQUFmLENBQW5FOztBQUVBLHdCQUFJQSxnQkFBZ0IsT0FBTyxLQUFLakIsT0FBTCxDQUFhVSxJQUFwQixhQUFwQixFQUEyRDtBQUN2RCw2QkFBS1YsT0FBTCxDQUFhVSxJQUFiLEdBQW9CLElBQUlTLElBQUosQ0FBUyxLQUFLbkIsT0FBTCxDQUFhVSxJQUF0QixDQUFwQjtBQUNIOztBQUVELHdCQUFJLE9BQU8sS0FBS1YsT0FBTCxDQUFhaUIsQ0FBYixDQUFQLGVBQUosRUFBMkM7QUFDdkMsNkJBQUtqQixPQUFMLENBQWFpQixDQUFiLElBQWtCLEtBQUtqQixPQUFMLENBQWFpQixDQUFiLEVBQWdCVCxJQUFoQixDQUFxQixJQUFyQixDQUFsQjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxnQkFBSSxPQUFPLEtBQUtSLE9BQUwsQ0FBYVUsSUFBcEIsYUFBSixFQUEyQztBQUN2QyxxQkFBS1YsT0FBTCxDQUFhVSxJQUFiLEdBQW9CLElBQUlTLElBQUosQ0FBUyxLQUFLbkIsT0FBTCxDQUFhVSxJQUF0QixDQUFwQjtBQUNIO0FBQ0o7O0FBRUQ7Ozs7OztzQ0FHYztBQUNWLGdCQUFJVSxPQUFPLENBQUMsS0FBS3BCLE9BQUwsQ0FBYVUsSUFBYixDQUFrQlcsT0FBbEIsS0FBOEJGLEtBQUtHLEdBQUwsRUFBOUIsR0FBMkMsS0FBS3RCLE9BQUwsQ0FBYVksTUFBekQsSUFBbUUsSUFBOUU7O0FBRUEsZ0JBQUlXLFdBQVc7QUFDWEMsdUJBQU8sQ0FESTtBQUVYQyxzQkFBTSxDQUZLO0FBR1hDLHVCQUFPLENBSEk7QUFJWEMscUJBQUssQ0FKTTtBQUtYQyxxQkFBSyxDQUxNO0FBTVhDLDBCQUFVO0FBTkMsYUFBZjs7QUFTQSxnQkFBSVQsUUFBUSxDQUFaLEVBQWU7QUFDWCxvQkFBSSxLQUFLVSxRQUFULEVBQW1CO0FBQ2YseUJBQUtDLElBQUw7QUFDQSx5QkFBSy9CLE9BQUwsQ0FBYWEsS0FBYjtBQUNIO0FBQ0QsdUJBQU9VLFFBQVA7QUFDSDs7QUFFRCxnQkFBSUgsUUFBUyxTQUFTLEtBQXRCLEVBQThCO0FBQzFCRyx5QkFBU0MsS0FBVCxHQUFpQlEsS0FBS0MsS0FBTCxDQUFXYixRQUFRLFNBQVMsS0FBakIsQ0FBWCxDQUFqQjtBQUNBQSx3QkFBUUcsU0FBU0MsS0FBVCxHQUFpQixNQUFqQixHQUEwQixLQUFsQztBQUNIOztBQUVELGdCQUFJSixRQUFRLEtBQVosRUFBbUI7QUFDZkcseUJBQVNFLElBQVQsR0FBZ0JPLEtBQUtDLEtBQUwsQ0FBV2IsT0FBTyxLQUFsQixDQUFoQjtBQUNBQSx3QkFBUUcsU0FBU0UsSUFBVCxHQUFnQixLQUF4QjtBQUNIOztBQUVELGdCQUFJTCxRQUFRLElBQVosRUFBa0I7QUFDZEcseUJBQVNHLEtBQVQsR0FBaUJNLEtBQUtDLEtBQUwsQ0FBV2IsT0FBTyxJQUFsQixDQUFqQjtBQUNBQSx3QkFBUUcsU0FBU0csS0FBVCxHQUFpQixJQUF6QjtBQUNIOztBQUVELGdCQUFJTixRQUFRLEVBQVosRUFBZ0I7QUFDWkcseUJBQVNJLEdBQVQsR0FBZUssS0FBS0MsS0FBTCxDQUFXYixPQUFPLEVBQWxCLENBQWY7QUFDQUEsd0JBQVFHLFNBQVNJLEdBQVQsR0FBZSxFQUF2QjtBQUNIOztBQUVESixxQkFBU0ssR0FBVCxHQUFlSSxLQUFLRSxLQUFMLENBQVdkLElBQVgsQ0FBZjs7QUFFQUcscUJBQVNNLFFBQVQsR0FBb0JULE9BQU8sQ0FBUCxHQUFXLElBQS9COztBQUVBLG1CQUFPRyxRQUFQO0FBQ0g7O0FBRUQ7Ozs7OztxQ0FHYVksRyxFQUFpQjtBQUFBLGdCQUFaaEMsTUFBWSx1RUFBSCxDQUFHOztBQUMxQmdDLGtCQUFNQyxPQUFPRCxHQUFQLENBQU47QUFDQSxnQkFBSUEsSUFBSWhDLE1BQUosR0FBYUEsTUFBakIsRUFBeUIsT0FBT2dDLEdBQVA7QUFDekIsbUJBQU8sQ0FBQ0UsTUFBTWxDLFNBQVMsQ0FBZixFQUFrQm1DLElBQWxCLFFBQThCSCxHQUEvQixFQUFvQ0ksTUFBcEMsQ0FBMkMsQ0FBQ3BDLE1BQTVDLENBQVA7QUFDSDs7QUFFRDs7Ozs7OytCQUdPcUMsTyxFQUFTO0FBQ1osaUJBQUt4QyxPQUFMLENBQWFVLElBQWIsR0FBb0IsT0FBTzhCLE9BQVAsZ0JBQThCLElBQUlyQixJQUFKLENBQVNxQixPQUFULENBQTlCLEdBQWtEQSxPQUF0RTtBQUNBLGlCQUFLMUIsTUFBTDtBQUNBLG1CQUFPLElBQVA7QUFDSDs7QUFFRDs7Ozs7OytCQUdPO0FBQ0gsZ0JBQUksS0FBS2dCLFFBQVQsRUFBbUI7QUFDZlcsOEJBQWMsS0FBS1gsUUFBbkI7QUFDQSxxQkFBS0EsUUFBTCxHQUFnQixDQUFDLENBQWpCO0FBQ0g7QUFDRCxtQkFBTyxJQUFQO0FBQ0g7O0FBRUQ7Ozs7OztpQ0FHUztBQUNMLGlCQUFLOUIsT0FBTCxDQUFhYyxNQUFiLENBQW9CLEtBQUs0QixXQUFMLEVBQXBCO0FBQ0EsbUJBQU8sSUFBUDtBQUNIOztBQUVEOzs7Ozs7Z0NBR1E7QUFBQTs7QUFDSixnQkFBSSxLQUFLWixRQUFULEVBQW1CLE9BQU8sQ0FBQyxDQUFSO0FBQ25CLGlCQUFLaEIsTUFBTDtBQUNBLGdCQUFJLEtBQUtkLE9BQUwsQ0FBYVcsT0FBakIsRUFBMEI7QUFDdEIscUJBQUttQixRQUFMLEdBQWdCYSxZQUFZLFlBQU07QUFDOUIsMEJBQUs3QixNQUFMO0FBQ0gsaUJBRmUsRUFFYixLQUFLZCxPQUFMLENBQWFXLE9BRkEsQ0FBaEI7QUFHSDtBQUNELG1CQUFPLElBQVA7QUFDSDs7QUFFRDs7Ozs7O3FDQUdhQyxNLEVBQVE7QUFDakIsaUJBQUtaLE9BQUwsQ0FBYVksTUFBYixHQUFzQkEsTUFBdEI7QUFDQSxtQkFBTyxJQUFQO0FBQ0g7O0FBRUQ7Ozs7OztrQ0FHc0I7QUFBQSxnQkFBZFosT0FBYyx1RUFBSixFQUFJOztBQUNsQixpQkFBSzRDLFlBQUwsQ0FBa0I1QyxPQUFsQjtBQUNBLGlCQUFLOEIsUUFBTCxHQUFnQixDQUFDLENBQWpCO0FBQ0EsaUJBQUtlLEtBQUw7QUFDQSxtQkFBTyxJQUFQO0FBQ0g7Ozs7OztrQkFHVTlDLFMiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBDb3VudGRvd24ge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSwgcGFnZSA9IGdldEN1cnJlbnRQYWdlcygpW2dldEN1cnJlbnRQYWdlcygpLmxlbmd0aCAtIDFdKSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywge1xuICAgICAgICAgICAgcGFnZSxcbiAgICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgIH0pXG4gICAgICAgIHRoaXMuX19pbml0KClcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDliJ3lp4vljJZcbiAgICAgKi9cbiAgICBfX2luaXQoKSB7XG4gICAgICAgIHRoaXMuc2V0RGF0YSA9IHRoaXMucGFnZS5zZXREYXRhLmJpbmQodGhpcy5wYWdlKVxuICAgICAgICB0aGlzLnJlc3RhcnQodGhpcy5vcHRpb25zKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOm7mOiupOWPguaVsFxuICAgICAqL1xuICAgIHNldERlZmF1bHRzKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZGF0ZTogYEp1bmUgNywgMjA4NyAxNTowMzoyNWAsXG4gICAgICAgICAgICByZWZyZXNoOiAxMDAwLFxuICAgICAgICAgICAgb2Zmc2V0OiAwLFxuICAgICAgICAgICAgb25FbmQoKSB7fSxcbiAgICAgICAgICAgIHJlbmRlcihkYXRlKSB7fSxcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOWQiOW5tuWPguaVsFxuICAgICAqL1xuICAgIG1lcmdlT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gdGhpcy5zZXREZWZhdWx0cygpXG5cbiAgICAgICAgZm9yIChsZXQgaSBpbiBkZWZhdWx0T3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKGRlZmF1bHRPcHRpb25zLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zW2ldID0gdHlwZW9mIG9wdGlvbnNbaV0gIT09IGB1bmRlZmluZWRgID8gb3B0aW9uc1tpXSA6IGRlZmF1bHRPcHRpb25zW2ldXG5cbiAgICAgICAgICAgICAgICBpZiAoaSA9PT0gYGRhdGVgICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZGF0ZSAhPT0gYG9iamVjdGApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zLmRhdGUgPSBuZXcgRGF0ZSh0aGlzLm9wdGlvbnMuZGF0ZSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMub3B0aW9uc1tpXSA9PT0gYGZ1bmN0aW9uYCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnNbaV0gPSB0aGlzLm9wdGlvbnNbaV0uYmluZCh0aGlzKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLmRhdGUgIT09IGBvYmplY3RgKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMuZGF0ZSA9IG5ldyBEYXRlKHRoaXMub3B0aW9ucy5kYXRlKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog6K6h566X5pel5pyf5beuXG4gICAgICovXG4gICAgZ2V0RGlmZkRhdGUoKSB7XG4gICAgICAgIGxldCBkaWZmID0gKHRoaXMub3B0aW9ucy5kYXRlLmdldFRpbWUoKSAtIERhdGUubm93KCkgKyB0aGlzLm9wdGlvbnMub2Zmc2V0KSAvIDEwMDBcblxuICAgICAgICBsZXQgZGF0ZURhdGEgPSB7XG4gICAgICAgICAgICB5ZWFyczogMCxcbiAgICAgICAgICAgIGRheXM6IDAsXG4gICAgICAgICAgICBob3VyczogMCxcbiAgICAgICAgICAgIG1pbjogMCxcbiAgICAgICAgICAgIHNlYzogMCxcbiAgICAgICAgICAgIG1pbGxpc2VjOiAwLFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRpZmYgPD0gMCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaW50ZXJ2YWwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnN0b3AoKVxuICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy5vbkVuZCgpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZGF0ZURhdGFcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChkaWZmID49ICgzNjUuMjUgKiA4NjQwMCkpIHtcbiAgICAgICAgICAgIGRhdGVEYXRhLnllYXJzID0gTWF0aC5mbG9vcihkaWZmIC8gKDM2NS4yNSAqIDg2NDAwKSlcbiAgICAgICAgICAgIGRpZmYgLT0gZGF0ZURhdGEueWVhcnMgKiAzNjUuMjUgKiA4NjQwMFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRpZmYgPj0gODY0MDApIHtcbiAgICAgICAgICAgIGRhdGVEYXRhLmRheXMgPSBNYXRoLmZsb29yKGRpZmYgLyA4NjQwMClcbiAgICAgICAgICAgIGRpZmYgLT0gZGF0ZURhdGEuZGF5cyAqIDg2NDAwXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZGlmZiA+PSAzNjAwKSB7XG4gICAgICAgICAgICBkYXRlRGF0YS5ob3VycyA9IE1hdGguZmxvb3IoZGlmZiAvIDM2MDApXG4gICAgICAgICAgICBkaWZmIC09IGRhdGVEYXRhLmhvdXJzICogMzYwMFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRpZmYgPj0gNjApIHtcbiAgICAgICAgICAgIGRhdGVEYXRhLm1pbiA9IE1hdGguZmxvb3IoZGlmZiAvIDYwKVxuICAgICAgICAgICAgZGlmZiAtPSBkYXRlRGF0YS5taW4gKiA2MFxuICAgICAgICB9XG5cbiAgICAgICAgZGF0ZURhdGEuc2VjID0gTWF0aC5yb3VuZChkaWZmKVxuXG4gICAgICAgIGRhdGVEYXRhLm1pbGxpc2VjID0gZGlmZiAlIDEgKiAxMDAwXG5cbiAgICAgICAgcmV0dXJuIGRhdGVEYXRhXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog6KGl6Zu2XG4gICAgICovXG4gICAgbGVhZGluZ1plcm9zKG51bSwgbGVuZ3RoID0gMikge1xuICAgICAgICBudW0gPSBTdHJpbmcobnVtKVxuICAgICAgICBpZiAobnVtLmxlbmd0aCA+IGxlbmd0aCkgcmV0dXJuIG51bVxuICAgICAgICByZXR1cm4gKEFycmF5KGxlbmd0aCArIDEpLmpvaW4oYDBgKSArIG51bSkuc3Vic3RyKC1sZW5ndGgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5pu05paw57uE5Lu2XG4gICAgICovXG4gICAgdXBkYXRlKG5ld0RhdGUpIHtcbiAgICAgICAgdGhpcy5vcHRpb25zLmRhdGUgPSB0eXBlb2YgbmV3RGF0ZSAhPT0gYG9iamVjdGAgPyBuZXcgRGF0ZShuZXdEYXRlKSA6IG5ld0RhdGVcbiAgICAgICAgdGhpcy5yZW5kZXIoKVxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOWBnOatouWAkuiuoeaXtlxuICAgICAqL1xuICAgIHN0b3AoKSB7XG4gICAgICAgIGlmICh0aGlzLmludGVydmFsKSB7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWwpXG4gICAgICAgICAgICB0aGlzLmludGVydmFsID0gITFcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIOa4suafk+e7hOS7tlxuICAgICAqL1xuICAgIHJlbmRlcigpIHtcbiAgICAgICAgdGhpcy5vcHRpb25zLnJlbmRlcih0aGlzLmdldERpZmZEYXRlKCkpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICog5ZCv5Yqo5YCS6K6h5pe2XG4gICAgICovXG4gICAgc3RhcnQoKSB7XG4gICAgICAgIGlmICh0aGlzLmludGVydmFsKSByZXR1cm4gITFcbiAgICAgICAgdGhpcy5yZW5kZXIoKVxuICAgICAgICBpZiAodGhpcy5vcHRpb25zLnJlZnJlc2gpIHtcbiAgICAgICAgICAgIHRoaXMuaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW5kZXIoKVxuICAgICAgICAgICAgfSwgdGhpcy5vcHRpb25zLnJlZnJlc2gpXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDmm7TmlrBvZmZzZXRcbiAgICAgKi9cbiAgICB1cGRhdGVPZmZzZXQob2Zmc2V0KSB7XG4gICAgICAgIHRoaXMub3B0aW9ucy5vZmZzZXQgPSBvZmZzZXRcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiDph43lkK/lgJLorqHml7ZcbiAgICAgKi9cbiAgICByZXN0YXJ0KG9wdGlvbnMgPSB7fSkge1xuICAgICAgICB0aGlzLm1lcmdlT3B0aW9ucyhvcHRpb25zKVxuICAgICAgICB0aGlzLmludGVydmFsID0gITFcbiAgICAgICAgdGhpcy5zdGFydCgpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDb3VudGRvd24iXX0=