'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames2 = require('./../helpers/classNames.js');

var _classNames3 = _interopRequireDefault(_classNames2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _baseComponent2.default)({
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-button'
        },
        type: {
            type: String,
            value: 'stable'
        },
        clear: {
            type: Boolean,
            value: false
        },
        block: {
            type: Boolean,
            value: false
        },
        full: {
            type: Boolean,
            value: false
        },
        outline: {
            type: Boolean,
            value: false
        },
        bordered: {
            type: Boolean,
            value: true
        },
        size: {
            type: String,
            value: 'default'
        },
        disabled: {
            type: Boolean,
            value: false
        },
        loading: {
            type: Boolean,
            value: false
        },
        formType: {
            type: String,
            value: ''
        },
        openType: {
            type: String,
            value: ''
        },
        hoverClass: {
            type: String,
            value: 'default'
        },
        hoverStopPropagation: {
            type: Boolean,
            value: false
        },
        hoverStartTime: {
            type: Number,
            value: 20
        },
        hoverStayTime: {
            type: Number,
            value: 70
        },
        lang: {
            type: String,
            value: 'en'
        },
        sessionFrom: {
            type: String,
            value: ''
        },
        sendMessageTitle: {
            type: String,
            value: ''
        },
        sendMessagePath: {
            type: String,
            value: ''
        },
        sendMessageImg: {
            type: String,
            value: ''
        },
        showMessageCard: {
            type: Boolean,
            value: false
        },
        appParameter: {
            type: String,
            value: ''
        }
    },
    computed: {
        classes: function classes() {
            var _classNames;

            var _data = this.data,
                prefixCls = _data.prefixCls,
                hoverClass = _data.hoverClass,
                type = _data.type,
                size = _data.size,
                block = _data.block,
                full = _data.full,
                clear = _data.clear,
                outline = _data.outline,
                bordered = _data.bordered,
                disabled = _data.disabled;

            var wrap = (0, _classNames3.default)(prefixCls, (_classNames = {}, _defineProperty(_classNames, prefixCls + '--' + type, type), _defineProperty(_classNames, prefixCls + '--' + size, size), _defineProperty(_classNames, prefixCls + '--block', block), _defineProperty(_classNames, prefixCls + '--full', full), _defineProperty(_classNames, prefixCls + '--clear', clear), _defineProperty(_classNames, prefixCls + '--outline', outline), _defineProperty(_classNames, prefixCls + '--bordered', bordered), _defineProperty(_classNames, prefixCls + '--disabled', disabled), _classNames));
            var hover = hoverClass && hoverClass !== 'default' ? hoverClass : prefixCls + '--hover';

            return {
                wrap: wrap,
                hover: hover
            };
        }
    },
    methods: {
        onTap: function onTap() {
            if (!this.data.disabled && !this.data.loading) {
                this.triggerEvent('click');
            }
        },
        bindgetuserinfo: function bindgetuserinfo(e) {
            this.triggerEvent('getuserinfo', e.detail);
        },
        bindcontact: function bindcontact(e) {
            this.triggerEvent('contact', e.detail);
        },
        bindgetphonenumber: function bindgetphonenumber(e) {
            this.triggerEvent('getphonenumber', e.detail);
        },
        bindopensetting: function bindopensetting(e) {
            this.triggerEvent('opensetting', e.detail);
        },
        onError: function onError(e) {
            this.triggerEvent('error', e.detail);
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbInByb3BlcnRpZXMiLCJwcmVmaXhDbHMiLCJ0eXBlIiwiU3RyaW5nIiwidmFsdWUiLCJjbGVhciIsIkJvb2xlYW4iLCJibG9jayIsImZ1bGwiLCJvdXRsaW5lIiwiYm9yZGVyZWQiLCJzaXplIiwiZGlzYWJsZWQiLCJsb2FkaW5nIiwiZm9ybVR5cGUiLCJvcGVuVHlwZSIsImhvdmVyQ2xhc3MiLCJob3ZlclN0b3BQcm9wYWdhdGlvbiIsImhvdmVyU3RhcnRUaW1lIiwiTnVtYmVyIiwiaG92ZXJTdGF5VGltZSIsImxhbmciLCJzZXNzaW9uRnJvbSIsInNlbmRNZXNzYWdlVGl0bGUiLCJzZW5kTWVzc2FnZVBhdGgiLCJzZW5kTWVzc2FnZUltZyIsInNob3dNZXNzYWdlQ2FyZCIsImFwcFBhcmFtZXRlciIsImNvbXB1dGVkIiwiY2xhc3NlcyIsImRhdGEiLCJ3cmFwIiwiaG92ZXIiLCJtZXRob2RzIiwib25UYXAiLCJ0cmlnZ2VyRXZlbnQiLCJiaW5kZ2V0dXNlcmluZm8iLCJlIiwiZGV0YWlsIiwiYmluZGNvbnRhY3QiLCJiaW5kZ2V0cGhvbmVudW1iZXIiLCJiaW5kb3BlbnNldHRpbmciLCJvbkVycm9yIl0sIm1hcHBpbmdzIjoiOztBQUFBOzs7O0FBQ0E7Ozs7Ozs7O0FBRUEsNkJBQWM7QUFDVkEsZ0JBQVk7QUFDUkMsbUJBQVc7QUFDUEMsa0JBQU1DLE1BREM7QUFFUEMsbUJBQU87QUFGQSxTQURIO0FBS1JGLGNBQU07QUFDRkEsa0JBQU1DLE1BREo7QUFFRkMsbUJBQU87QUFGTCxTQUxFO0FBU1JDLGVBQU87QUFDSEgsa0JBQU1JLE9BREg7QUFFSEYsbUJBQU87QUFGSixTQVRDO0FBYVJHLGVBQU87QUFDSEwsa0JBQU1JLE9BREg7QUFFSEYsbUJBQU87QUFGSixTQWJDO0FBaUJSSSxjQUFNO0FBQ0ZOLGtCQUFNSSxPQURKO0FBRUZGLG1CQUFPO0FBRkwsU0FqQkU7QUFxQlJLLGlCQUFTO0FBQ0xQLGtCQUFNSSxPQUREO0FBRUxGLG1CQUFPO0FBRkYsU0FyQkQ7QUF5QlJNLGtCQUFVO0FBQ05SLGtCQUFNSSxPQURBO0FBRU5GLG1CQUFPO0FBRkQsU0F6QkY7QUE2QlJPLGNBQU07QUFDRlQsa0JBQU1DLE1BREo7QUFFRkMsbUJBQU87QUFGTCxTQTdCRTtBQWlDUlEsa0JBQVU7QUFDTlYsa0JBQU1JLE9BREE7QUFFTkYsbUJBQU87QUFGRCxTQWpDRjtBQXFDUlMsaUJBQVM7QUFDTFgsa0JBQU1JLE9BREQ7QUFFTEYsbUJBQU87QUFGRixTQXJDRDtBQXlDUlUsa0JBQVU7QUFDTlosa0JBQU1DLE1BREE7QUFFTkMsbUJBQU87QUFGRCxTQXpDRjtBQTZDUlcsa0JBQVU7QUFDTmIsa0JBQU1DLE1BREE7QUFFTkMsbUJBQU87QUFGRCxTQTdDRjtBQWlEUlksb0JBQVk7QUFDUmQsa0JBQU1DLE1BREU7QUFFUkMsbUJBQU87QUFGQyxTQWpESjtBQXFEUmEsOEJBQXNCO0FBQ2xCZixrQkFBTUksT0FEWTtBQUVsQkYsbUJBQU87QUFGVyxTQXJEZDtBQXlEUmMsd0JBQWdCO0FBQ1poQixrQkFBTWlCLE1BRE07QUFFWmYsbUJBQU87QUFGSyxTQXpEUjtBQTZEUmdCLHVCQUFlO0FBQ1hsQixrQkFBTWlCLE1BREs7QUFFWGYsbUJBQU87QUFGSSxTQTdEUDtBQWlFUmlCLGNBQU07QUFDRm5CLGtCQUFNQyxNQURKO0FBRUZDLG1CQUFPO0FBRkwsU0FqRUU7QUFxRVJrQixxQkFBYTtBQUNUcEIsa0JBQU1DLE1BREc7QUFFVEMsbUJBQU87QUFGRSxTQXJFTDtBQXlFUm1CLDBCQUFrQjtBQUNkckIsa0JBQU1DLE1BRFE7QUFFZEMsbUJBQU87QUFGTyxTQXpFVjtBQTZFUm9CLHlCQUFpQjtBQUNidEIsa0JBQU1DLE1BRE87QUFFYkMsbUJBQU87QUFGTSxTQTdFVDtBQWlGUnFCLHdCQUFnQjtBQUNadkIsa0JBQU1DLE1BRE07QUFFWkMsbUJBQU87QUFGSyxTQWpGUjtBQXFGUnNCLHlCQUFpQjtBQUNieEIsa0JBQU1JLE9BRE87QUFFYkYsbUJBQU87QUFGTSxTQXJGVDtBQXlGUnVCLHNCQUFjO0FBQ1Z6QixrQkFBTUMsTUFESTtBQUVWQyxtQkFBTztBQUZHO0FBekZOLEtBREY7QUErRlZ3QixjQUFVO0FBQ05DLGVBRE0scUJBQ0k7QUFBQTs7QUFBQSx3QkFDeUYsS0FBS0MsSUFEOUY7QUFBQSxnQkFDRTdCLFNBREYsU0FDRUEsU0FERjtBQUFBLGdCQUNhZSxVQURiLFNBQ2FBLFVBRGI7QUFBQSxnQkFDeUJkLElBRHpCLFNBQ3lCQSxJQUR6QjtBQUFBLGdCQUMrQlMsSUFEL0IsU0FDK0JBLElBRC9CO0FBQUEsZ0JBQ3FDSixLQURyQyxTQUNxQ0EsS0FEckM7QUFBQSxnQkFDNENDLElBRDVDLFNBQzRDQSxJQUQ1QztBQUFBLGdCQUNrREgsS0FEbEQsU0FDa0RBLEtBRGxEO0FBQUEsZ0JBQ3lESSxPQUR6RCxTQUN5REEsT0FEekQ7QUFBQSxnQkFDa0VDLFFBRGxFLFNBQ2tFQSxRQURsRTtBQUFBLGdCQUM0RUUsUUFENUUsU0FDNEVBLFFBRDVFOztBQUVOLGdCQUFNbUIsT0FBTywwQkFBVzlCLFNBQVgsa0RBQ0xBLFNBREssVUFDU0MsSUFEVCxFQUNrQkEsSUFEbEIsZ0NBRUxELFNBRkssVUFFU1UsSUFGVCxFQUVrQkEsSUFGbEIsZ0NBR0xWLFNBSEssY0FHZ0JNLEtBSGhCLGdDQUlMTixTQUpLLGFBSWVPLElBSmYsZ0NBS0xQLFNBTEssY0FLZ0JJLEtBTGhCLGdDQU1MSixTQU5LLGdCQU1rQlEsT0FObEIsZ0NBT0xSLFNBUEssaUJBT21CUyxRQVBuQixnQ0FRTFQsU0FSSyxpQkFRbUJXLFFBUm5CLGdCQUFiO0FBVUEsZ0JBQU1vQixRQUFRaEIsY0FBY0EsZUFBZSxTQUE3QixHQUF5Q0EsVUFBekMsR0FBeURmLFNBQXpELFlBQWQ7O0FBRUEsbUJBQU87QUFDSDhCLDBCQURHO0FBRUhDO0FBRkcsYUFBUDtBQUlIO0FBbkJLLEtBL0ZBO0FBb0hWQyxhQUFTO0FBQ0xDLGFBREssbUJBQ0c7QUFDSixnQkFBSSxDQUFDLEtBQUtKLElBQUwsQ0FBVWxCLFFBQVgsSUFBdUIsQ0FBQyxLQUFLa0IsSUFBTCxDQUFVakIsT0FBdEMsRUFBK0M7QUFDM0MscUJBQUtzQixZQUFMLENBQWtCLE9BQWxCO0FBQ0g7QUFDSixTQUxJO0FBTUxDLHVCQU5LLDJCQU1XQyxDQU5YLEVBTWM7QUFDZixpQkFBS0YsWUFBTCxDQUFrQixhQUFsQixFQUFpQ0UsRUFBRUMsTUFBbkM7QUFDSCxTQVJJO0FBU0xDLG1CQVRLLHVCQVNPRixDQVRQLEVBU1U7QUFDWCxpQkFBS0YsWUFBTCxDQUFrQixTQUFsQixFQUE2QkUsRUFBRUMsTUFBL0I7QUFDSCxTQVhJO0FBWUxFLDBCQVpLLDhCQVljSCxDQVpkLEVBWWlCO0FBQ2xCLGlCQUFLRixZQUFMLENBQWtCLGdCQUFsQixFQUFvQ0UsRUFBRUMsTUFBdEM7QUFDSCxTQWRJO0FBZUxHLHVCQWZLLDJCQWVXSixDQWZYLEVBZWM7QUFDZixpQkFBS0YsWUFBTCxDQUFrQixhQUFsQixFQUFpQ0UsRUFBRUMsTUFBbkM7QUFDSCxTQWpCSTtBQWtCTEksZUFsQkssbUJBa0JHTCxDQWxCSCxFQWtCTTtBQUNQLGlCQUFLRixZQUFMLENBQWtCLE9BQWxCLEVBQTJCRSxFQUFFQyxNQUE3QjtBQUNIO0FBcEJJO0FBcEhDLENBQWQiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmFzZUNvbXBvbmVudCBmcm9tICcuLi9oZWxwZXJzL2Jhc2VDb21wb25lbnQnXG5pbXBvcnQgY2xhc3NOYW1lcyBmcm9tICcuLi9oZWxwZXJzL2NsYXNzTmFtZXMnXG5cbmJhc2VDb21wb25lbnQoe1xuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcHJlZml4Q2xzOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ3d1eC1idXR0b24nLFxuICAgICAgICB9LFxuICAgICAgICB0eXBlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJ3N0YWJsZScsXG4gICAgICAgIH0sXG4gICAgICAgIGNsZWFyOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBibG9jazoge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgZnVsbDoge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgb3V0bGluZToge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgYm9yZGVyZWQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICdkZWZhdWx0JyxcbiAgICAgICAgfSxcbiAgICAgICAgZGlzYWJsZWQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGxvYWRpbmc6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGZvcm1UeXBlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIG9wZW5UeXBlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIGhvdmVyQ2xhc3M6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnZGVmYXVsdCcsXG4gICAgICAgIH0sXG4gICAgICAgIGhvdmVyU3RvcFByb3BhZ2F0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICAgICAgdmFsdWU6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBob3ZlclN0YXJ0VGltZToge1xuICAgICAgICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgICAgICAgdmFsdWU6IDIwLFxuICAgICAgICB9LFxuICAgICAgICBob3ZlclN0YXlUaW1lOiB7XG4gICAgICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgICAgICB2YWx1ZTogNzAsXG4gICAgICAgIH0sXG4gICAgICAgIGxhbmc6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnZW4nLFxuICAgICAgICB9LFxuICAgICAgICBzZXNzaW9uRnJvbToge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzZW5kTWVzc2FnZVRpdGxlOiB7XG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIH0sXG4gICAgICAgIHNlbmRNZXNzYWdlUGF0aDoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzZW5kTWVzc2FnZUltZzoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgICAgICBzaG93TWVzc2FnZUNhcmQ6IHtcbiAgICAgICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGFwcFBhcmFtZXRlcjoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAgY29tcHV0ZWQ6IHtcbiAgICAgICAgY2xhc3NlcygpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcHJlZml4Q2xzLCBob3ZlckNsYXNzLCB0eXBlLCBzaXplLCBibG9jaywgZnVsbCwgY2xlYXIsIG91dGxpbmUsIGJvcmRlcmVkLCBkaXNhYmxlZCB9ID0gdGhpcy5kYXRhXG4gICAgICAgICAgICBjb25zdCB3cmFwID0gY2xhc3NOYW1lcyhwcmVmaXhDbHMsIHtcbiAgICAgICAgICAgICAgICBbYCR7cHJlZml4Q2xzfS0tJHt0eXBlfWBdOiB0eXBlLFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS0ke3NpemV9YF06IHNpemUsXG4gICAgICAgICAgICAgICAgW2Ake3ByZWZpeENsc30tLWJsb2NrYF06IGJsb2NrLFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1mdWxsYF06IGZ1bGwsXG4gICAgICAgICAgICAgICAgW2Ake3ByZWZpeENsc30tLWNsZWFyYF06IGNsZWFyLFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1vdXRsaW5lYF06IG91dGxpbmUsXG4gICAgICAgICAgICAgICAgW2Ake3ByZWZpeENsc30tLWJvcmRlcmVkYF06IGJvcmRlcmVkLFxuICAgICAgICAgICAgICAgIFtgJHtwcmVmaXhDbHN9LS1kaXNhYmxlZGBdOiBkaXNhYmxlZCxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBjb25zdCBob3ZlciA9IGhvdmVyQ2xhc3MgJiYgaG92ZXJDbGFzcyAhPT0gJ2RlZmF1bHQnID8gaG92ZXJDbGFzcyA6IGAke3ByZWZpeENsc30tLWhvdmVyYFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdyYXAsXG4gICAgICAgICAgICAgICAgaG92ZXIsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBtZXRob2RzOiB7XG4gICAgICAgIG9uVGFwKCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmRhdGEuZGlzYWJsZWQgJiYgIXRoaXMuZGF0YS5sb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2NsaWNrJylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgYmluZGdldHVzZXJpbmZvKGUpIHtcbiAgICAgICAgICAgIHRoaXMudHJpZ2dlckV2ZW50KCdnZXR1c2VyaW5mbycsIGUuZGV0YWlsKVxuICAgICAgICB9LFxuICAgICAgICBiaW5kY29udGFjdChlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY29udGFjdCcsIGUuZGV0YWlsKVxuICAgICAgICB9LFxuICAgICAgICBiaW5kZ2V0cGhvbmVudW1iZXIoZSkge1xuICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2dldHBob25lbnVtYmVyJywgZS5kZXRhaWwpXG4gICAgICAgIH0sXG4gICAgICAgIGJpbmRvcGVuc2V0dGluZyhlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnb3BlbnNldHRpbmcnLCBlLmRldGFpbClcbiAgICAgICAgfSxcbiAgICAgICAgb25FcnJvcihlKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnZXJyb3InLCBlLmRldGFpbClcbiAgICAgICAgfSxcbiAgICB9LFxufSlcbiJdfQ==