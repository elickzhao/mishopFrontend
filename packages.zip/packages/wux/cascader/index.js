'use strict';

var _baseComponent = require('./../helpers/baseComponent.js');

var _baseComponent2 = _interopRequireDefault(_baseComponent);

var _classNames = require('./../helpers/classNames.js');

var _classNames2 = _interopRequireDefault(_classNames);

var _arrayTreeFilter = require('./../helpers/arrayTreeFilter.js');

var _arrayTreeFilter2 = _interopRequireDefault(_arrayTreeFilter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var WUX_CASCADER = 'wux-cascader';
var defaultFieldNames = {
    label: 'label',
    value: 'value',
    children: 'children'
};

(0, _baseComponent2.default)({
    externalClasses: ['wux-scroll-view-class'],
    properties: {
        prefixCls: {
            type: String,
            value: 'wux-cascader'
        },
        defaultValue: {
            type: Array,
            value: []
        },
        value: {
            type: Array,
            value: [],
            observer: function observer(newVal) {
                var _this = this;

                if (this.data.controlled) {
                    this.setData({ activeValue: newVal }, function () {
                        return _this.getCurrentOptions(newVal);
                    });
                }
            }
        },
        controlled: {
            type: Boolean,
            value: false
        },
        title: {
            type: String,
            value: ''
        },
        city: {
            type: String,
            value: ''
        },
        options: {
            type: Array,
            value: [],
            observer: 'getCurrentOptions'
        },
        chooseTitle: {
            type: String,
            value: '请选择'
        },
        visible: {
            type: Boolean,
            value: false
        },
        defaultFieldNames: {
            type: Object,
            value: defaultFieldNames
        }
    },
    data: {
        activeOptions: [],
        activeIndex: 0,
        bodyStyle: '',
        activeValue: [],
        showOptions: [],
        fieldNames: {}
    },
    computed: {
        classes: function classes() {
            var prefixCls = this.data.prefixCls;

            var wrap = (0, _classNames2.default)(prefixCls);
            var hd = prefixCls + '__hd';
            var title = prefixCls + '__title';
            var menus = prefixCls + '__menus';
            var menu = prefixCls + '__menu';
            var bd = prefixCls + '__bd';
            var inner = prefixCls + '__inner';
            var scrollView = prefixCls + '__scroll-view';
            var option = prefixCls + '__option';
            var item = prefixCls + '__item';
            var icon = prefixCls + '__icon';
            var ft = prefixCls + '__ft';

            return {
                wrap: wrap,
                hd: hd,
                title: title,
                menus: menus,
                menu: menu,
                bd: bd,
                inner: inner,
                scrollView: scrollView,
                option: option,
                item: item,
                icon: icon,
                ft: ft
            };
        }
    },
    methods: {
        getActiveOptions: function getActiveOptions(activeValue) {
            var options = this.data.options;

            var value = this.getFieldName('value');
            var childrenKeyName = this.getFieldName('children');

            return (0, _arrayTreeFilter2.default)(options, function (option, level) {
                return option[value] === activeValue[level];
            }, { childrenKeyName: childrenKeyName });
        },
        getShowOptions: function getShowOptions(activeValue) {
            var options = this.data.options;

            var children = this.getFieldName('children');
            var result = this.getActiveOptions(activeValue).map(function (activeOption) {
                return activeOption[children];
            }).filter(function (activeOption) {
                return !!activeOption;
            });

            return [options].concat(_toConsumableArray(result));
        },
        getMenus: function getMenus() {
            var activeValue = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
            var hasChildren = arguments[1];
            var _data = this.data,
                options = _data.options,
                chooseTitle = _data.chooseTitle;

            var activeOptions = this.getActiveOptions(activeValue);

            if (hasChildren && activeOptions.length < options.length) {
                var _activeOptions$push;

                var value = this.getFieldName('value');
                var label = this.getFieldName('label');

                activeOptions.push((_activeOptions$push = {}, _defineProperty(_activeOptions$push, value, WUX_CASCADER), _defineProperty(_activeOptions$push, label, chooseTitle), _activeOptions$push));
            }

            return activeOptions;
        },
        getNextActiveValue: function getNextActiveValue(value, optionIndex) {
            var activeValue = this.data.activeValue;


            activeValue = activeValue.slice(0, optionIndex + 1);
            activeValue[optionIndex] = value;

            return activeValue;
        },
        updated: function updated(currentOptions, optionIndex, condition, callback) {
            var value = this.getFieldName('value');
            var children = this.getFieldName('children');
            var hasChildren = currentOptions[children] && currentOptions[children].length > 0;
            var activeValue = this.getNextActiveValue(currentOptions[value], optionIndex);
            var activeOptions = this.getMenus(activeValue, hasChildren);
            var activeIndex = activeOptions.length - 1;
            var showOptions = this.getShowOptions(activeValue);
            var params = {
                activeValue: activeValue,
                activeOptions: activeOptions,
                activeIndex: activeIndex,
                showOptions: showOptions

                // 判断 hasChildren 计算需要更新的数据
            };if (hasChildren || activeValue.length === showOptions.length && (optionIndex = Math.max(0, optionIndex - 1))) {
                params.bodyStyle = 'transform: translate(' + -50 * optionIndex + '%)';
                params.showOptions = showOptions;
            }

            // 判断是否需要 setData 更新数据
            if (condition) {
                this.setData(params);
            }

            // 回调函数
            if (typeof callback === 'function') {
                callback.call(this, currentOptions, activeOptions, !hasChildren);
            }
        },

        /**
         * 更新级联数据
         * @param {Array} activeValue 当前选中值
         */
        getCurrentOptions: function getCurrentOptions() {
            var activeValue = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.activeValue;
            // console.log(activeValue, 'activeValue 213-----------------------')
            var optionIndex = Math.max(0, activeValue.length - 1);
            var activeOptions = this.getActiveOptions(activeValue);
            var currentOptions = activeOptions[optionIndex];

            if (currentOptions) {
                this.updated(currentOptions, optionIndex, true);
            } else {
                var _activeOptions$push2;

                var value = this.getFieldName('value');
                var label = this.getFieldName('label');

                activeOptions.push((_activeOptions$push2 = {}, _defineProperty(_activeOptions$push2, value, WUX_CASCADER), _defineProperty(_activeOptions$push2, label, this.data.chooseTitle), _activeOptions$push2));

                var showOptions = this.getShowOptions(activeValue);
                var activeIndex = activeOptions.length - 1;
                var params = {
                    showOptions: showOptions,
                    activeOptions: activeOptions,
                    activeIndex: activeIndex,
                    bodyStyle: ''
                };
                // console.log(params, 'params 236-----------------------')
                this.setData(params);
            }
        },

        /**
         * 点击菜单时的回调函数
         */
        onMenuClick: function onMenuClick(e) {
            var menuIndex = e.currentTarget.dataset.menuIndex;

            var index = menuIndex > 1 ? menuIndex - 1 : 0;
            var bodyStyle = 'transform: translate(' + -50 * index + '%)';

            this.setData({
                bodyStyle: bodyStyle,
                activeIndex: menuIndex
            });
        },

        /**
         * 点击选项时的回调函数
         */
        onItemSelect: function onItemSelect(e) {
            var _e$currentTarget$data = e.currentTarget.dataset,
                item = _e$currentTarget$data.item,
                optionIndex = _e$currentTarget$data.optionIndex;

            // 判断是否禁用

            if (!item || item.disabled) return;

            // updated
            this.updated(item, optionIndex, !this.data.controlled, this.onChange);
        },

        /**
         * 组件关闭时的回调函数
         */
        onPopupClose: function onPopupClose() {
            this.triggerEvent('close');
        },

        /**
         * 选择完成时的回调函数
         */
        onChange: function onChange() {
            var currentOptions = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            var _this2 = this;

            var activeOptions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
            var done = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

            var options = activeOptions.filter(function (n) {
                return n[_this2.getFieldName('value')] !== WUX_CASCADER;
            });
            var value = options.map(function (n) {
                return n[_this2.getFieldName('value')];
            });

            // 判断是否异步加载
            if (currentOptions.isLeaf === false && !currentOptions.children) {
                this.emitEvent({ value: value, options: options, done: false });
                this.triggerEvent('load', { value: value, options: options });
                return;
            }

            // 正常加载
            this.emitEvent({ value: value, options: options, done: done });
        },
        emitEvent: function emitEvent() {
            var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            this.triggerEvent('change', params);

            // 当选择完成时关闭组件
            if (params.done) {
                this.onPopupClose();
            }
        },
        getFieldName: function getFieldName(name) {
            return this.data.fieldNames[name];
        }
    },
    // 原版生命周期加载在赋值之前 无法动态设定 改成下面的ready 解决这个问题
    // attached: function attached() {
    //     var _this3 = this;

    //     var _data2 = this.data,
    //         defaultValue = _data2.defaultValue,
    //         value = _data2.value,
    //         controlled = _data2.controlled;
    //     var activeValue = controlled ? value : defaultValue;
    //     console.log(activeValue, 'index.js 327')
    //     var fieldNames = Object.assign({}, defaultFieldNames, this.data.defaultFieldNames);

    //     this.setData({ activeValue: activeValue, fieldNames: fieldNames }, function () {
    //         return _this3.getCurrentOptions(activeValue);
    //     });
    // },
    ready: function ready(){
        var _this3 = this;
        var _data2 = this.data,
            defaultValue = _data2.defaultValue,
            value = _data2.value,
            controlled = _data2.controlled;
        var activeValue = controlled ? value : defaultValue;
        // console.log(activeValue, 'activeValue -- index.js 327')
        var fieldNames = Object.assign({}, defaultFieldNames, this.data.defaultFieldNames);

        this.setData({ activeValue: activeValue, fieldNames: fieldNames }, function () {
            return _this3.getCurrentOptions(activeValue);
        });
        // 这里貌似得触发一下才行
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIldVWF9DQVNDQURFUiIsImRlZmF1bHRGaWVsZE5hbWVzIiwibGFiZWwiLCJ2YWx1ZSIsImNoaWxkcmVuIiwiZXh0ZXJuYWxDbGFzc2VzIiwicHJvcGVydGllcyIsInByZWZpeENscyIsInR5cGUiLCJTdHJpbmciLCJkZWZhdWx0VmFsdWUiLCJBcnJheSIsIm9ic2VydmVyIiwibmV3VmFsIiwiZGF0YSIsImNvbnRyb2xsZWQiLCJzZXREYXRhIiwiYWN0aXZlVmFsdWUiLCJnZXRDdXJyZW50T3B0aW9ucyIsIkJvb2xlYW4iLCJ0aXRsZSIsIm9wdGlvbnMiLCJjaG9vc2VUaXRsZSIsInZpc2libGUiLCJPYmplY3QiLCJhY3RpdmVPcHRpb25zIiwiYWN0aXZlSW5kZXgiLCJib2R5U3R5bGUiLCJzaG93T3B0aW9ucyIsImZpZWxkTmFtZXMiLCJjb21wdXRlZCIsImNsYXNzZXMiLCJ3cmFwIiwiaGQiLCJtZW51cyIsIm1lbnUiLCJiZCIsImlubmVyIiwic2Nyb2xsVmlldyIsIm9wdGlvbiIsIml0ZW0iLCJpY29uIiwiZnQiLCJtZXRob2RzIiwiZ2V0QWN0aXZlT3B0aW9ucyIsImdldEZpZWxkTmFtZSIsImNoaWxkcmVuS2V5TmFtZSIsImxldmVsIiwiZ2V0U2hvd09wdGlvbnMiLCJyZXN1bHQiLCJtYXAiLCJhY3RpdmVPcHRpb24iLCJmaWx0ZXIiLCJnZXRNZW51cyIsImhhc0NoaWxkcmVuIiwibGVuZ3RoIiwicHVzaCIsImdldE5leHRBY3RpdmVWYWx1ZSIsIm9wdGlvbkluZGV4Iiwic2xpY2UiLCJ1cGRhdGVkIiwiY3VycmVudE9wdGlvbnMiLCJjb25kaXRpb24iLCJjYWxsYmFjayIsInBhcmFtcyIsIk1hdGgiLCJtYXgiLCJjYWxsIiwib25NZW51Q2xpY2siLCJlIiwibWVudUluZGV4IiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJpbmRleCIsIm9uSXRlbVNlbGVjdCIsImRpc2FibGVkIiwib25DaGFuZ2UiLCJvblBvcHVwQ2xvc2UiLCJ0cmlnZ2VyRXZlbnQiLCJkb25lIiwibiIsImlzTGVhZiIsImVtaXRFdmVudCIsIm5hbWUiLCJhdHRhY2hlZCIsImFzc2lnbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7QUFFQSxJQUFNQSxlQUFlLGNBQXJCO0FBQ0EsSUFBTUMsb0JBQW9CO0FBQ3RCQyxXQUFPLE9BRGU7QUFFdEJDLFdBQU8sT0FGZTtBQUd0QkMsY0FBVTtBQUhZLENBQTFCOztBQU1BLDZCQUFjO0FBQ1ZDLHFCQUFpQixDQUFDLHVCQUFELENBRFA7QUFFVkMsZ0JBQVk7QUFDUkMsbUJBQVc7QUFDUEMsa0JBQU1DLE1BREM7QUFFUE4sbUJBQU87QUFGQSxTQURIO0FBS1JPLHNCQUFjO0FBQ1ZGLGtCQUFNRyxLQURJO0FBRVZSLG1CQUFPO0FBRkcsU0FMTjtBQVNSQSxlQUFPO0FBQ0hLLGtCQUFNRyxLQURIO0FBRUhSLG1CQUFPLEVBRko7QUFHSFMsb0JBSEcsb0JBR01DLE1BSE4sRUFHYztBQUFBOztBQUNiLG9CQUFJLEtBQUtDLElBQUwsQ0FBVUMsVUFBZCxFQUEwQjtBQUN0Qix5QkFBS0MsT0FBTCxDQUFhLEVBQUVDLGFBQWFKLE1BQWYsRUFBYixFQUFzQztBQUFBLCtCQUFNLE1BQUtLLGlCQUFMLENBQXVCTCxNQUF2QixDQUFOO0FBQUEscUJBQXRDO0FBQ0g7QUFDSjtBQVBFLFNBVEM7QUFrQlJFLG9CQUFZO0FBQ1JQLGtCQUFNVyxPQURFO0FBRVJoQixtQkFBTztBQUZDLFNBbEJKO0FBc0JSaUIsZUFBTztBQUNIWixrQkFBTUMsTUFESDtBQUVITixtQkFBTztBQUZKLFNBdEJDO0FBMEJSa0IsaUJBQVM7QUFDTGIsa0JBQU1HLEtBREQ7QUFFTFIsbUJBQU8sRUFGRjtBQUdMUyxzQkFBVTtBQUhMLFNBMUJEO0FBK0JSVSxxQkFBYTtBQUNUZCxrQkFBTUMsTUFERztBQUVUTixtQkFBTztBQUZFLFNBL0JMO0FBbUNSb0IsaUJBQVM7QUFDTGYsa0JBQU1XLE9BREQ7QUFFTGhCLG1CQUFPO0FBRkYsU0FuQ0Q7QUF1Q1JGLDJCQUFtQjtBQUNmTyxrQkFBTWdCLE1BRFM7QUFFZnJCLG1CQUFPRjtBQUZRO0FBdkNYLEtBRkY7QUE4Q1ZhLFVBQU07QUFDRlcsdUJBQWUsRUFEYjtBQUVGQyxxQkFBYSxDQUZYO0FBR0ZDLG1CQUFXLEVBSFQ7QUFJRlYscUJBQWEsRUFKWDtBQUtGVyxxQkFBYSxFQUxYO0FBTUZDLG9CQUFZO0FBTlYsS0E5Q0k7QUFzRFZDLGNBQVU7QUFDTkMsZUFETSxxQkFDSTtBQUFBLGdCQUNFeEIsU0FERixHQUNnQixLQUFLTyxJQURyQixDQUNFUCxTQURGOztBQUVOLGdCQUFNeUIsT0FBTywwQkFBV3pCLFNBQVgsQ0FBYjtBQUNBLGdCQUFNMEIsS0FBUTFCLFNBQVIsU0FBTjtBQUNBLGdCQUFNYSxRQUFXYixTQUFYLFlBQU47QUFDQSxnQkFBTTJCLFFBQVczQixTQUFYLFlBQU47QUFDQSxnQkFBTTRCLE9BQVU1QixTQUFWLFdBQU47QUFDQSxnQkFBTTZCLEtBQVE3QixTQUFSLFNBQU47QUFDQSxnQkFBTThCLFFBQVc5QixTQUFYLFlBQU47QUFDQSxnQkFBTStCLGFBQWdCL0IsU0FBaEIsa0JBQU47QUFDQSxnQkFBTWdDLFNBQVloQyxTQUFaLGFBQU47QUFDQSxnQkFBTWlDLE9BQVVqQyxTQUFWLFdBQU47QUFDQSxnQkFBTWtDLE9BQVVsQyxTQUFWLFdBQU47QUFDQSxnQkFBTW1DLEtBQVFuQyxTQUFSLFNBQU47O0FBRUEsbUJBQU87QUFDSHlCLDBCQURHO0FBRUhDLHNCQUZHO0FBR0hiLDRCQUhHO0FBSUhjLDRCQUpHO0FBS0hDLDBCQUxHO0FBTUhDLHNCQU5HO0FBT0hDLDRCQVBHO0FBUUhDLHNDQVJHO0FBU0hDLDhCQVRHO0FBVUhDLDBCQVZHO0FBV0hDLDBCQVhHO0FBWUhDO0FBWkcsYUFBUDtBQWNIO0FBOUJLLEtBdERBO0FBc0ZWQyxhQUFTO0FBQ0xDLHdCQURLLDRCQUNZM0IsV0FEWixFQUN5QjtBQUFBLGdCQUNsQkksT0FEa0IsR0FDTixLQUFLUCxJQURDLENBQ2xCTyxPQURrQjs7QUFFMUIsZ0JBQU1sQixRQUFRLEtBQUswQyxZQUFMLENBQWtCLE9BQWxCLENBQWQ7QUFDQSxnQkFBTUMsa0JBQWtCLEtBQUtELFlBQUwsQ0FBa0IsVUFBbEIsQ0FBeEI7O0FBRUEsbUJBQU8sK0JBQWdCeEIsT0FBaEIsRUFBeUIsVUFBQ2tCLE1BQUQsRUFBU1EsS0FBVDtBQUFBLHVCQUFtQlIsT0FBT3BDLEtBQVAsTUFBa0JjLFlBQVk4QixLQUFaLENBQXJDO0FBQUEsYUFBekIsRUFBa0YsRUFBRUQsZ0NBQUYsRUFBbEYsQ0FBUDtBQUNILFNBUEk7QUFRTEUsc0JBUkssMEJBUVUvQixXQVJWLEVBUXVCO0FBQUEsZ0JBQ2hCSSxPQURnQixHQUNKLEtBQUtQLElBREQsQ0FDaEJPLE9BRGdCOztBQUV4QixnQkFBTWpCLFdBQVcsS0FBS3lDLFlBQUwsQ0FBa0IsVUFBbEIsQ0FBakI7QUFDQSxnQkFBTUksU0FBUyxLQUFLTCxnQkFBTCxDQUFzQjNCLFdBQXRCLEVBQW1DaUMsR0FBbkMsQ0FBdUMsVUFBQ0MsWUFBRDtBQUFBLHVCQUFrQkEsYUFBYS9DLFFBQWIsQ0FBbEI7QUFBQSxhQUF2QyxFQUFpRmdELE1BQWpGLENBQXdGLFVBQUNELFlBQUQ7QUFBQSx1QkFBa0IsQ0FBQyxDQUFDQSxZQUFwQjtBQUFBLGFBQXhGLENBQWY7O0FBRUEsb0JBQVE5QixPQUFSLDRCQUFvQjRCLE1BQXBCO0FBQ0gsU0FkSTtBQWVMSSxnQkFmSyxzQkFlbUM7QUFBQSxnQkFBL0JwQyxXQUErQix1RUFBakIsRUFBaUI7QUFBQSxnQkFBYnFDLFdBQWE7QUFBQSx3QkFDSCxLQUFLeEMsSUFERjtBQUFBLGdCQUM1Qk8sT0FENEIsU0FDNUJBLE9BRDRCO0FBQUEsZ0JBQ25CQyxXQURtQixTQUNuQkEsV0FEbUI7O0FBRXBDLGdCQUFNRyxnQkFBZ0IsS0FBS21CLGdCQUFMLENBQXNCM0IsV0FBdEIsQ0FBdEI7O0FBRUEsZ0JBQUlxQyxlQUFlN0IsY0FBYzhCLE1BQWQsR0FBdUJsQyxRQUFRa0MsTUFBbEQsRUFBMEQ7QUFBQTs7QUFDdEQsb0JBQU1wRCxRQUFRLEtBQUswQyxZQUFMLENBQWtCLE9BQWxCLENBQWQ7QUFDQSxvQkFBTTNDLFFBQVEsS0FBSzJDLFlBQUwsQ0FBa0IsT0FBbEIsQ0FBZDs7QUFFQXBCLDhCQUFjK0IsSUFBZCxpRUFDS3JELEtBREwsRUFDYUgsWUFEYix3Q0FFS0UsS0FGTCxFQUVhb0IsV0FGYjtBQUlIOztBQUVELG1CQUFPRyxhQUFQO0FBQ0gsU0E5Qkk7QUErQkxnQywwQkEvQkssOEJBK0JjdEQsS0EvQmQsRUErQnFCdUQsV0EvQnJCLEVBK0JrQztBQUFBLGdCQUM3QnpDLFdBRDZCLEdBQ2IsS0FBS0gsSUFEUSxDQUM3QkcsV0FENkI7OztBQUduQ0EsMEJBQWNBLFlBQVkwQyxLQUFaLENBQWtCLENBQWxCLEVBQXFCRCxjQUFjLENBQW5DLENBQWQ7QUFDQXpDLHdCQUFZeUMsV0FBWixJQUEyQnZELEtBQTNCOztBQUVBLG1CQUFPYyxXQUFQO0FBQ0gsU0F0Q0k7QUF1Q0wyQyxlQXZDSyxtQkF1Q0dDLGNBdkNILEVBdUNtQkgsV0F2Q25CLEVBdUNnQ0ksU0F2Q2hDLEVBdUMyQ0MsUUF2QzNDLEVBdUNxRDtBQUN0RCxnQkFBTTVELFFBQVEsS0FBSzBDLFlBQUwsQ0FBa0IsT0FBbEIsQ0FBZDtBQUNBLGdCQUFNekMsV0FBVyxLQUFLeUMsWUFBTCxDQUFrQixVQUFsQixDQUFqQjtBQUNBLGdCQUFNUyxjQUFjTyxlQUFlekQsUUFBZixLQUE0QnlELGVBQWV6RCxRQUFmLEVBQXlCbUQsTUFBekIsR0FBa0MsQ0FBbEY7QUFDQSxnQkFBTXRDLGNBQWMsS0FBS3dDLGtCQUFMLENBQXdCSSxlQUFlMUQsS0FBZixDQUF4QixFQUErQ3VELFdBQS9DLENBQXBCO0FBQ0EsZ0JBQU1qQyxnQkFBZ0IsS0FBSzRCLFFBQUwsQ0FBY3BDLFdBQWQsRUFBMkJxQyxXQUEzQixDQUF0QjtBQUNBLGdCQUFNNUIsY0FBY0QsY0FBYzhCLE1BQWQsR0FBdUIsQ0FBM0M7QUFDQSxnQkFBTTNCLGNBQWMsS0FBS29CLGNBQUwsQ0FBb0IvQixXQUFwQixDQUFwQjtBQUNBLGdCQUFNK0MsU0FBUztBQUNYL0Msd0NBRFc7QUFFWFEsNENBRlc7QUFHWEMsd0NBSFc7QUFJWEU7O0FBR0o7QUFQZSxhQUFmLENBUUEsSUFBSTBCLGVBQWdCckMsWUFBWXNDLE1BQVosS0FBdUIzQixZQUFZMkIsTUFBbkMsS0FBOENHLGNBQWNPLEtBQUtDLEdBQUwsQ0FBUyxDQUFULEVBQVlSLGNBQWMsQ0FBMUIsQ0FBNUQsQ0FBcEIsRUFBZ0g7QUFDNUdNLHVCQUFPckMsU0FBUCw2QkFBMkMsQ0FBQyxFQUFELEdBQU0rQixXQUFqRDtBQUNBTSx1QkFBT3BDLFdBQVAsR0FBcUJBLFdBQXJCO0FBQ0g7O0FBRUQ7QUFDQSxnQkFBSWtDLFNBQUosRUFBZTtBQUNYLHFCQUFLOUMsT0FBTCxDQUFhZ0QsTUFBYjtBQUNIOztBQUVEO0FBQ0EsZ0JBQUksT0FBT0QsUUFBUCxLQUFvQixVQUF4QixFQUFvQztBQUNoQ0EseUJBQVNJLElBQVQsQ0FBYyxJQUFkLEVBQW9CTixjQUFwQixFQUFvQ3BDLGFBQXBDLEVBQW1ELENBQUM2QixXQUFwRDtBQUNIO0FBQ0osU0FyRUk7O0FBc0VMOzs7O0FBSUFwQyx5QkExRUssK0JBMEVrRDtBQUFBLGdCQUFyQ0QsV0FBcUMsdUVBQXZCLEtBQUtILElBQUwsQ0FBVUcsV0FBYTs7QUFDbkQsZ0JBQU15QyxjQUFjTyxLQUFLQyxHQUFMLENBQVMsQ0FBVCxFQUFZakQsWUFBWXNDLE1BQVosR0FBcUIsQ0FBakMsQ0FBcEI7QUFDQSxnQkFBTTlCLGdCQUFnQixLQUFLbUIsZ0JBQUwsQ0FBc0IzQixXQUF0QixDQUF0QjtBQUNBLGdCQUFNNEMsaUJBQWlCcEMsY0FBY2lDLFdBQWQsQ0FBdkI7O0FBRUEsZ0JBQUlHLGNBQUosRUFBb0I7QUFDaEIscUJBQUtELE9BQUwsQ0FBYUMsY0FBYixFQUE2QkgsV0FBN0IsRUFBMEMsSUFBMUM7QUFDSCxhQUZELE1BRU87QUFBQTs7QUFDSCxvQkFBTXZELFFBQVEsS0FBSzBDLFlBQUwsQ0FBa0IsT0FBbEIsQ0FBZDtBQUNBLG9CQUFNM0MsUUFBUSxLQUFLMkMsWUFBTCxDQUFrQixPQUFsQixDQUFkOztBQUVBcEIsOEJBQWMrQixJQUFkLG1FQUNLckQsS0FETCxFQUNhSCxZQURiLHlDQUVLRSxLQUZMLEVBRWEsS0FBS1ksSUFBTCxDQUFVUSxXQUZ2Qjs7QUFLQSxvQkFBTU0sY0FBYyxLQUFLb0IsY0FBTCxDQUFvQi9CLFdBQXBCLENBQXBCO0FBQ0Esb0JBQU1TLGNBQWNELGNBQWM4QixNQUFkLEdBQXVCLENBQTNDO0FBQ0Esb0JBQU1TLFNBQVM7QUFDWHBDLDRDQURXO0FBRVhILGdEQUZXO0FBR1hDLDRDQUhXO0FBSVhDLCtCQUFXO0FBSkEsaUJBQWY7O0FBT0EscUJBQUtYLE9BQUwsQ0FBYWdELE1BQWI7QUFDSDtBQUNKLFNBckdJOztBQXNHTDs7O0FBR0FJLG1CQXpHSyx1QkF5R09DLENBekdQLEVBeUdVO0FBQUEsZ0JBQ0hDLFNBREcsR0FDV0QsRUFBRUUsYUFBRixDQUFnQkMsT0FEM0IsQ0FDSEYsU0FERzs7QUFFWCxnQkFBTUcsUUFBUUgsWUFBWSxDQUFaLEdBQWdCQSxZQUFZLENBQTVCLEdBQWdDLENBQTlDO0FBQ0EsZ0JBQU0zQyxzQ0FBb0MsQ0FBQyxFQUFELEdBQU04QyxLQUExQyxPQUFOOztBQUVBLGlCQUFLekQsT0FBTCxDQUFhO0FBQ1RXLG9DQURTO0FBRVRELDZCQUFhNEM7QUFGSixhQUFiO0FBSUgsU0FsSEk7O0FBbUhMOzs7QUFHQUksb0JBdEhLLHdCQXNIUUwsQ0F0SFIsRUFzSFc7QUFBQSx3Q0FDa0JBLEVBQUVFLGFBQUYsQ0FBZ0JDLE9BRGxDO0FBQUEsZ0JBQ0poQyxJQURJLHlCQUNKQSxJQURJO0FBQUEsZ0JBQ0VrQixXQURGLHlCQUNFQSxXQURGOztBQUdaOztBQUNBLGdCQUFJLENBQUNsQixJQUFELElBQVNBLEtBQUttQyxRQUFsQixFQUE0Qjs7QUFFNUI7QUFDQSxpQkFBS2YsT0FBTCxDQUFhcEIsSUFBYixFQUFtQmtCLFdBQW5CLEVBQWdDLENBQUMsS0FBSzVDLElBQUwsQ0FBVUMsVUFBM0MsRUFBdUQsS0FBSzZELFFBQTVEO0FBQ0gsU0E5SEk7O0FBK0hMOzs7QUFHQUMsb0JBbElLLDBCQWtJVTtBQUNYLGlCQUFLQyxZQUFMLENBQWtCLE9BQWxCO0FBQ0gsU0FwSUk7O0FBcUlMOzs7QUFHQUYsZ0JBeElLLHNCQXdJMkQ7QUFBQSxnQkFBdkRmLGNBQXVELHVFQUF0QyxFQUFzQzs7QUFBQTs7QUFBQSxnQkFBbENwQyxhQUFrQyx1RUFBbEIsRUFBa0I7QUFBQSxnQkFBZHNELElBQWMsdUVBQVAsS0FBTzs7QUFDNUQsZ0JBQU0xRCxVQUFVSSxjQUFjMkIsTUFBZCxDQUFxQixVQUFDNEIsQ0FBRDtBQUFBLHVCQUFPQSxFQUFFLE9BQUtuQyxZQUFMLENBQWtCLE9BQWxCLENBQUYsTUFBa0M3QyxZQUF6QztBQUFBLGFBQXJCLENBQWhCO0FBQ0EsZ0JBQU1HLFFBQVFrQixRQUFRNkIsR0FBUixDQUFZLFVBQUM4QixDQUFEO0FBQUEsdUJBQU9BLEVBQUUsT0FBS25DLFlBQUwsQ0FBa0IsT0FBbEIsQ0FBRixDQUFQO0FBQUEsYUFBWixDQUFkOztBQUVBO0FBQ0EsZ0JBQUlnQixlQUFlb0IsTUFBZixLQUEwQixLQUExQixJQUFtQyxDQUFDcEIsZUFBZXpELFFBQXZELEVBQWlFO0FBQzdELHFCQUFLOEUsU0FBTCxDQUFlLEVBQUUvRSxZQUFGLEVBQVNrQixnQkFBVCxFQUFrQjBELE1BQU0sS0FBeEIsRUFBZjtBQUNBLHFCQUFLRCxZQUFMLENBQWtCLE1BQWxCLEVBQTBCLEVBQUUzRSxZQUFGLEVBQVNrQixnQkFBVCxFQUExQjtBQUNBO0FBQ0g7O0FBRUQ7QUFDQSxpQkFBSzZELFNBQUwsQ0FBZSxFQUFFL0UsWUFBRixFQUFTa0IsZ0JBQVQsRUFBa0IwRCxVQUFsQixFQUFmO0FBQ0gsU0FySkk7QUFzSkxHLGlCQXRKSyx1QkFzSmtCO0FBQUEsZ0JBQWJsQixNQUFhLHVFQUFKLEVBQUk7O0FBQ25CLGlCQUFLYyxZQUFMLENBQWtCLFFBQWxCLEVBQTRCZCxNQUE1Qjs7QUFFQTtBQUNBLGdCQUFJQSxPQUFPZSxJQUFYLEVBQWlCO0FBQ2IscUJBQUtGLFlBQUw7QUFDSDtBQUNKLFNBN0pJO0FBOEpMaEMsb0JBOUpLLHdCQThKUXNDLElBOUpSLEVBOEpjO0FBQ2YsbUJBQU8sS0FBS3JFLElBQUwsQ0FBVWUsVUFBVixDQUFxQnNELElBQXJCLENBQVA7QUFDSDtBQWhLSSxLQXRGQztBQXdQVkMsWUF4UFUsc0JBd1BDO0FBQUE7O0FBQUEscUJBQ3FDLEtBQUt0RSxJQUQxQztBQUFBLFlBQ0NKLFlBREQsVUFDQ0EsWUFERDtBQUFBLFlBQ2VQLEtBRGYsVUFDZUEsS0FEZjtBQUFBLFlBQ3NCWSxVQUR0QixVQUNzQkEsVUFEdEI7O0FBRVAsWUFBTUUsY0FBY0YsYUFBYVosS0FBYixHQUFxQk8sWUFBekM7QUFDQSxZQUFNbUIsYUFBYUwsT0FBTzZELE1BQVAsQ0FBYyxFQUFkLEVBQWtCcEYsaUJBQWxCLEVBQXFDLEtBQUthLElBQUwsQ0FBVWIsaUJBQS9DLENBQW5COztBQUVBLGFBQUtlLE9BQUwsQ0FBYSxFQUFFQyx3QkFBRixFQUFlWSxzQkFBZixFQUFiLEVBQTBDO0FBQUEsbUJBQU0sT0FBS1gsaUJBQUwsQ0FBdUJELFdBQXZCLENBQU47QUFBQSxTQUExQztBQUNIO0FBOVBTLENBQWQiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmFzZUNvbXBvbmVudCBmcm9tICcuLi9oZWxwZXJzL2Jhc2VDb21wb25lbnQnXG5pbXBvcnQgY2xhc3NOYW1lcyBmcm9tICcuLi9oZWxwZXJzL2NsYXNzTmFtZXMnXG5pbXBvcnQgYXJyYXlUcmVlRmlsdGVyIGZyb20gJy4uL2hlbHBlcnMvYXJyYXlUcmVlRmlsdGVyJ1xuXG5jb25zdCBXVVhfQ0FTQ0FERVIgPSAnd3V4LWNhc2NhZGVyJ1xuY29uc3QgZGVmYXVsdEZpZWxkTmFtZXMgPSB7XG4gICAgbGFiZWw6ICdsYWJlbCcsXG4gICAgdmFsdWU6ICd2YWx1ZScsXG4gICAgY2hpbGRyZW46ICdjaGlsZHJlbicsXG59XG5cbmJhc2VDb21wb25lbnQoe1xuICAgIGV4dGVybmFsQ2xhc3NlczogWyd3dXgtc2Nyb2xsLXZpZXctY2xhc3MnXSxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHByZWZpeENsczoge1xuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgdmFsdWU6ICd3dXgtY2FzY2FkZXInLFxuICAgICAgICB9LFxuICAgICAgICBkZWZhdWx0VmFsdWU6IHtcbiAgICAgICAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgICAgICAgdmFsdWU6IFtdLFxuICAgICAgICB9LFxuICAgICAgICB2YWx1ZToge1xuICAgICAgICAgICAgdHlwZTogQXJyYXksXG4gICAgICAgICAgICB2YWx1ZTogW10sXG4gICAgICAgICAgICBvYnNlcnZlcihuZXdWYWwpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kYXRhLmNvbnRyb2xsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHsgYWN0aXZlVmFsdWU6IG5ld1ZhbCB9LCAoKSA9PiB0aGlzLmdldEN1cnJlbnRPcHRpb25zKG5ld1ZhbCkpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgY29udHJvbGxlZDoge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgfSxcbiAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgdHlwZTogQXJyYXksXG4gICAgICAgICAgICB2YWx1ZTogW10sXG4gICAgICAgICAgICBvYnNlcnZlcjogJ2dldEN1cnJlbnRPcHRpb25zJyxcbiAgICAgICAgfSxcbiAgICAgICAgY2hvb3NlVGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHZhbHVlOiAn6K+36YCJ5oupJyxcbiAgICAgICAgfSxcbiAgICAgICAgdmlzaWJsZToge1xuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgZGVmYXVsdEZpZWxkTmFtZXM6IHtcbiAgICAgICAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgICAgICAgIHZhbHVlOiBkZWZhdWx0RmllbGROYW1lcyxcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIGRhdGE6IHtcbiAgICAgICAgYWN0aXZlT3B0aW9uczogW10sXG4gICAgICAgIGFjdGl2ZUluZGV4OiAwLFxuICAgICAgICBib2R5U3R5bGU6ICcnLFxuICAgICAgICBhY3RpdmVWYWx1ZTogW10sXG4gICAgICAgIHNob3dPcHRpb25zOiBbXSxcbiAgICAgICAgZmllbGROYW1lczoge30sXG4gICAgfSxcbiAgICBjb21wdXRlZDoge1xuICAgICAgICBjbGFzc2VzKCkge1xuICAgICAgICAgICAgY29uc3QgeyBwcmVmaXhDbHMgfSA9IHRoaXMuZGF0YVxuICAgICAgICAgICAgY29uc3Qgd3JhcCA9IGNsYXNzTmFtZXMocHJlZml4Q2xzKVxuICAgICAgICAgICAgY29uc3QgaGQgPSBgJHtwcmVmaXhDbHN9X19oZGBcbiAgICAgICAgICAgIGNvbnN0IHRpdGxlID0gYCR7cHJlZml4Q2xzfV9fdGl0bGVgXG4gICAgICAgICAgICBjb25zdCBtZW51cyA9IGAke3ByZWZpeENsc31fX21lbnVzYFxuICAgICAgICAgICAgY29uc3QgbWVudSA9IGAke3ByZWZpeENsc31fX21lbnVgXG4gICAgICAgICAgICBjb25zdCBiZCA9IGAke3ByZWZpeENsc31fX2JkYFxuICAgICAgICAgICAgY29uc3QgaW5uZXIgPSBgJHtwcmVmaXhDbHN9X19pbm5lcmBcbiAgICAgICAgICAgIGNvbnN0IHNjcm9sbFZpZXcgPSBgJHtwcmVmaXhDbHN9X19zY3JvbGwtdmlld2BcbiAgICAgICAgICAgIGNvbnN0IG9wdGlvbiA9IGAke3ByZWZpeENsc31fX29wdGlvbmBcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBgJHtwcmVmaXhDbHN9X19pdGVtYFxuICAgICAgICAgICAgY29uc3QgaWNvbiA9IGAke3ByZWZpeENsc31fX2ljb25gXG4gICAgICAgICAgICBjb25zdCBmdCA9IGAke3ByZWZpeENsc31fX2Z0YFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdyYXAsXG4gICAgICAgICAgICAgICAgaGQsXG4gICAgICAgICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgICAgICAgbWVudXMsXG4gICAgICAgICAgICAgICAgbWVudSxcbiAgICAgICAgICAgICAgICBiZCxcbiAgICAgICAgICAgICAgICBpbm5lcixcbiAgICAgICAgICAgICAgICBzY3JvbGxWaWV3LFxuICAgICAgICAgICAgICAgIG9wdGlvbixcbiAgICAgICAgICAgICAgICBpdGVtLFxuICAgICAgICAgICAgICAgIGljb24sXG4gICAgICAgICAgICAgICAgZnQsXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBtZXRob2RzOiB7XG4gICAgICAgIGdldEFjdGl2ZU9wdGlvbnMoYWN0aXZlVmFsdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgb3B0aW9ucyB9ID0gdGhpcy5kYXRhXG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0RmllbGROYW1lKCd2YWx1ZScpXG4gICAgICAgICAgICBjb25zdCBjaGlsZHJlbktleU5hbWUgPSB0aGlzLmdldEZpZWxkTmFtZSgnY2hpbGRyZW4nKVxuXG4gICAgICAgICAgICByZXR1cm4gYXJyYXlUcmVlRmlsdGVyKG9wdGlvbnMsIChvcHRpb24sIGxldmVsKSA9PiBvcHRpb25bdmFsdWVdID09PSBhY3RpdmVWYWx1ZVtsZXZlbF0sIHsgY2hpbGRyZW5LZXlOYW1lIH0pXG4gICAgICAgIH0sXG4gICAgICAgIGdldFNob3dPcHRpb25zKGFjdGl2ZVZhbHVlKSB7XG4gICAgICAgICAgICBjb25zdCB7IG9wdGlvbnMgfSA9IHRoaXMuZGF0YVxuICAgICAgICAgICAgY29uc3QgY2hpbGRyZW4gPSB0aGlzLmdldEZpZWxkTmFtZSgnY2hpbGRyZW4nKVxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5nZXRBY3RpdmVPcHRpb25zKGFjdGl2ZVZhbHVlKS5tYXAoKGFjdGl2ZU9wdGlvbikgPT4gYWN0aXZlT3B0aW9uW2NoaWxkcmVuXSkuZmlsdGVyKChhY3RpdmVPcHRpb24pID0+ICEhYWN0aXZlT3B0aW9uKVxuXG4gICAgICAgICAgICByZXR1cm4gW29wdGlvbnMsIC4uLnJlc3VsdF1cbiAgICAgICAgfSxcbiAgICAgICAgZ2V0TWVudXMoYWN0aXZlVmFsdWUgPSBbXSwgaGFzQ2hpbGRyZW4pIHtcbiAgICAgICAgICAgIGNvbnN0IHsgb3B0aW9ucywgY2hvb3NlVGl0bGUgfSA9IHRoaXMuZGF0YVxuICAgICAgICAgICAgY29uc3QgYWN0aXZlT3B0aW9ucyA9IHRoaXMuZ2V0QWN0aXZlT3B0aW9ucyhhY3RpdmVWYWx1ZSlcblxuICAgICAgICAgICAgaWYgKGhhc0NoaWxkcmVuICYmIGFjdGl2ZU9wdGlvbnMubGVuZ3RoIDwgb3B0aW9ucy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0RmllbGROYW1lKCd2YWx1ZScpXG4gICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSB0aGlzLmdldEZpZWxkTmFtZSgnbGFiZWwnKVxuXG4gICAgICAgICAgICAgICAgYWN0aXZlT3B0aW9ucy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgW3ZhbHVlXTogV1VYX0NBU0NBREVSLFxuICAgICAgICAgICAgICAgICAgICBbbGFiZWxdOiBjaG9vc2VUaXRsZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBhY3RpdmVPcHRpb25zXG4gICAgICAgIH0sXG4gICAgICAgIGdldE5leHRBY3RpdmVWYWx1ZSh2YWx1ZSwgb3B0aW9uSW5kZXgpIHtcbiAgICAgICAgICAgIGxldCB7IGFjdGl2ZVZhbHVlIH0gPSB0aGlzLmRhdGFcblxuICAgICAgICAgICAgYWN0aXZlVmFsdWUgPSBhY3RpdmVWYWx1ZS5zbGljZSgwLCBvcHRpb25JbmRleCArIDEpXG4gICAgICAgICAgICBhY3RpdmVWYWx1ZVtvcHRpb25JbmRleF0gPSB2YWx1ZVxuXG4gICAgICAgICAgICByZXR1cm4gYWN0aXZlVmFsdWVcbiAgICAgICAgfSxcbiAgICAgICAgdXBkYXRlZChjdXJyZW50T3B0aW9ucywgb3B0aW9uSW5kZXgsIGNvbmRpdGlvbiwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGhpcy5nZXRGaWVsZE5hbWUoJ3ZhbHVlJylcbiAgICAgICAgICAgIGNvbnN0IGNoaWxkcmVuID0gdGhpcy5nZXRGaWVsZE5hbWUoJ2NoaWxkcmVuJylcbiAgICAgICAgICAgIGNvbnN0IGhhc0NoaWxkcmVuID0gY3VycmVudE9wdGlvbnNbY2hpbGRyZW5dICYmIGN1cnJlbnRPcHRpb25zW2NoaWxkcmVuXS5sZW5ndGggPiAwXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVWYWx1ZSA9IHRoaXMuZ2V0TmV4dEFjdGl2ZVZhbHVlKGN1cnJlbnRPcHRpb25zW3ZhbHVlXSwgb3B0aW9uSW5kZXgpXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVPcHRpb25zID0gdGhpcy5nZXRNZW51cyhhY3RpdmVWYWx1ZSwgaGFzQ2hpbGRyZW4pXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVJbmRleCA9IGFjdGl2ZU9wdGlvbnMubGVuZ3RoIC0gMVxuICAgICAgICAgICAgY29uc3Qgc2hvd09wdGlvbnMgPSB0aGlzLmdldFNob3dPcHRpb25zKGFjdGl2ZVZhbHVlKVxuICAgICAgICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGFjdGl2ZVZhbHVlLFxuICAgICAgICAgICAgICAgIGFjdGl2ZU9wdGlvbnMsXG4gICAgICAgICAgICAgICAgYWN0aXZlSW5kZXgsXG4gICAgICAgICAgICAgICAgc2hvd09wdGlvbnMsXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOWIpOaWrSBoYXNDaGlsZHJlbiDorqHnrpfpnIDopoHmm7TmlrDnmoTmlbDmja5cbiAgICAgICAgICAgIGlmIChoYXNDaGlsZHJlbiB8fCAoYWN0aXZlVmFsdWUubGVuZ3RoID09PSBzaG93T3B0aW9ucy5sZW5ndGggJiYgKG9wdGlvbkluZGV4ID0gTWF0aC5tYXgoMCwgb3B0aW9uSW5kZXggLSAxKSkpKSB7XG4gICAgICAgICAgICAgICAgcGFyYW1zLmJvZHlTdHlsZSA9IGB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgkey01MCAqIG9wdGlvbkluZGV4fSUpYFxuICAgICAgICAgICAgICAgIHBhcmFtcy5zaG93T3B0aW9ucyA9IHNob3dPcHRpb25zXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOWIpOaWreaYr+WQpumcgOimgSBzZXREYXRhIOabtOaWsOaVsOaNrlxuICAgICAgICAgICAgaWYgKGNvbmRpdGlvbikge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0RGF0YShwYXJhbXMpXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOWbnuiwg+WHveaVsFxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrLmNhbGwodGhpcywgY3VycmVudE9wdGlvbnMsIGFjdGl2ZU9wdGlvbnMsICFoYXNDaGlsZHJlbilcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOabtOaWsOe6p+iBlOaVsOaNrlxuICAgICAgICAgKiBAcGFyYW0ge0FycmF5fSBhY3RpdmVWYWx1ZSDlvZPliY3pgInkuK3lgLxcbiAgICAgICAgICovXG4gICAgICAgIGdldEN1cnJlbnRPcHRpb25zKGFjdGl2ZVZhbHVlID0gdGhpcy5kYXRhLmFjdGl2ZVZhbHVlKSB7XG4gICAgICAgICAgICBjb25zdCBvcHRpb25JbmRleCA9IE1hdGgubWF4KDAsIGFjdGl2ZVZhbHVlLmxlbmd0aCAtIDEpXG4gICAgICAgICAgICBjb25zdCBhY3RpdmVPcHRpb25zID0gdGhpcy5nZXRBY3RpdmVPcHRpb25zKGFjdGl2ZVZhbHVlKVxuICAgICAgICAgICAgY29uc3QgY3VycmVudE9wdGlvbnMgPSBhY3RpdmVPcHRpb25zW29wdGlvbkluZGV4XVxuXG4gICAgICAgICAgICBpZiAoY3VycmVudE9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZWQoY3VycmVudE9wdGlvbnMsIG9wdGlvbkluZGV4LCB0cnVlKVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0RmllbGROYW1lKCd2YWx1ZScpXG4gICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSB0aGlzLmdldEZpZWxkTmFtZSgnbGFiZWwnKVxuXG4gICAgICAgICAgICAgICAgYWN0aXZlT3B0aW9ucy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgW3ZhbHVlXTogV1VYX0NBU0NBREVSLFxuICAgICAgICAgICAgICAgICAgICBbbGFiZWxdOiB0aGlzLmRhdGEuY2hvb3NlVGl0bGVcbiAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICAgICAgY29uc3Qgc2hvd09wdGlvbnMgPSB0aGlzLmdldFNob3dPcHRpb25zKGFjdGl2ZVZhbHVlKVxuICAgICAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUluZGV4ID0gYWN0aXZlT3B0aW9ucy5sZW5ndGggLSAxXG4gICAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgICAgICAgICAgICAgICBzaG93T3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlSW5kZXgsXG4gICAgICAgICAgICAgICAgICAgIGJvZHlTdHlsZTogJycsXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHBhcmFtcylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIOeCueWHu+iPnOWNleaXtueahOWbnuiwg+WHveaVsFxuICAgICAgICAgKi9cbiAgICAgICAgb25NZW51Q2xpY2soZSkge1xuICAgICAgICAgICAgY29uc3QgeyBtZW51SW5kZXggfSA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IG1lbnVJbmRleCA+IDEgPyBtZW51SW5kZXggLSAxIDogMFxuICAgICAgICAgICAgY29uc3QgYm9keVN0eWxlID0gYHRyYW5zZm9ybTogdHJhbnNsYXRlKCR7LTUwICogaW5kZXh9JSlgXG5cbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XG4gICAgICAgICAgICAgICAgYm9keVN0eWxlLFxuICAgICAgICAgICAgICAgIGFjdGl2ZUluZGV4OiBtZW51SW5kZXgsXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog54K55Ye76YCJ6aG55pe255qE5Zue6LCD5Ye95pWwXG4gICAgICAgICAqL1xuICAgICAgICBvbkl0ZW1TZWxlY3QoZSkge1xuICAgICAgICAgICAgY29uc3QgeyBpdGVtLCBvcHRpb25JbmRleCB9ID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXRcblxuICAgICAgICAgICAgLy8g5Yik5pat5piv5ZCm56aB55SoXG4gICAgICAgICAgICBpZiAoIWl0ZW0gfHwgaXRlbS5kaXNhYmxlZCkgcmV0dXJuXG5cbiAgICAgICAgICAgIC8vIHVwZGF0ZWRcbiAgICAgICAgICAgIHRoaXMudXBkYXRlZChpdGVtLCBvcHRpb25JbmRleCwgIXRoaXMuZGF0YS5jb250cm9sbGVkLCB0aGlzLm9uQ2hhbmdlKVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog57uE5Lu25YWz6Zet5pe255qE5Zue6LCD5Ye95pWwXG4gICAgICAgICAqL1xuICAgICAgICBvblBvcHVwQ2xvc2UoKSB7XG4gICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnY2xvc2UnKVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog6YCJ5oup5a6M5oiQ5pe255qE5Zue6LCD5Ye95pWwXG4gICAgICAgICAqL1xuICAgICAgICBvbkNoYW5nZShjdXJyZW50T3B0aW9ucyA9IHt9LCBhY3RpdmVPcHRpb25zID0gW10sIGRvbmUgPSBmYWxzZSkge1xuICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IGFjdGl2ZU9wdGlvbnMuZmlsdGVyKChuKSA9PiBuW3RoaXMuZ2V0RmllbGROYW1lKCd2YWx1ZScpXSAhPT0gV1VYX0NBU0NBREVSKVxuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBvcHRpb25zLm1hcCgobikgPT4gblt0aGlzLmdldEZpZWxkTmFtZSgndmFsdWUnKV0pXG5cbiAgICAgICAgICAgIC8vIOWIpOaWreaYr+WQpuW8guatpeWKoOi9vVxuICAgICAgICAgICAgaWYgKGN1cnJlbnRPcHRpb25zLmlzTGVhZiA9PT0gZmFsc2UgJiYgIWN1cnJlbnRPcHRpb25zLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lbWl0RXZlbnQoeyB2YWx1ZSwgb3B0aW9ucywgZG9uZTogZmFsc2UgfSlcbiAgICAgICAgICAgICAgICB0aGlzLnRyaWdnZXJFdmVudCgnbG9hZCcsIHsgdmFsdWUsIG9wdGlvbnMgfSlcbiAgICAgICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8g5q2j5bi45Yqg6L29XG4gICAgICAgICAgICB0aGlzLmVtaXRFdmVudCh7IHZhbHVlLCBvcHRpb25zLCBkb25lIH0pXG4gICAgICAgIH0sXG4gICAgICAgIGVtaXRFdmVudChwYXJhbXMgPSB7fSkge1xuICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoJ2NoYW5nZScsIHBhcmFtcylcblxuICAgICAgICAgICAgLy8g5b2T6YCJ5oup5a6M5oiQ5pe25YWz6Zet57uE5Lu2XG4gICAgICAgICAgICBpZiAocGFyYW1zLmRvbmUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9uUG9wdXBDbG9zZSgpXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGdldEZpZWxkTmFtZShuYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kYXRhLmZpZWxkTmFtZXNbbmFtZV1cbiAgICAgICAgfSxcbiAgICB9LFxuICAgIGF0dGFjaGVkKCkge1xuICAgICAgICBjb25zdCB7IGRlZmF1bHRWYWx1ZSwgdmFsdWUsIGNvbnRyb2xsZWQgfSA9IHRoaXMuZGF0YVxuICAgICAgICBjb25zdCBhY3RpdmVWYWx1ZSA9IGNvbnRyb2xsZWQgPyB2YWx1ZSA6IGRlZmF1bHRWYWx1ZVxuICAgICAgICBjb25zdCBmaWVsZE5hbWVzID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdEZpZWxkTmFtZXMsIHRoaXMuZGF0YS5kZWZhdWx0RmllbGROYW1lcylcblxuICAgICAgICB0aGlzLnNldERhdGEoeyBhY3RpdmVWYWx1ZSwgZmllbGROYW1lcyB9LCAoKSA9PiB0aGlzLmdldEN1cnJlbnRPcHRpb25zKGFjdGl2ZVZhbHVlKSlcbiAgICB9LFxufSlcbiJdfQ==